﻿$ServerList = @('VS-MSK00-ATM03','VS-MSK00-RBQ02','VS-WEU00-QRT01','VS-WEU02-QRT01','S-MSK01-SQL08')
#$ServerList = @('VS-MSK00-RBQ02')


foreach ($srv in $ServerList)
{
  if (!(Test-Path ("\\$srv\c$\bat")))
  {
    $bat = 'BatFiles'
  }
  else
  {
    $bat = 'bat'
  }
 
  Get-ChildItem ("\\$srv\c$\$bat") -Include *.ps1,*.bat,*.cmd -Recurse | ForEach-Object `
  {
    
    $NewGitTarget = ("C:\bat\PortableGit\LocalRep\BatFiles\$srv\"+([string]::Join('\',$_.DirectoryName.Split('\')[4..10000]))+'\')
    $NewGitTarget = $NewGitTarget -replace '\\\\','\'
    #$NewGitTarget
    #$_.FullName
    If (!(Test-Path $NewGitTarget))
    {
      New-Item -ItemType "Directory" -Path $NewGitTarget
    }
    Copy-Item $_.FullName -Destination $NewGitTarget -Force
  } 
}