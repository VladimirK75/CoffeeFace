﻿$ServerList = @('VS-WEU00-QRT01','VS-MSK00-RBQ02','S-MSK01-SQL08')

foreach ($srv in $ServerList)
{
 Get-ChildItem ("\\$srv\c$\QORT") -Include *.ini,*.ps1,*.txk,*.cfg,*.bat,*.cmd,*.xsl -Recurse | ForEach-Object `
 {
   if ($srv -match 'WEU')
   {
     $space = 'QORT_OFFSHORE_INI'
   }
   else
   {
     $space = 'QORT_RENBR_INI'
   }  
   $NewGitTarget = ("C:\bat\PortableGit\LocalRep\$space\$srv\"+([string]::Join('\',$_.DirectoryName.Split('\')[5..10000]))+'\')
   #$NewGitTarget
   If (!(Test-Path $NewGitTarget))
	  {
	    New-Item -ItemType "Directory" -Path $NewGitTarget
	  }

   Copy-Item $_.FullName -Destination $NewGitTarget -Force
 }
}
