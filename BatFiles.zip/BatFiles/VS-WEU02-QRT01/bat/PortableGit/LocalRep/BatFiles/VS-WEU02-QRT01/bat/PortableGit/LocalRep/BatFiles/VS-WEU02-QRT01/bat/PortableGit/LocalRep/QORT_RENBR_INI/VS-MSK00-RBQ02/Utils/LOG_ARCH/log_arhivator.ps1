    #Start
################################

# Current date
$S_time=get-date -format HH:mm:ss
$C_Date=get-date 
$Y_Date=get-date $C_Date.AddDays(-1)	

# defaul BackUp folders
$Accounts_Folder="c:\QORT\srvComp\SrvAccounts\*.log"
$DocMaker_Folder="c:\QORT\srvComp\srvDocMaker\*.log"

# defaul BackUp TARGET folders
$Accounts_Target="c:\Log\a_test\T0\srvAccounts\"
$DocMaker_Target="c:\Log\a_test\T0\srvDocMaker\"

# fo ARHIVATION
$List_for_Arhiv="c:\Log\a_test\T0\*.log"
$Arhiv_dist="c:\Log\a_test\Arch\$(get-date $Y_Date -format yyyyMMdd).zip" 



##########################
## MAIN
##########################

# clear folder
remove-item c:\Log\a_test\T0\ -recurse

# create again
new-item c:\Log\a_test\T0\srvAccounts\ -type directory
new-item c:\Log\a_test\T0\srvDocMaker\ -type directory

# Replace LOGS
move-item -path $Accounts_Folder -destination $Accounts_Target  -force
move-item -path $DocMaker_Folder -destination $DocMaker_Target  -force

#Arhiving last version
#rar a -r -y  $Arhiv_dist $List_for_Arhiv
#c:\Program Files\7-Zip\7z.exe e -y $Arhiv_dist $List_for_Arhiv
& "C:\Program Files\7-Zip\7z.exe" a -tzip -mx7 -r0 $Arhiv_dist $List_for_Arhiv

#
#$source = "C:\Date"
#$destination = "C:\Temp"
#$passwd = "Password"
#$curdate = (Get-Date -UFormat "%d-%m-%Y")

# "C:\Program Files\7-Zip\7z.exe" a -tzip -ssw -mx1 -p$passwd -r0 $destination\backup_$curdate.zip $source




#send mail
#$smtp=new-object system.net.mail.SMTPclient ("msdb.dbo.sp_send_dbmail")
#$body="QORT server log files arhivation process started at $S_time and compleated at $(get-date -format HH:mm:ss)"
#$smtp.send("ayushin@rencap.com", "QORT server logs arhivation",$body)

#####################################
#END
