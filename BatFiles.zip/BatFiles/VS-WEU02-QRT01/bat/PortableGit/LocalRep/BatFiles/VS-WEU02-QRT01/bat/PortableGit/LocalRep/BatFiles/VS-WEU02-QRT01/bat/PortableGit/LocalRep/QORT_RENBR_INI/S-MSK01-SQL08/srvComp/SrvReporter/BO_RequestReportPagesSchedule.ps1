﻿$userName = "svcQORT"
$passWord = "svcQORT"
$Subacc = $args[1]#"RB0002"
$Period = $args[0]#"Last Work Day"

#$Subacc = "UMG939"
#$Period = "Last Work Day"

if (!$args[2]) {[datetime]$DateStart = (Get-Date).AddDays(-1)} else {[datetime]$DateStart = [datetime]::parseexact($args[2], 'yyyyMMdd', $null) }
if (!$args[3]) {[datetime]$DateEnd = (Get-Date).AddDays(-1)} else {[datetime]$DateEnd = [datetime]::parseexact($args[3], 'yyyyMMdd', $null)}

$authType = "secEnterprise"
$baseURL   = "http://vs-msk01-bip01:6405/biprws"
$logonURL  = "$baseURL/logon/long"
$logoffURL = "$baseURL/logoff"
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Accept","Application/xml")
$headers.Add("Content-Type","Application/xml")
$logonXml = @"
<attrs xmlns="http://www.sap.com/rws/bip">
  <attr name="userName" type="string">$userName</attr>
  <attr name="password" type="string">$passWord</attr>
  <attr name="auth" type="string" possibilities="secEnterprise,secLDAP,secWinAD,secSAPR3">$authType</attr>
</attrs>
"@

#SQL query to Get Report Date
Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandTimeout = 120
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $sqlConnection.Close()
  Return $DataSet
}


$BDate = $DateStart.ToString('yyyy-MM-ddT00:00:00.000-07:00')
$EDate = $DateEnd.ToString('yyyy-MM-ddT00:00:00.000-07:00')
$HelperBDate = $DateStart.ToString('yyyy-MM-ddT00:00:00.000-07:00')
$HelperEDate = $DateEnd.ToString('yyyy-MM-ddT00:00:00.000-07:00')

$sqlDate = $DateStart.ToString('yyyyMMdd')

$sqlQuery01 = "select dbo.[fn_GetBDay](CONVERT(date,cast($sqlDate as varchar(8))), '$Period', 5, 1, 1)"
$HelpersqlQuery = "exec [sp_RPT_QORTHelper] '$Subacc', '$HelperBDate', '$HelperEDate', '$Period'"

$SqlData  = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $sqlQuery01 'QORT' 'QORTDB'
$SqlData2 = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $HelpersqlQuery 'QORT' 'QORTDB'

$RDate = $SqlData.Tables[0].Rows[0].Column1

if ($SqlData2.Tables[0].Rows[0].Column1 -eq 0) 
{
  Write-Host $HelpersqlQuery
  Write-Host "$Subacc NOT ACTIVE OPERATIONS"
  break
}
else
{
# Log on to the BI Platform
$response = Invoke-RestMethod -Uri $logonURL -Method Post -Headers $headers -Body $logonXml
# Retrieve the logonToken, this assumes everything went OK, since Invoke-RestMethod doesn't support .StatusCode
$SAPToken = $response.entry.content.attrs.attr.'#text'
$headers.Add("X-SAP-Logontoken",$SAPToken)




if ($period -eq "Last Month") { 

$FileName = "M" + ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('MM') + "`_$Subacc`_"

}
else 
{
  if ($args[2] -eq $args[3])
  {
    $FileName = "D" + $RDate + "`_$Subacc`_"
  }
  else
  {
    $FileName = "F" + $RDate + "`_$Subacc`_"
  }
}

$FileName = $FileName + $(get-date -f yyMMdd_HHmm)

$FileName = $FileName -replace '\s',''

$Month = ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('yyyy') + ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('MM')

$Body = @"
    <parameters>
		<parameter>
			<id>0</id>
			<name>Enter End Date:</name>
			<answer constrained="false" type="DateTime">
				<values>
					<value>$EDate</value>
				</values>
			</answer>
		</parameter>
		<parameter>
			<id>1</id>
			<name>Enter Period:</name>
			<answer type="Text" constrained="false">
				<values>
					<value>$Period</value>
				</values>
			</answer>
		</parameter>
		<parameter>
			<id>2</id>
			<name>Enter Start Date:</name>
			<answer constrained="false" type="DateTime">
				<values>
					<value>$BDate</value>
				</values>
			</answer>
		</parameter>
		<parameter>
			<id>3</id>
			<name>Enter SubAccCode:</name>
			<answer>
				<values>
					<value>$Subacc</value>
				</values>
			</answer>
		</parameter>
	</parameters>
"@


#if (-not (Test-Path "\\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc"))
#{
#    New-Item -ItemType directory -Path \\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc
#}

#if (-not (Test-Path "\\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc\$Month"))
#{
#    New-Item -ItemType directory -Path \\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc\$Month | Out-Null
#}



if ($Subacc -eq "UMG873 A") 
	{ 
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/5531/parameters" -Method PUT -Body $Body -Headers $headers 

        $headers = @{ “X-SAP-LogonToken” = $SAPToken; “Accept” = “application/vnd.openxmlformats-officedocument.spreadsheetml.sheet”}

        $response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/5531" -Method Get -Headers $headers -OutFile "\\s-msk01-sql08\srvReporter\OutSideClientRequests\$FileName.xlsx"
	}
elseif ($Subacc.StartsWith("RB0") -or $Subacc.StartsWith("UMG")) 
	{
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/24703/parameters" -Method PUT -Body $Body -Headers $headers 

        $headers = @{ “X-SAP-LogonToken” = $SAPToken; “Accept” = “application/vnd.openxmlformats-officedocument.spreadsheetml.sheet”}

        $response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/24703" -Method Get -Headers $headers -OutFile "\\s-msk01-sql08\srvReporter\OutSideClientRequests\$FileName.xlsx" 
	}
else 	{
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/5532/parameters" -Method PUT -Body $Body -Headers $headers 

        $headers = @{ “X-SAP-LogonToken” = $SAPToken; “Accept” = “application/vnd.openxmlformats-officedocument.spreadsheetml.sheet”}

        $response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/5532" -Method Get -Headers $headers -OutFile "\\s-msk01-sql08\srvReporter\OutSideClientRequests\$FileName.xlsx"
	}

Write-Host ("$FileName.xlsx")

}





