﻿$Day      = Get-Date -Format yyyyMMdd_HHmmss
$HomeDir  = $PSScriptRoot
$CossUtil = "$PSScriptRoot\insertcrossrates.exe"
$7Zip     = "C:\Program Files\7-Zip\7z.exe"


$a = $CossUtil,$7Zip  # Проверяем валидность путей
 Foreach ($srt in $a)
 {
   If (Test-Path $srt)
   {}
   Else
   {
     Write-Error " Path $srt is not valid"
   }
 }

& $HomeDir\InsertCrossRates.exe
Get-ChildItem $HomeDir\*log | Rename-Item -NewName {$_.BaseName+"_$Day"+$_.Extension}
& $7Zip u $HomeDir\ArchiveLog.zip $HomeDir\*.log
Remove-Item -Path "$HomeDir\*.log"