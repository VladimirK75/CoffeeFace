﻿param(
[string]$Date,
[string]$SubaccCode
)

$sqlQuery = "exec sp_RPT_EXO_CSV '" + $Date + "', '" + $SubaccCode + "'"
$SqlServer = "QORT_DMA\QORT_DMA"
$SqlCatalog = "QORT_DB_PROD"
$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = "Server = $SqlServer; Database =$SqlCatalog; Integrated Security = True;"

# Create a SqlCommand object to define the query
$sqlCmd = New-Object System.Data.SqlClient.SqlCommand
$sqlCmd.CommandText = $sqlQuery
$sqlCmd.Connection = $sqlConnection

# Create a SqlAdapter that actually does the work and manages everything
$sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$sqlAdapter.SelectCommand = $sqlCmd

# Create an empty DataSet for the query to fill with its results
$dataSet = New-Object System.Data.DataSet

# Execute the query and fill the DataSet (then disconnect)
$sqlAdapter.Fill($dataSet)  | out-null
$sqlConnection.Close()

$filename = 'MS_EXECUTION_' + $Date + '.csv'
$filepath = 'C:\QORT\SrvComp\SrvReporter\ClientReports\' + $filename

# Convert DataSet table to array for ease of use
if ($dataSet.Tables[0].Rows.Count -gt 0)
{
$dataSet.Tables[0] | Export-Csv $filepath -notypeinformation -Delimiter ';'
(Get-Content $filepath) | Foreach-Object {$_ -replace '"', ''} | Out-File $filepath -Encoding OEM
Write-Host($filename)
}
