$CurrentDate = (Get-Date)

Remove-Item c:\QORT\ExchReports\Reports* -Confirm:$false -Recurse

if ($CurrentDate.Day -lt 10) {
$newday = "0" + $CurrentDate.Day
}
else {
$newday = $CurrentDate.Day
}

if ($CurrentDate.Month -lt 10) {
$newmonth = "0" + $CurrentDate.Month
}
else {
$newmonth = $CurrentDate.Month
}

$Date = [string]$CurrentDate.Year + [string]$newmonth + [string]$newday 
#write-host $Date

$filemask = "FO" + [string]$CurrentDate.Year + [string]$newmonth  + [string]$newday + "_?.zip"

$latest = Get-ChildItem -Path \\rencap.com\Files\MSK01-Applications\AppData\RTSReports\FROM_FORTS\$filemask | Sort-Object LastAccessTime -Descending | Select-Object -First 1

$CMD = 'c:\QORT\ExchReports\unzip.exe '
$arg1 = $latest 
$arg2 = '-d'
$arg3 = 'c:\QORT\ExchReports\Reports'
#write-host $CMD $arg1 $arg2 $arg3

& $CMD -o $arg1 -d $arg3



