# Run in PS console
# .\deploy.ps1 -AppName QortUploadFeed -BuildNumber 1.8.141-SNAPSHOT -WinServiceName "RC QORT Upload Feed"
param (
    [Parameter(Mandatory=$true)][string]$AppName,
    [Parameter(Mandatory=$true)][string]$BuildNumber,
    [Parameter(Mandatory=$true)][string]$WinServiceName,
	[switch]$Force = $false
 )

function EmptyLogFile
{
	if(Test-Path $LogFile)
	{
		Remove-Item $LogFile;
	}
}

function LogMessage
{
    param([string]$Message)

    ((Get-Date).ToString() + " - " + $Message) >> $LogFile;
    Write-Host  $Message;
}


$Build      =  $AppName + "-" + $BuildNumber
$SourceDir  =  "\\rencap.com\files\WEU01-Workgroups\IT\FOC\Builds\" + $AppName
$Source     =  $SourceDir + "\" + $Build
$ScriptDir  =  Split-Path $script:MyInvocation.MyCommand.Path
$DestDir    =  $ScriptDir
$Dest       =  $DestDir + "\" + $Build
$SymLink   =  $DestDir + "\" + $AppName

$LogFile = $script:MyInvocation.MyCommand.Path + ".log";
EmptyLogFile
LogMessage -Message ("Install build " + $Build);

LogMessage -Message ("Check currently active version of " + $AppName + " in " + $SymLink);
if(Test-Path $SymLink) {
	if( (Join-Path -Path (Get-Item -Path $SymLink).Target -ChildPath "") -eq (Join-Path -Path $Dest -ChildPath "") ) 
	{
		LogMessage -Message ("Symbolic Link " + $SymLink + " exists for " + $Dest + " could not replace working version");
		return;
	}
}

LogMessage -Message ("Stop service " + $WinServiceName);
Get-Service $WinServiceName | Where {$_.status -eq "Running"} |  Stop-Service
Get-Service $WinServiceName

LogMessage -Message ("Copy files to " + $Dest);
if(Test-Path $Dest)
{
    LogMessage -Message ("Delete " + $Dest);
    Remove-Item -Path $Dest -Recurse -Force
}
LogMessage -Message ("Copy from " + $Source + " to " + $DestDir);
Copy-Item -Path $Source -Destination $DestDir -Recurse
# New-Item $Dest -ItemType Directory

LogMessage -Message ("Create Soft link " + $SymLink);
New-Item -ItemType SymbolicLink -Path $SymLink -Target $Dest

LogMessage -Message ("Start service " + $WinServiceName);
Get-Service $WinServiceName | Where {$_.status -eq "Stopped"} |  Start-Service
