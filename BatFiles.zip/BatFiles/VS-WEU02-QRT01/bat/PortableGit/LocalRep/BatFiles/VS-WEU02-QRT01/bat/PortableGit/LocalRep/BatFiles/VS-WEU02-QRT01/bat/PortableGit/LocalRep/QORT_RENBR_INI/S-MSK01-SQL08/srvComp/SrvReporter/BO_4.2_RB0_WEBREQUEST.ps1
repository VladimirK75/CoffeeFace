﻿$userName = "svcQORT"
$passWord = "svcQORT"
$Subacc = $args[1]#"RB0029"
$Period = $args[0]#"Last Work Day"

Write-Host($args[0])
Write-Host($args[1])
Write-Host($args[2])
Write-Host($args[3])

if (!$args[2]) {[datetime]$DateStart = (Get-Date).AddDays(-1)} else {[datetime]$DateStart = [datetime]::parseexact($args[2], 'yyyyMMdd', $null) }
if (!$args[3] ) {[datetime]$DateEnd = (Get-Date).AddDays(-1)} else {[datetime]$DateEnd = [datetime]::parseexact($args[3], 'yyyyMMdd', $null)}

$authType = "secEnterprise"
$baseURL   = "http://vs-msk01-bip01:6405/biprws"
$logonURL  = "$baseURL/logon/long"
$logoffURL = "$baseURL/logoff"
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Accept","Application/xml")
$headers.Add("Content-Type","Application/xml")
$logonXml = @"
<attrs xmlns="http://www.sap.com/rws/bip">
  <attr name="userName" type="string">$userName</attr>
  <attr name="password" type="string">$passWord</attr>
  <attr name="auth" type="string" possibilities="secEnterprise,secLDAP,secWinAD,secSAPR3">$authType</attr>
</attrs>
"@

#SQL query to Get Report Date





$BDate = $DateStart.ToString('yyyy-MM-ddT00:00:00.000-07:00')
$EDate = $DateEnd.ToString('yyyy-MM-ddT00:00:00.000-07:00')


$sqlDate = $DateStart.ToString('yyyyMMdd')

$sqlQuery = "select dbo.[fn_GetBDay](CONVERT(date,cast($sqlDate as varchar(8))), '$Period', 5, 1, 1)"
$SqlServer = "MSK00-SQL08-RB"
$SqlCatalog = "QORT_DB_PROD"
$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = "Server = $SqlServer; Database =$SqlCatalog; Integrated Security = True;"

$sqlCmd = New-Object System.Data.SqlClient.SqlCommand
$sqlCmd.CommandText = $sqlQuery
$sqlCmd.Connection = $sqlConnection

$sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$sqlAdapter.SelectCommand = $sqlCmd

$dataSet = New-Object System.Data.DataSet

# Execute the query and fill the DataSet (then disconnect)
$sqlAdapter.Fill($dataSet)  | out-null
$sqlConnection.Close()

$RDate = $dataSet.Tables[0].Rows[0].Column1

# Log on to the BI Platform
$response = Invoke-RestMethod -Uri $logonURL -Method Post -Headers $headers -Body $logonXml
# Retrieve the logonToken, this assumes everything went OK, since Invoke-RestMethod doesn't support .StatusCode
$SAPToken = $response.entry.content.attrs.attr.'#text'
$headers.Add("X-SAP-Logontoken",$SAPToken)



if ($period -eq "Last Month") { 

$FileName = "M" + ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('MM') + "`_$Subacc`_"

}
else 
{
$FileName = "D" + $RDate + "`_$Subacc`_"
}

$FileName = $FileName + $(get-date -f yyMMdd_HHmm)

$Month = ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('yyyy') + ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('MM')

$schedule = @"
<schedule>
	<name>$FileName</name>
    <format type="xls"/>
    <destination >
    <useSpecificName>$FileName</useSpecificName>
        <filesystem>
            <directory>\\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc\$Month</directory>
        </filesystem>
    </destination>
    <parameters>
		<parameter dpId="DP65" type="prompt" optional="false">
			<id>0</id>
			<technicalName>Enter End Date:</technicalName>
			<name>Enter End Date:</name>
			<answer type="DateTime" constrained="false">
				<values>
					<value>$EDate</value>
				</values>
			</answer>
		</parameter>
		<parameter dpId="DP65" type="prompt" optional="false">
			<id>1</id>
			<technicalName>Enter Period:</technicalName>
			<name>Enter Period:</name>
			<answer type="Text" constrained="false">
				<values>
					<value>$Period</value>
				</values>
			</answer>
		</parameter>
		<parameter dpId="DP65" type="prompt" optional="false">
			<id>2</id>
			<technicalName>Enter Start Date:</technicalName>
			<name>Enter Start Date:</name>
			<answer type="DateTime" constrained="false">
				<values>
					<value>$BDate</value>
				</values>
			</answer>
		</parameter>
		<parameter dpId="DP65" type="prompt" optional="false">
			<id>3</id>
			<technicalName>Enter SubAccCode:</technicalName>
			<name>Enter SubAccCode:</name>
			<answer type="Text" constrained="false">
				<values>
					<value>$Subacc</value>
				</values>
			</answer>
		</parameter>
	</parameters>
</schedule>
"@
#Write-Host($Subacc)
if ($Subacc -eq "UMG873 A") 
	{ 
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/5531/schedules" -Method Post -Headers $headers -Body $schedule 
	}
elseif ($Subacc.StartsWith("RB0") -or $Subacc.StartsWith("UMG")) 
	{
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/5534/schedules" -Method Post -Headers $headers -Body $schedule 
	}
else 	{
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/5532/schedules" -Method Post -Headers $headers -Body $schedule
	}