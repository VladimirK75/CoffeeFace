﻿Param(
       [Parameter(Mandatory = $True, Position = 0)]
       [String]$SourseDir, # Откуда
       [Parameter(Mandatory = $True, Position = 1)]
       [String]$TargetDir # Куда копируем

     )

Function Get-LastBOid
{ 
  Param(
         [String]$Path
        ,[String]$FileName2
       )
    $a = @(Get-ChildItem ($Path+$FileName2+'*.xls') | ForEach-Object `
    {
      $BaseName = $_.BaseName
      $BaseName.Substring($BaseName.LastIndexOf('_') + 1)
    })
    $max = $a | Measure-Object -Maximum | ForEach-Object {$_.Maximum}
    $max++
    return $max
}
	 
$FileName = [io.path]::GetFileNameWithoutExtension($SourseDir)
$T0date   = (Get-Date).ToString('yyyMMdd')

if ($FileName[0] -in ('D') -and $FileName -notmatch "$T0date")
{
  $TargetDir = Join-Path -Path $TargetDir -ChildPath ''
  $FileName  = $FileName -replace '\d{6}_\d{4}', ''
  $FileName  = $FileName+(Get-LastBOid $TargetDir $FileName)+'.xls'
  
  Copy-Item $SourseDir -Destination ($TargetDir+$FileName) -Force
}