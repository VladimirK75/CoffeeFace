﻿Param(
       [Parameter(Mandatory = $True, Position = 0)]
       [String]$SourseDir, # Откуда
       [Parameter(Mandatory = $True, Position = 1)]
       [String]$TargetDir # Куда копируем

     )

Function Get-LastBOid
{ 
  Param(
         [String]$Path
        ,[String]$FileName2
       )
    $a = @(Get-ChildItem ($Path+$FileName2+'*.xls') | ForEach-Object `
    {
      $BaseName = $_.BaseName
      $BaseName.Substring($BaseName.LastIndexOf('_') + 1)
    })
    $max = $a | Measure-Object -Maximum | ForEach-Object {$_.Maximum}
    $max++
    return $max
}
	 
$FirstChar = [io.path]::GetFileNameWithoutExtension($SourseDir)

if ($FirstChar[0] -ne 'F')	 
{
  $TargetDir = Join-Path -Path $TargetDir -ChildPath '' 
  $FileName  = [io.path]::GetFileNameWithoutExtension($SourseDir)
  $FileName  = $FileName -replace '\d{6}_\d{4}', ''
  $FileName  = $FileName+(Get-LastBOid $TargetDir $FileName)+'.xls'
  
  Copy-Item $SourseDir -Destination ($TargetDir+$FileName) -Force
}