﻿$userName = "svcQORT"
$passWord = "svcQORT"
$Subacc = $args[1]#"RB0002"
$Period = $args[0]#"Last Work Day"

#$Subacc = "UMG939"
#$Period = "Last Work Day"

if (!$args[2]) {[datetime]$DateStart = (Get-Date).AddDays(-1)} else {[datetime]$DateStart = [datetime]::parseexact($args[2], 'yyyyMMdd', $null) }
if (!$args[3] ) {[datetime]$DateEnd = (Get-Date).AddDays(-1)} else {[datetime]$DateEnd = [datetime]::parseexact($args[3], 'yyyyMMdd', $null)}

$authType = "secEnterprise"
$baseURL   = "http://vs-msk01-bip01:6405/biprws"
$logonURL  = "$baseURL/logon/long"
$logoffURL = "$baseURL/logoff"
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Accept","Application/xml")
$headers.Add("Content-Type","Application/xml")
$logonXml = @"
<attrs xmlns="http://www.sap.com/rws/bip">
  <attr name="userName" type="string">$userName</attr>
  <attr name="password" type="string">$passWord</attr>
  <attr name="auth" type="string" possibilities="secEnterprise,secLDAP,secWinAD,secSAPR3">$authType</attr>
</attrs>
"@

#SQL query to Get Report Date


$BDate = $DateStart.ToString('yyyy-MM-ddT00:00:00.000-07:00')
$EDate = $DateEnd.ToString('yyyy-MM-ddT00:00:00.000-07:00')


$sqlDate = $DateStart.ToString('yyyyMMdd')

$sqlQuery = "select dbo.[fn_GetBDay](CONVERT(date,cast($sqlDate as varchar(8))), '$Period', 5, 1, 1)"
$SqlServer = "MSK00-SQL08-RB"
$SqlCatalog = "QORT_DB_PROD"
$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = "Server = $SqlServer; Database =$SqlCatalog; Integrated Security = True;"

$sqlCmd = New-Object System.Data.SqlClient.SqlCommand
$sqlCmd.CommandText = $sqlQuery
$sqlCmd.Connection = $sqlConnection

$sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$sqlAdapter.SelectCommand = $sqlCmd

$dataSet = New-Object System.Data.DataSet

# Execute the query and fill the DataSet (then disconnect)
$sqlAdapter.Fill($dataSet)  | out-null
$sqlConnection.Close()

$RDate = $dataSet.Tables[0].Rows[0].Column1

# Log on to the BI Platform
$response = Invoke-RestMethod -Uri $logonURL -Method Post -Headers $headers -Body $logonXml
# Retrieve the logonToken, this assumes everything went OK, since Invoke-RestMethod doesn't support .StatusCode
$SAPToken = $response.entry.content.attrs.attr.'#text'
$headers.Add("X-SAP-Logontoken",$SAPToken)


if ($period -eq "Last Month") { 

$FileName = "M" + ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('MM') + "`_$Subacc`_"

}
else 
{
  if ($args[2] -eq $args[3])
  {
    $FileName = "D" + $RDate + "`_$Subacc`_"
  }
  else
  {
    $FileName = "F" + $RDate + "`_$Subacc`_"
  }
}

$FileName = $FileName + $(get-date -f yyMMdd_HHmm)

$FileName = $FileName -replace '\s',''

$Month = ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('yyyy') + ([datetime]::parseexact($RDate, 'yyyyMMdd', $null)).ToString('MM')

$Body = @"
    <parameters>
		<parameter>
			<id>0</id>
			<name>Enter End Date:</name>
			<answer constrained="false" type="DateTime">
				<values>
					<value>$EDate</value>
				</values>
			</answer>
		</parameter>
		<parameter>
			<id>1</id>
			<name>Enter Period:</name>
			<answer type="Text" constrained="false">
				<values>
					<value>$Period</value>
				</values>
			</answer>
		</parameter>
		<parameter>
			<id>2</id>
			<name>Enter Start Date:</name>
			<answer constrained="false" type="DateTime">
				<values>
					<value>$BDate</value>
				</values>
			</answer>
		</parameter>
		<parameter>
			<id>3</id>
			<name>Enter SubAccCode:</name>
			<answer>
				<values>
					<value>$Subacc</value>
				</values>
			</answer>
		</parameter>
	</parameters>
"@


#if (-not (Test-Path "\\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc"))
#{
#    New-Item -ItemType directory -Path \\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc
#}

#if (-not (Test-Path "\\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc\$Month"))
#{
#    New-Item -ItemType directory -Path \\vs-msk00-rbq02\SrvReporter\ClientReports\$Subacc\$Month | Out-Null
#}



if ($Subacc -eq "UMG873 A") 
	{ 
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/864464/parameters" -Method PUT -Body $Body -Headers $headers 

        $headers = @{ “X-SAP-LogonToken” = $SAPToken; “Accept” = “application/vnd.openxmlformats-officedocument.spreadsheetml.sheet”}

        $response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/864464" -Method Get -Headers $headers -OutFile "\\s-msk01-sql08\SrvReporter\OutSideClientRequests\$FileName.xlsx"
	}
elseif ($Subacc.StartsWith("RB0") -or $Subacc.StartsWith("UMG") -or $Subacc.StartsWith("RBC") -or $Subacc.StartsWith("SBS")) 
	{
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/864463/parameters" -Method PUT -Body $Body -Headers $headers 

        $headers = @{ “X-SAP-LogonToken” = $SAPToken; “Accept” = “application/vnd.openxmlformats-officedocument.spreadsheetml.sheet”}

        $response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/864463" -Method Get -Headers $headers -OutFile "\\s-msk01-sql08\SrvReporter\OutSideClientRequests\$FileName.xlsx" 
	}
else 	{
		$response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/864465/parameters" -Method PUT -Body $Body -Headers $headers 

        $headers = @{ “X-SAP-LogonToken” = $SAPToken; “Accept” = “application/vnd.openxmlformats-officedocument.spreadsheetml.sheet”}

        $response = Invoke-RestMethod -Uri "$baseURL/raylight/v1/documents/864465" -Method Get -Headers $headers -OutFile "\\s-msk01-sql08\SrvReporter\OutSideClientRequests\$FileName.xlsx"
	}

Write-Host ("$FileName.xlsx")



