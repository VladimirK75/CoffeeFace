﻿$Day = Get-Date -Format yyyyMMdd_HHmmss
& C:\QORT\Utils\IC\insertcrossrates.exe
Get-ChildItem C:\QORT\Utils\IC\ *log | Rename-Item -NewName {$_.BaseName+"_$Day"+$_.Extension}
Compress-Archive -Path "C:\QORT\Utils\IC\*.log" -Update "C:\QORT\Utils\IC\ArchiveLog.zip"
Remove-Item -Path "C:\QORT\Utils\IC\*.log"