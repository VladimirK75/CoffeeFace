﻿# QORT2DDM

$ServerList = @('VS-MSK00-ATM03','VS-WEU02-QRT01')

foreach ($srv in $ServerList)
{
  if ($srv -match 'WEU')
  {
    $space = 'QORT_OFFSHORE_SERVICES'
  }
  else
  {
    $space = 'QORT_RENBR_SERVICES'
  }
  Get-ChildItem ("\\$srv\c$\QORT2DDM\*\conf") -Include *.conf,*.xml,*.properties,*.yaml,*.json -Recurse | ForEach-Object `
  {
    $NewGitTarget = ("C:\bat\PortableGit\LocalRep\$space\$srv\"+([string]::Join('\',$_.DirectoryName.Split('\')[5..10000]))+'\')
    If (!(Test-Path $NewGitTarget))
    {
      New-Item -ItemType "Directory" -Path $NewGitTarget
    }
    Copy-Item $_.FullName -Destination $NewGitTarget -Force
  } 
}


#DDMSettlementService

$ServerList2 = @('VS-MSK00-ATM03')

foreach ($srv in $ServerList2)
{
  if ($srv -match 'WEU')
  {
    $space = 'QORT_OFFSHORE_SERVICES'
  }
  else
  {
    $space = 'QORT_RENBR_SERVICES'
  }
  Get-ChildItem ("\\$srv\c$\DDMSettlementService\conf") -Include *.conf,*.xml,*.properties,*.json -Recurse | ForEach-Object `
  {
    $NewGitTarget = ("C:\bat\PortableGit\LocalRep\$space\$srv\"+([string]::Join('\',$_.DirectoryName.Split('\')[4..10000]))+'\')
    #$NewGitTarget
    
    If (!(Test-Path $NewGitTarget))
    {
      New-Item -ItemType "Directory" -Path $NewGitTarget
    }
    Copy-Item $_.FullName -Destination $NewGitTarget -Force
    
  } 
}


#Q2CTransactionsAdapter

$ServerList3 = @('VS-MSK00-ATM03')

foreach ($srv in $ServerList3)
{
  if ($srv -match 'WEU')
  {
    $space = 'QORT_OFFSHORE_SERVICES'
  }
  else
  {
    $space = 'QORT_RENBR_SERVICES'
  }
  Get-ChildItem ("\\$srv\c$\Q2CTransactionsAdapter\") -Include *.conf,*.xml,*.properties,*.json -Recurse | ForEach-Object `
  {
    $NewGitTarget = ("C:\bat\PortableGit\LocalRep\$space\$srv\"+([string]::Join('\',$_.DirectoryName.Split('\')[4..10000]))+'\')
    #$NewGitTarget
    If (!(Test-Path $NewGitTarget))
    {
      New-Item -ItemType "Directory" -Path $NewGitTarget
    }
    Copy-Item $_.FullName -Destination $NewGitTarget -Force
  } 
}


# QORT2DDM

$ServerList = @('VS-MSK00-RBQ02','VS-WEU00-QRT01')

foreach ($srv in $ServerList)
{
  if ($srv -match 'WEU')
  {
    $space = 'QORT_OFFSHORE_SERVICES'
  }
  else
  {
    $space = 'QORT_RENBR_SERVICES'
  }
  Get-ChildItem ("\\$srv\c$\GRDBServices\") -Include *.xslt, *.config -Recurse | ForEach-Object `
  {
    $NewGitTarget = ("C:\bat\PortableGit\LocalRep\$space\$srv\"+([string]::Join('\',$_.DirectoryName.Split('\')[4..10000]))+'\')
    If (!(Test-Path $NewGitTarget))
    {
      New-Item -ItemType "Directory" -Path $NewGitTarget
    }
    Copy-Item $_.FullName -Destination $NewGitTarget -Force
  } 
}


# GRDBServices 

$ServerList = @('VS-MSK00-RBQ02','VS-WEU02-QRT01')

foreach ($srv in $ServerList)
{
  if ($srv -match 'WEU')
  {
    $space = 'QORT_OFFSHORE_SERVICES'
  }
  else
  {
    $space = 'QORT_RENBR_SERVICES'
  }
  Get-ChildItem ("\\$srv\c$\GRDBServices\") -Include *.xslt, *.config -Recurse | ForEach-Object `
  {
    $NewGitTarget = ("C:\bat\PortableGit\LocalRep\$space\$srv\"+([string]::Join('\',$_.DirectoryName.Split('\')[4..10000]))+'\')
    If (!(Test-Path $NewGitTarget))
    {
      New-Item -ItemType "Directory" -Path $NewGitTarget
    }
    Copy-Item $_.FullName -Destination $NewGitTarget -Force
  } 
}

