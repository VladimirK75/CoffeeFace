﻿Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}

$csvPath = "\\rencap.com\files\WEU01-Workgroups\BackQORT\Orders_to_RedKite"
$zipPath = "\\rencap.com\files\WEU01-Workgroups\BackQORT\Orders_to_RedKite\backup"


$SqlQuery  = "SELECT QORT_DDM.[dbo].[DDM_fn_AddBusinessDay] ((CONVERT(varchar(255), GETDATE(), 112)),-1,'Reports_RW')"

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$FileDate =  $SqlData.Tables.Column1

$FileName = 'NULL'
$FileLen  = 0
$ErrorNum = 4

Get-ChildItem "$csvPath\*$FileDate*" | ForEach-Object `
{
  $FileName = $_.Name
  $FileLen  = $_.Length
} 

Get-ChildItem "$zipPath\*$FileDate*.zip" | ForEach-Object `
{
  $FileName = $_.Name
  $FileLen  = ($_.Length/1024kb)
} 


if ($FileLen -eq 0 -or $FileLen -le 1)
{
  $ErrorNum = 4
}
else
{
  $ErrorNum = 3
}

$FileLen = [math]::Round($FileLen, 2)
#$FileLen = $FileLen -replace ',','.'

$FileLenSrt = $FileLen.ToString([cultureinfo]::GetCultureInfo('en-US'))


$SqlQuery2 =
@"
INSERT INTO RedKite_Files
(Date,FileName,FileLen,Error)
VALUES
(
'$FileDate','$FileName',$FileLenSrt,$ErrorNum
)
"@


$SqlData = Select-Sql "VS-WEU00-SQL09\RPT" "ReportsProcedures" $SqlQuery2 'QORT' 'QORTDB'