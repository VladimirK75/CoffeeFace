﻿Import-Module sqlps
$Date = Get-Date -Format yyyyMMdd
#$Log="C:\bat\PhasesToAladdin\PhasesToDiasoft.log"
#$Date = ((Get-Date).AddDays(-1)).ToString('yyyyMMdd')
$Time = Get-Date -Format HHmmss
#$directoryPath = "\\RENCAP.COM\Files\WEU01-Workgroups\Diasoft\Integrations\ARQA\"
$directoryPath = "\\rencap.com\files\MSK01-Workgroups\Diasoft\QORT\In\"
$SQLquery='select * from [GetExchInstruction_DEPO_phases] ('+ $Date +', ''RENBR'', null, null) where MarketName != ''MICEX Main'' '
#$SQLquery='select * from [GetExchInstruction_DEPO_phases_REPO_USD] ('+ $Date +', ''RENBR'', null, null)'
$result=invoke-sqlcmd -query $SQLquery -serverinstance msk00-sql08-rb -database QORT_DDM   -QueryTimeout 600 -ConnectionTimeout 600
$filename = $directoryPath + 'QORT_MFB_RENBR_' + $Date + '_' + $Date + '_' + $Time + '.csv'
if (Test-Path $filename) { Clear-Content $filename }
$FileStream   = New-Object System.IO.FileStream($filename,[System.IO.FileMode]::OpenOrCreate)  
$StreamWriter = New-Object System.IO.StreamWriter($FileStream,[System.Text.Encoding]::Default)

foreach ($row in $result)
    {
      
        $StreamWriter.WriteLine($row.Depository + ';' +
        $row.Broker	 + ';' +
        $row.SettlementDate.ToString("MM/dd/yyyy") + ';' +
        $row.DepoClientID	 + ';' +
        $row.DepoAccount +	';' +
        $row.MarketName +	';' +
        $row.InstructionID +	';' +
        $row.Direction +';' +	
        $row.SecQty +	';' +
        $row.SecISIN +';' +	
        $row.SecRegCode +';' +	
        $row.EmitentBOCode +';' +
        $row.SecNSDCode +';' +	
        $row.Amount +	';' +
        $row.AmountCurrencyISO +';' +	
        $row.CP_BOCode +';' +	
        $row.CP_NSDCode +';' +	
        $row.InstructionType +';' +
        $row.ID +';' +	
        $row.ExchangeID +';' +	
        $row.TradeDate.ToString("MM/dd/yyyy") +	';' +
        $row.InternalTradeRef)
    }
 $StreamWriter.Close();
 $FileStream.Close();
