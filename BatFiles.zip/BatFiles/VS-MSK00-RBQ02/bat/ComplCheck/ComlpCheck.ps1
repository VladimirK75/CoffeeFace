﻿$ErrorActionPreference = "Stop"

Try
{
  $Sourse    = "C:\QORT\srvComp\srvTDB\FSFM\"
  $ErrorLog  = "$PSScriptRoot\ComlpCheck.log"
  $7Zip      = "C:\Program Files\7-Zip\7z.exe"
  $Date      = (Get-Date).ToString('yyyyMMdd')
  $DelDays   = -7
  
  Get-ChildItem $Sourse *.dbf | Rename-Item -NewName 'ComplCheck.dbf'
  TIMEOUT /T 900 /NOBREAK 
  
  $Count = Get-ChildItem $Sourse *.csv | Measure-Object | ForEach-Object {$_.Count}
  if($Count -ne 0)
  {
    $FileStream   = New-Object System.IO.FileStream("$Sourse\DelimiterDollar.csv",[System.IO.FileMode]::OpenOrCreate)  
    $StreamWriter = New-Object System.IO.StreamWriter($FileStream,[System.Text.Encoding]::Default)
  }  
  
  Get-ChildItem $Sourse "Результаты*.csv" | ForEach-Object `
  {
    $a = Get-Content $_.Fullname
	$a = $a -replace '\$','#'	
    Foreach ($rownum in $a)
    {
      $n = 6
      $row2 = '' 
      for ($i=($rownum.Length); $i -ge 0; $i--)
      {
        If ($rownum[$i] -eq ';'-and $n -ne 0)
        {
          $row2 = $row2+'$'
          $n = $n - 1;
        }
        Else
        {
          $row2 = $row2+$rownum[$i]
        }
      }
      $NewRow = ''
      for ($i=($row2.Length); $i -ge 0; $i--)
      {
        $NewRow = $NewRow +$row2[$i] 
      }
	  $StreamWriter.WriteLine($NewRow)
      #$NewRow | Add-Content ("$Sourse"+"DelimiterDollar.csv")
    }
  }
  $StreamWriter.Close();
  $FileStream.Close();
   
  Get-ChildItem $Sourse *.csv | ForEach-Object `
  {
    if($Count -ne 0)
	{
	  &$7Zip a -sdel ($Sourse+"$Date"+'.zip') $_.FullName
	}
  }
  
  Get-ChildItem $Sourse *.zip | Where-Object {$_.CreationTime -lt ((Get-Date).AddDays($DelDays))} | ForEach-Object `
  {
    Remove-Item $_.Fullname
  }
}  
Finally
{
  If($Error)
  {
    (Get-Date).ToString('dd.MM.yyyy HH:mm:ss') | Out-File $ErrorLog -Append
    $Error | Format-List -Property * -Force    | Out-File $ErrorLog -Append
  }
}
