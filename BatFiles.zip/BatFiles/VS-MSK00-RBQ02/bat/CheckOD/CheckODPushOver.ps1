﻿Function Send-Pushover
{
Param(
	[Parameter(Mandatory=$True, Position=1)]
	[string]$UserKey,
	
	[Parameter(Mandatory=$True, Position=2)]
	[string]$ApiKey,
	
	[Parameter(Mandatory=$True)]
	[string]$Message,
	
	[Parameter(Mandatory=$False)]
	[string]$Device,
	
	[Parameter(Mandatory=$False)]
	[string]$Title,
	
	[Parameter(Mandatory=$False)]
	[string]$Url,
	
	[Parameter(Mandatory=$False)]
	[string]$UrlTitle,
	
	[Parameter(Mandatory=$False)]
	[int]$Priority,
	
	[Parameter(Mandatory=$False)]
	[string]$Sound,
    
    [Parameter(Mandatory=$False)]
	[int]$Retry,

    [Parameter(Mandatory=$False)]
	[int]$Expire,

    [Parameter(Mandatory=$False)]
	[int]$Html

)
$data = @{
	token = "$ApiKey";
	user = "$UserKey";
	message = "$Message"
}

if ($Device) { $data.Add("device", "$Device") }
if ($Title) { $data.Add("title", "$Title") }
if ($Url) { $data.Add("url", "$Url") }
if ($UrlTitle) { $data.Add("url_title", "$UrlTitle") }
if ($Priority) { $data.Add("priority", $Priority) }
if ($Sound) { $data.Add("sound", "$Sound") }
if ($Retry) { $data.Add("retry", "$Retry") }
if ($Expire) { $data.Add("expire", "$Expire") }
if ($Html) { $data.Add("html", "$Html") }

Invoke-RestMethod -Method Post -Uri "https://api.pushover.net/1/messages.json" -Body $data | Out-Null

}


Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $SqlConnection.Close()
  Return $DataSet 
}
$TODAY     = Get-Date -Format yyyyMMdd
$TelChatID = Select-String -Path "C:\bat\Pushover\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
$SqlQuery  = "SELECT TOP 1 Day FROM OperationDays WITH(NOLOCK) ORDER BY Day DESC"
$SqlData   = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$QORTOD    = $SqlData.Tables.Rows.Day





If ($TODAY -ne $QORTOD)
{
  Foreach ($a in $TelChatID)
  {
    Send-Pushover -UserKey $a -ApiKey "aj4yvf7pdqxh3cyo1w7d86f7u2qdys" -Message "<font color='red'>Operation day has not been changed current OD is $QORTOD</font>" -Title "PROBLEM:QORT RENBR OD" -Priority 2 -Retry 1200 -Expire 18000 -Sound "alien" -Html 1
  }
}
Else
{
  Foreach ($a in $TelChatID)
  {
    Send-Pushover -UserKey $a -ApiKey "aj4yvf7pdqxh3cyo1w7d86f7u2qdys" -Message "Current OD is $QORTOD" -Title "OK:QORT RENBR OD"
  }
}