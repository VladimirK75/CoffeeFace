﻿Function Send-Telegram
{ 
  Param(
         [String]$Token 
        ,[String]$ChatId
        ,[String]$Text
       )
   $PayLoad = @{ "parse_mode" = "Markdown"; "disable_web_page_preview" = "True" }
   $URL     = "https://api.telegram.org/bot$Token/sendMessage?chat_id=$ChatId&text=$Text"
   $Request = Invoke-WebRequest -Uri $URL -Method Post `
              -ContentType "application/json; charset=utf-8" `
              -Body (ConvertTo-Json -Compress -InputObject $PayLoad) `
			  #-Proxy 'http://lon3.sme.zscaler.net:80'
}


Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $SqlConnection.Close()
  Return $DataSet 
}
$TODAY     = Get-Date -Format yyyyMMdd
$TelChatID = Select-String -Path "C:\bat\Telegram\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
$SqlQuery  = "SELECT TOP 1 Day FROM OperationDays WITH(NOLOCK) ORDER BY Day DESC"
$SqlData   = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$QORTOD    = $SqlData.Tables.Rows.Day

If ($TODAY -ne $QORTOD)
{
#  WHILE ($TODAY -ne $QORTOD)
#  {
    Foreach ($a in $TelChatID)
    {
      Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "*ERROR:RENBR Operation day has not been changed.* Current OD is $QORTOD"
    }
#    TIMEOUT /T 1800 /NOBREAK
#    $SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
#    $QORTOD  = $SqlData.Tables.Rows.Day
#  }
}
Else
{
  Foreach ($a in $TelChatID)
  {
    Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "OK:RENBR Current OD is $QORTOD"
  }
}



