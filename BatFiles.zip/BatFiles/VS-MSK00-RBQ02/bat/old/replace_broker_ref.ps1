$p=Resolve-Path $args[0];
Foreach ($path in $p)
{
$a=get-content $path;
$d=Split-Path $path -Leaf
$f=$args[1] + '\' + $d

If (Test-Path $f) {Remove-Item $f}

Foreach ($row in $a) 
	{
	if ($row -like '*ClientCode="DMS*') 
		{

		$c=  'BrokerRef="RB441/' + $row.substring($row.IndexOf('ClientCode="')+12,6) + '"'; 
		$row1=$row -replace 'BrokerRef="([^"]*)"', $c;
		$row1 -replace 'ClientCode="([^"]*)"', 'ClientCode="RB441"' | Add-Content $f
		continue
		} 
	if ($row -like '*ClientCode="RESEC"*') 
		{
		
		$c=  'BrokerRef="RESEC"'; 
		$row1=$row -replace 'BrokerRef="([^"]*)"', $c | Add-Content $f
		continue
		}	
	if ($row -like '*ClientCode="DMC419') 
		{
 
		$c=  'BrokerRef="RB447/' + $row.substring($row.IndexOf('ClientCode="')+12,6) + '"'; 
		$row1=$row -replace 'BrokerRef="([^"]*)"', $c;
		$row1 -replace 'ClientCode="([^"]*)"', 'ClientCode="RB331"' | Add-Content $f
		continue
		}
		
	if ($row -like '*ClientCode="DMC*') 
		{
 
		$c=  'BrokerRef="RB331/' + $row.substring($row.IndexOf('ClientCode="')+12,6) + '"'; 
		$row1=$row -replace 'BrokerRef="([^"]*)"', $c;
		$row1 -replace 'ClientCode="([^"]*)"', 'ClientCode="RB331"' | Add-Content $f
		continue
		}
	if ($row -like '*ClientCode="RB0*') 
		{
 
			$c=  'BrokerRef="' + $row.substring($row.IndexOf('ClientCode="')+12,6) + '"'; 
		$row1=$row -replace 'BrokerRef="([^"]*)"', $c | Add-Content $f
		}
	else {echo $row | Add-Content $f }  
	}
}