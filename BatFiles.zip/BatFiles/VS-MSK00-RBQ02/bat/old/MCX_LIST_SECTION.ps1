﻿Invoke-WebRequest "http://www.moex.com/ru/listing/securities-list-csv.aspx?type=2" -Outfile "C:\temp\cot.csv"
$a = Import-Csv "C:\temp\cot.csv" -Delimiter ';' -Encoding default

$conn = New-Object System.Data.SqlClient.SqlConnection
$conn.ConnectionString = "Server=S-MSK01-SQL08\QORT_RENBR;Database=QORT_TDB_PROD;Integrated Security=SSPI;"
Write-Host $conn.open()

$cmd = New-Object System.Data.SqlClient.SqlCommand
$cmd.connection = $conn

$cmd.commandtext = "TRUNCATE TABLE MCX_LIST_SECTION"
$cmd.ExecuteNonQuery()

foreach ($item in $a) 
    {
    if ($item.ISIN -ne '')
    {

    $cmd.commandtext = "INSERT INTO MCX_LIST_SECTION (ISIN,LIST_SECTION,TRADE_CODE) VALUES('{0}','{1}','{2}')" -f
        $item.ISIN, $item.LIST_SECTION, $item.TRADE_CODE
    $cmd.ExecuteNonQuery()
    <#Write-Host $item.ISIN, 
               $item.LIST_SECTION,
               $item.TRADE_CODE
               #>
               }
    }

$cmd.CommandText = "insert into Securities (SecCode, Asset_ShortName, TSSection_Name, QuoteList, IsProcessed, ET_Const)
SELECT 
s.SecCode,
a.ShortName,
tss.Name,
replace(replace(replace(m.LIST_SECTION, 'Первый уровень', 10), 'Второй уровень', 11), 'Третий уровень', 12),
1,
4

  FROM [QORT_TDB_PROD].[dbo].[MCX_LIST_SECTION] m 
  inner join QORT_DB_PROD..Assets a
	on a.ISIN = m.ISIN
  inner join QORT_DB_PROD..Securities s 
    on s.Asset_ID = a.id
  inner join QORT_DB_PROD..TSSections tss
		on tss.id = s.TSSection_ID
  where replace(replace(replace(m.LIST_SECTION, 'Первый уровень', 10), 'Второй уровень', 11), 'Третий уровень', 12) <> s.QuoteList
  and s.Enabled = 0
  and a.Enabled = 0
"

$cmd.ExecuteNonQuery()

$conn.close()