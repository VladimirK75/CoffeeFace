﻿Add-PSSnapin Microsoft.Exchange.Management.Powershell.Admin -erroraction silentlyContinue
Add-Type -AssemblyName System.IO.Compression.FileSystem
$Date = (Get-Date).AddDays(-1).ToString("yyyyMMdd")
Write-Host $Date
$zip = [IO.Compression.ZipFile]::OpenRead("\\rencap.com\Files\MSK01-Applications\AppData\RTSReports\FROM_FORTS\FUTOPTMM" + $Date + ".zip")
$entries=$zip.Entries | where {$_.FullName -like '*9717.csv' }
$Dir = "c:\temp\" + $Date

Remove-Item -Path $Dir -recurse
New-Item -ItemType Directory -Path $Dir -Force

$smtpServer = "relay.rencap.com"

$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
$msg.From = "qortmonitoring@rencap.com"
$msg.To.Add("ETGCustomerServices@rencap.com")
$msg.To.Add("aleonov@rencap.com")
$msg.Subject = "FUTOPTMM 9717 files"
$msg.Body = ""

foreach ($file in $entries) 
{
    
    
   
    [IO.Compression.ZipFileExtensions]::ExtractToFile( $file, "c:\temp\" + $Date + "\" + $file.Name) 
    
    $att = new-object Net.Mail.Attachment("c:\temp\" + $Date + "\" + $file.Name)
    $msg.Attachments.Add($att)
    
}

#$file = "C:\temp\test2.xml"


$smtp.Send($msg)
$att.Dispose();
$msg.Dispose()


