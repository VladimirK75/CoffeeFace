﻿$Paths = 'C:\QORT\srvComp\SrvReporter\OutSideClientRequests\','C:\QORT\srvComp\SrvReporter\ClientReports\','C:\QORT\srvComp\SrvReporter\ClientReportsPeriod\'

foreach ($a in $Paths)
{
 Get-ChildItem $a -Recurse | Where-Object {$_.CreationTime -lt (Get-Date).AddDays(-20)} | ForEach-Object `
 {
   Remove-Item -Path $_.FullName -Force
 }
}