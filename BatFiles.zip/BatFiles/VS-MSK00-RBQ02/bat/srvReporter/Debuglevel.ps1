﻿$Reporterini  = "C:\QORT\srvComp\SrvReporter\Starter.ini"
$content =  [System.IO.File]::ReadAllText($Reporterini,[text.encoding]::Default) -Replace 'DebugLevel=1','DebugLevel=8'
[System.IO.File]::WriteAllText($Reporterini,$content,[text.encoding]::Default)
TIMEOUT /T 1800 /NOBREAK
$content =  [System.IO.File]::ReadAllText($Reporterini,[text.encoding]::Default) -Replace 'DebugLevel=8','DebugLevel=1'
[System.IO.File]::WriteAllText($Reporterini,$content,[text.encoding]::Default)


