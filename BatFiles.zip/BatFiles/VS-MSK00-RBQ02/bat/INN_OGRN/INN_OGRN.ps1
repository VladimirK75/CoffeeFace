﻿$Url     = 'http://www.cbr.ru'
$7Zip    = "C:\Program Files\7-Zip\7z.exe"
#$OutPath = 'G:\ForAll\nik\'
$OutPath = $PSScriptRoot

Try
{
  Get-ChildItem $OutPath -Include *.xlsx,*.rar -Recurse | ForEach-Object `
  {
    Remove-Item $_.FullName -Force
  }
  
  $HTML     = Invoke-WebRequest -Uri ($Url+'/registries/rcb/inn_ogrn/') -UseBasicParsing
  $LinkList = $HTML.Links | Where-Object { $_.href -match 'Collection' } | Select-Object -ExpandProperty href
  $FileName = Split-Path -Path $LinkList[0] -Leaf 
  Invoke-WebRequest -Uri ($Url+$LinkList[0]) -OutFile ($OutPath+'\'+$FileName)
  &$7Zip e ($OutPath+'\'+$FileName) -o"$OutPath"
}
Finally
{
  If ($Error)
  {
    Get-Date | Out-File "$OutPath\INN_OGRN.log" -Append
    $Error | Out-File "$OutPath\INN_OGRN_ERROR.log" -Append
  }
}