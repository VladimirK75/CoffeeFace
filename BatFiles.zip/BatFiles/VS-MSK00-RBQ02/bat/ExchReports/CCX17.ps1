﻿$yyyyMM  = (Get-Date).ToString("yyyy-MM")
$ddMMyy  = (Get-Date).ToString("ddMMyy")
$TargetDir = 'C:\bat\ExchReports\MMVB\SELT\CCX17'


Get-ChildItem $TargetDir | Remove-Item -Force

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*CCX17*$ddMMyy*.xml" | ForEach-Object `
{
  Copy-Item $_.FullName $TargetDir
}
