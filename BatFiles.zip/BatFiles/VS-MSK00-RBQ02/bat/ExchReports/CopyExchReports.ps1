﻿$7Zip            = "C:\Program Files\7-Zip\7z.exe"
$MMBVMMonth      = (Get-Date).ToString('yyyy-MM')
$MMBVMDate       = (Get-Date).ToString('ddMMyy')
$FORTSDate       = 'FO'+(Get-Date).ToString('yyyyMMdd')+'_2.zip'
$FromFORTSDir    = "\\rencap.com\Files\MSK01-Applications\AppData\RTSReports\FROM_FORTS\$FORTSDate"
$ToFORTSDir      = "C:\bat\ExchReports\FORTS\"
$FromMMVBExchDir = "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$MMBVMMonth\"
$ToMMVBExchDir   = "C:\bat\ExchReports\MMVB\"
#$BrokerPath      = 'C:\bat\ExchReports\replace_broker_ref.ps1'
#$FORTSName       = 'FO20180321_2.zip'

# Удаляем вчерашние файлы
$yyyy    = (Get-Date).ToString('yyyy')
$MM      = (Get-Date).ToString('MM')
$dd      = (Get-Date).ToString('dd')
$Time    = [DateTime] "$MM/$dd/$yyyy 9:00 PM"
$CurTime = Get-Date
if($CurTime -lt $Time)
{ 
  Get-ChildItem $ToFORTSDir     -Recurse -File  | ForEach-Object {Remove-Item $_.FullName -Force}
  Get-ChildItem $ToMMVBExchDir  -Recurse -File  | ForEach-Object {Remove-Item $_.FullName -Force}
}

Copy-Item $FromFORTSDir -Destination $ToFORTSDir
& $7Zip e ($ToFORTSDir+$FORTSName) -o "$ToFORTSDir"
Get-ChildItem $ToFORTSDir "moncb*.csv" | ForEach-Object {Remove-Item $_.FullName -Force}

<#
Get-ChildItem $FromMMVBExchDir | Where-Object {$_.Name -match $MMBVMDate} | ForEach-Object {Copy-Item $_.FullName -Destination $ToMMVBExchDir\Temp}
#Get-ChildItem $ToMMVBExchDir *SEM03* | ForEach-Object {Move-Item $_.FullName -Destination "$ToMMVBExchDir\Temp"}
#Get-ChildItem $ToMMVBExchDir *SEM02* | ForEach-Object {Move-Item $_.FullName -Destination "$ToMMVBExchDir\Temp"}
#Get-ChildItem $ToMMVBExchDir *CUX23* | ForEach-Object {Move-Item $_.FullName -Destination "$ToMMVBExchDir\Temp"}

Get-ChildItem $ToMMVBExchDir\Temp\ -Recurse  -Exclude '*_SEM03*.xml','*_SEM02*.xml','*_CUX23*.xml' | ForEach-Object `
{
  Copy-Item $_.FullName "$ToMMVBExchDir"
}

if (!(Test-Path $ToMMVBExchDir\* -Include *_SEM03*.xml))
{
  C:\bat\ExchReports\replace_broker_ref.ps1 $ToMMVBExchDir\Temp\*SEM03*.xml $ToMMVBExchDir
}

if (!(Test-Path $ToMMVBExchDir\* -Include *_SEM02*.xml))
{
  C:\bat\ExchReports\replace_broker_ref.ps1 $ToMMVBExchDir\Temp\*SEM02*.xml $ToMMVBExchDir
}
#>


