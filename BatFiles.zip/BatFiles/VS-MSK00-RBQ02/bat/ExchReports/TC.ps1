﻿Param(
       [Parameter(Mandatory = $False, Position = 0)]
       [Int32]$TaskID = 0
     )


Function Send-Telegram
{ 
  Param(
         [String]$Token 
        ,[String]$ChatId
        ,[String]$Text
       )
   $PayLoad = @{ "parse_mode" = "Markdown"; "disable_web_page_preview" = "True" }
   $URL     = "https://api.telegram.org/bot$Token/sendMessage?chat_id=$ChatId&text=$Text"
   $Request = Invoke-WebRequest -Uri $URL -Method Post `
              -ContentType "application/json; charset=utf-8" `
              -Body (ConvertTo-Json -Compress -InputObject $PayLoad) `
              -Proxy 'http://lon3.sme.zscaler.net:80'
}

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $SqlConnection.Close()
  Return $DataSet 
}

$TODAY     = Get-Date -Format yyyyMMdd
$TelChatID = Select-String -Path "C:\bat\Telegram\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
$SqlQuery  = 
@"
select top 1 sr.ReiterationName,sl.log
from ScheduleLogs sl
inner join ScheduleTasks st on st.id = sl.ScheduleTask_ID 
inner join ScheduleReiterations sr ON sr.id = st.ScheduleReiteration_ID
where 1=1
and sl.StartDate = $TODAY
and st.id IN ($TaskID)
Order by sl.id desc
"@
$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
#$Sql = $SqlData.Tables.rows

foreach ($srt in $SqlData.Tables.rows)
{
  $Text = $srt.ReiterationName +"`n"+($srt.log).Split(':')[0]
  $Text = $Text -replace "_", '-'
  [int]$Desc = $Text | Select-String -Pattern 'Найдено (\d+)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
  if($Text -match "FORTS")
  {
    if($Text -notmatch "Сверка с 5 отчетами")
    {
      $Text = $Text.Insert(0,"*ERROR: Сверка не с 5 отчетами*"+"`n")
    }
  }
  if($Desc -ge 100)
  {
    $Text = $Text.Insert(0,"*ERROR: Очень много расхождений*"+"`n")
  }
  Foreach ($a in $TelChatID)
  {    
    Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "$Text";
  }
}