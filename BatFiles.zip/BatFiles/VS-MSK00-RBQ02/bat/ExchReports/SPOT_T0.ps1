﻿$yyyyMM  = ((Get-Date).AddDays(-1)).ToString("yyyy-MM")
$ddMMyy  = ((Get-Date).AddDays(-1)).ToString("ddMMyy")
Get-ChildItem  "C:\bat\ExchReports\MMVB\SPOT\T0\*.xml" -Recurse | Remove-Item -Force
Get-ChildItem  "C:\bat\ExchReports\MMVB\SPOT\T0\*.txt" -Recurse | Remove-Item -Force

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*SEM03*$ddMMyy*.xml" | % `
{
  #Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\Temp\"
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\SEM03"
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*EQM24*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\EQM24\"
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*EQM06*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\EQM06\"
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*EQM6C*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\EQM6C\"
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*SEM21*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\SEM21\"
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*EQM3T*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\EQM3T\"
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*SEM02*$ddMMyy*.xml" | % `
{
  #Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\Temp\"
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\SEM02"
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*SEM2T*$ddMMyy*.txt" | % `
{
  Copy-Item $_.FullName "C:\bat\ExchReports\MMVB\SPOT\T0\SEM2T\"
}


#C:\bat\ExchReports\replace_broker_ref.ps1 C:\bat\ExchReports\MMVB\SPOT\T0\Temp\*SEM03*.xml C:\bat\ExchReports\MMVB\SPOT\T0\SEM03\
#C:\bat\ExchReports\replace_broker_ref.ps1 C:\bat\ExchReports\MMVB\SPOT\T0\Temp\*SEM02*.xml C:\bat\ExchReports\MMVB\SPOT\T0\SEM02\

