﻿$7Zip            = "C:\Program Files\7-Zip\7z.exe"
$FORTSDate       = 'FO'+(Get-Date).ToString('yyyyMMdd')+'_2.zip'
$FromFORTSDir    = "\\rencap.com\Files\MSK01-Applications\AppData\RTSReports\FROM_FORTS\$FORTSDate"
$ToFORTSDir      = "\\VS-MSK00-RBQ01\c$\bat\ExchReports\FORTS\"


Function Send-Telegram
{ 
  Param(
         [String]$Token 
        ,[String]$ChatId
        ,[String]$Text
       )
   $PayLoad = @{ "parse_mode" = "Markdown"; "disable_web_page_preview" = "True" }
   $URL     = "https://api.telegram.org/bot$Token/sendMessage?chat_id=$ChatId&text=$Text"
   $Request = Invoke-WebRequest -Uri $URL -Method Post `
              -ContentType "application/json; charset=utf-8" `
              -Body (ConvertTo-Json -Compress -InputObject $PayLoad) 

}



#Get-ChildItem $ToFORTSDir -Recurse -File  | ForEach-Object {Remove-Item $_.FullName -Force}


# Количество попыток
$Count = 5
Do
{
  Copy-Item $FromFORTSDir -Destination $ToFORTSDir -ErrorAction SilentlyContinue  
  Write-Host 'OK'
  TIMEOUT /T 2 /NOBREAK
  $Count = $Count - 1
}
While (!(Test-Path $FromFORTSDir) -and $Count -ne 0)

$TelChatID = Select-String -Path "C:\bat\Telegram\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
if($Count -eq 0)
{
  Foreach ($a in $TelChatID)
    {
      Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR We don't have FORTS files"
    }  
}


if (Test-Path $ToFORTSDir+$FORTSDate)
{
  & $7Zip e ($ToFORTSDir+$FORTSName) -o "$ToFORTSDir" -ErrorAction SilentlyContinue
  Get-ChildItem $ToFORTSDir "moncb*.csv" | ForEach-Object {Remove-Item $_.FullName -Force}
}


