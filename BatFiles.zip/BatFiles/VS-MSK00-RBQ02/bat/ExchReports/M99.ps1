﻿$yyyyMM  = ((Get-Date).AddDays(-1)).ToString("yyyy-MM")
$ddMMyy  = ((Get-Date).AddDays(-1)).ToString("ddMMyy")
Get-ChildItem  "C:\bat\ExchReports\MMVB\SELT\*.xml" -Recurse | Remove-Item -Force

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*CUX23*$ddMMyy*.xml" | % `
{
#Copy-Item $_.FullName C:\bat\ExchReports\MMVB\SELT\Temp\
 Copy-Item $_.FullName C:\bat\ExchReports\MMVB\SELT\CUX23\
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*CCX123*$ddMMyy*.xml" | % `
{
  #Copy-Item $_.FullName C:\bat\ExchReports\MMVB\SELT\Temp\
  Copy-Item $_.FullName C:\bat\ExchReports\MMVB\SELT\CCX123\
}

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*CUX16*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName C:\bat\ExchReports\MMVB\SELT\CUX16\
}


Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*CCX03*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName C:\bat\ExchReports\MMVB\SELT\CCX03\
}

#C:\bat\ExchReports\replace_broker_ref.ps1 C:\bat\ExchReports\MMVB\SELT\Temp\*CUX23*.xml C:\bat\ExchReports\MMVB\SELT\CUX23\
#C:\bat\ExchReports\replace_broker_ref.ps1 C:\bat\ExchReports\MMVB\SELT\Temp\*CCX123*.xml C:\bat\ExchReports\MMVB\SELT\CCX123\


Get-ChildItem "C:\bat\ExchReports\MMVB\SELT\CUX23\*CUX23_ADD*.xml"
{
 Move-Item $_.FullName "C:\bat\ExchReports\MMVB\SELT\CUX23_ADD\"
}



