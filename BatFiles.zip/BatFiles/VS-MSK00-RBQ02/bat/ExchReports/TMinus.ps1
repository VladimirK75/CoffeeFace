﻿Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


Function Get-Workday
{
  Param(
       [DateTime]$Date
        )
  If($Date.DayOfWeek -in "Saturday","Sunday")
  {
    if($Date.ToString('yyyyMMdd') -in $OutItems)
    {
      return $True
    }
    else
    {
      return $False
    }     
  }
  else
  {
    if($Date.ToString('yyyyMMdd') -notin $OutItems)
    {
      return $True
    }
    else
    {
      return $False
    }
  }  
}

Function Last-Workday
{
  Param(
       [Int32]$Num
       )
  $Cnt   = 0
  $Date2 = (Get-Date).AddDays(-1)
  Do
  {
    If(Get-Workday $Date2)
    {
      $Cnt = $Cnt + 1
      if($Cnt -ne $Num)
      {
        $Date2 = $Date2.AddDays(-1)
      }
    }
    else
    {
      $Date2 = $Date2.AddDays(-1)
    }
  }
  While($Cnt -ne $Num)
  return $Date2
}

$SqlQuery  = 
@"
SELECT [date]
FROM QORT_DB_PROD..CalendarDates with(nolock)
WHERE Calendar_ID = 5
"@
$SqlData  = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB'
$OutItems = New-Object System.Collections.Generic.List[System.Object]
foreach ($row in $SqlData.Tables.Rows)
{
  $OutItems.Add($row[0].ToString())
}


$T1 = Last-Workday 1
$T2 = Last-Workday 2
$MMBVMMonthOne = ($T1).ToString('yyyy-MM')
$MMBVMDateOne  = ($T1).ToString('ddMMyy')
$MMBVMMonthTwo = ($T2 ).ToString('yyyy-MM')
$MMBVMDateTwo  = ($T2 ).ToString('ddMMyy')


$ReportPath = '\\rencap.com\files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\'

Get-ChildItem "C:\bat\ExchReports\MMVB\SPOT\T1" -Recurse -File | ForEach-Object {Remove-Item $_.FullName -Force}
Get-ChildItem $ReportPath\$MMBVMMonthOne\ -Recurse -Include  "*_SEM03*$MMBVMDateOne*.xml","*_CUX23*$MMBVMDateOne*.xml","*_SEM02*$MMBVMDateOne*.xml" | ForEach-Object `
{
 #Copy-Item $_.FullName -Destination "C:\bat\ExchReports\MMVB\SPOT\T1\TEMP\"
 Copy-Item $_.FullName -Destination "C:\bat\ExchReports\MMVB\SPOT\T1\"
}

#C:\bat\ExchReports\replace_broker_ref.ps1 "C:\bat\ExchReports\MMVB\SPOT\T1\TEMP\*SEM03*.xml" "C:\bat\ExchReports\MMVB\SPOT\T1"
#C:\bat\ExchReports\replace_broker_ref.ps1 "C:\bat\ExchReports\MMVB\SPOT\T1\TEMP\*CUX23*.xml" "C:\bat\ExchReports\MMVB\SPOT\T1"
#C:\bat\ExchReports\replace_broker_ref.ps1 "C:\bat\ExchReports\MMVB\SPOT\T1\TEMP\*SEM02*.xml" "C:\bat\ExchReports\MMVB\SPOT\T1"

Get-ChildItem "C:\bat\ExchReports\MMVB\SPOT\T2" -Recurse -File | ForEach-Object {Remove-Item $_.FullName -Force}
Get-ChildItem $ReportPath\$MMBVMMonthTwo\ -Recurse -Include  "*_SEM03*$MMBVMDateTwo*.xml","*_CUX23*$MMBVMDateTwo*.xml","*_SEM02*$MMBVMDateTwo*.xml" | ForEach-Object `
{
 #Copy-Item $_.FullName -Destination "C:\bat\ExchReports\MMVB\SPOT\T2\TEMP\"
 Copy-Item $_.FullName -Destination "C:\bat\ExchReports\MMVB\SPOT\T2\"
}
#C:\bat\ExchReports\replace_broker_ref.ps1 "C:\bat\ExchReports\MMVB\SPOT\T2\TEMP\*SEM03*.xml" "C:\bat\ExchReports\MMVB\SPOT\T2"
#C:\bat\ExchReports\replace_broker_ref.ps1 "C:\bat\ExchReports\MMVB\SPOT\T2\TEMP\*CUX23*.xml" "C:\bat\ExchReports\MMVB\SPOT\T2"
#C:\bat\ExchReports\replace_broker_ref.ps1 "C:\bat\ExchReports\MMVB\SPOT\T2\TEMP\*SEM02*.xml" "C:\bat\ExchReports\MMVB\SPOT\T2"
 
