﻿Import-Module Pscx

$pcsx = Get-ChildItem C:\Windows\System32\WindowsPowerShell\v1.0\Modules\Pscx

$newfoldername=20150710
$destination = "C:\LOG\" + $newfoldername + "\"
cd C:\LOG\$newfoldername\server


#Зададим имя архива
$zipfilename = "server_" + $newfoldername + ".zip"

#Создадим архив
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvCommissioner
$zipfilename = "SrvCommissioner_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvPositioner
$zipfilename = "SrvPositioner_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\srvQUIK
$zipfilename = "srvQUIK_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\srvQUIKCETS
$zipfilename = "srvQUIKCETS_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvReporter
$zipfilename = "SrvReporter_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvRisks
$zipfilename = "SrvRisks_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\srvTDB
$zipfilename = "srvTDB_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd c:\LOG

#Remove-Item C:\LOG\$newfoldername\* -recurse -exclude *.zip -force

