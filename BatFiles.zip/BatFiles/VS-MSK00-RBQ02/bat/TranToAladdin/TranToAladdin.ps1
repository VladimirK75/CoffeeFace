﻿$Log="C:\bat\TranToAladdin\TranToAladdin.log"

Try
{
$Date       = ((Get-Date).AddDays(-1)).ToString('yyyyMMdd')
$SqlDate    = ((Get-Date).AddDays(-1)).ToString('yyyy-MM-dd')
$Time       = Get-Date -Format HHmmss
#TargetPath = "D:\Tmp\46\QUIK_ALADDIN_RENBR_$Date"+"_$Date"+"_$Time"
#$TargetPath ="C:\temp\QUIK_ALADDIN_RENBR_$Date"+"_$Date"+"_$Time"
#$TargetPath ="\\rencap.com\files\MSK01-Applications\Calypso to Aladdin Instructions\RENBR\Stock trades input\QUIK_ALADDIN_RENBR_$Date"+"_$Date"+"_$Time"
$TargetPath ="\\rencap.com\files\MSK01-Applications\Calypso to Aladdin Instructions\RENBR\Stock trades input\QUIK_ALADDIN_RENBR_$Date"+"_$Date"+"_$Time"


$SQLQuery2 =
@"
declare
       @TradeDate datetime = '$SqlDate'
select [1] = 'RENBR'
     , [2] = 'RENBR'
     , [3] = convert(varchar, t.TradeDate, 101)
     , [4] = case t.Account
                  when 'L04+00000F02' then '7100006RES01'
                  when 'L04-00000F02' then '7100006RES01'
                  when 'L04b00000F02' then '7100006RES05' /* as made in Calypso 05 */
                  when 'L05+00000F01' then '7100006RES01'
                  when 'L05-00000F01' then '7100006RES01'
                  when 'L05b00000F01' then '7100006RES03' /* as made in Calypso 03 */
                  when 'L05x00000F01' then '7100006RES04' /* as made in Calypso 04 */
                  when 'L17+00000F08' then '7100006RES01'
                  when 'L22+00000F10' then 'RB00331RES01'
                  when 'L22b00000F10' then 'RB00331RES05' /* as made in Calypso 05 */
                  when 'L22x00000F10' then 'RB00331RES04' /* as made in Calypso 04 */
                  when 'L20+00000FUX' then 'RB00447RES01'
		  when 'L34+00000F19' then '7100006RES01'
                else '<' + t.Account + '>'
             end
     , [5] = case t.Account
                  when 'L04+00000F02' then 'HL1212130369/36MC0089500000F02'
                  when 'L04b00000F02' then 'HB1512160055/8LMC0089500000F02'
                  when 'L05+00000F01' then 'HL1212130369/36MC0089500000F01'
                  when 'L05-00000F01' then 'HL1212130369/31MC0089500000F01'
                  when 'L05x00000F01' then 'HX1512160077/8LMC0089500000F01'
                  when 'L05b00000F01' then 'HB1512160055/8LMC0089500000F01'
                  when 'L22+00000F10' then 'HL1212130369/36MC0089500000F10'
                  when 'L22b00000F10' then 'HB1512160055/8LMC0089500000F10'
                  when 'L22x00000F10' then 'HX1512160077/8LMC0089500000F10'
                  when 'L19+00000FDH' then 'HL1212130369/36MC0089500000FDH'
                  when 'L20+00000FUX' then 'HL1212130369/36MC0089500000FUX'
                  when 'L21+00000F09' then 'HL1212130369/36MC0089500000F09'
		  when 'L34+00000F19' then 'HL1212130369/36MC0089500000F19'
                  when 'S02+00000FRB' then 'HS1212130162/36MC0089500000FRB'
                  when 'S02x00000FRB' then 'HX1512160077/8SMC0089500000FRB'
                  when 'S03+00000FDP' then 'HS1212130162/36MC0089500000FDP'
                  when 'S03-00000FDP' then 'HS1212130162/31MC0089500000FDP'
                  when 'S03b00000FDP' then 'HB1512160055/8SMC0089500000FDP'
                else '<' + t.Account + '>'
             end
     , [6] = 'MICEX Main'
     , [7] = t.OrderNum
     , [8] = case t.Sell
                  when 0 then 'B'
                else 'S'
             end
     , [9] = convert(varchar, cast(Qty as money), 1)
     , [10] = isnull(sec.ISINCode, iif(patindex('GCTR', t.ClassCode) > 0, t.SecCode, ''))
     , [11] = isnull(sec.RegNumber, iif(patindex('GCTR', t.ClassCode) > 0, t.SecCode, ''))
     , [12] = case
                   when t.SecCode = 'IRAO' then 'IRAOS'
                   when t.SecCode = 'RUAL' then 'RUALM'
                   when t.SecCode = 'POGR' then 'PEHML'
                   when t.SecCode = 'RIG' then 'RIGUS'
                   when t.SecCode = 'FTI' then 'FTIUS'
                 else t.SecCode
              end
       /* , [13] = isnull(sec.ISINCode, '')*/
     , [13] = case
                   when t.SecCode = 'RUAL' then 'RU000A1025V3'
                   when t.SecCode = 'IRAO' then 'TECS/04'
                   when t.SecCode = 'POGR' then '014750495'
                   when t.SecCode = 'RIG' then 'RIG'
                   when t.SecCode = 'FTI' then 'GB00BDSFG982'
                 else isnull(sec.ISINCode, iif(patindex('GCTR', t.ClassCode) > 0, t.SecCode, ''))
              end
     , [14] = convert(varchar, cast(Value as money), 1)
     , [15] = case TradeCurrency
                   when 'EUR' then '978'
                   when 'GBP' then '826'
                   when 'SUR' then '643'
                   when 'RUR' then '643'
                   when 'USD' then '840'
                 else '643'
              end
     , [16] = 'NKCKB'
     , [17] = isnull(t.ClearingFirmId, iif(patindex('GCTR', t.ClassCode) > 0, t.FirmId, ''))
     , [18] = 'NEW'
     , [19] = ''
     , [20] = t.TradeNum
     , [21] = convert(varchar, t.SettleDate, 101)
       /*     , [22] = +'QK'+ltrim(str(TradeNum))*/
     , [22] = concat('QK', TradeNum)
  from Trades_History t with(nolock)
  inner join Securities_History sec with(nolock) on t.SecCode = sec.SecCode
                                                    and t.ClassName = sec.ClassName
                                                    and t.TradeDate = sec.TradeDate
  left join SecDepoAccount sdacc with(nolock) on sdacc.TrdAccId = t.Account
                                                 and sdacc.LoadDate = t.TradeDate
                                                 and sdacc.SecCode = t.SecCode
 where 1 = 1
       and t.tradedate = @TradeDate
       and abs(isnull(qty, 0)) > 0 /*- without cash transfer*/
       and patindex('TRAN', t.ClassCode) + patindex('GCTR', t.ClassCode) > 0
       and t.Account not in ('S05+00000FRC', 'S02+00000FRB', 'S02-00000FRB', 'S02x00000FRB', 'S02b00000FRB', 'S03+00000FDP', 'S03-00000FDP', 'S03b00000FDP', 'F01+00000F00')
 /* exclude list is more comfortable to support */
 /*and t.Account in('L04+00000F02', 'L04-00000F02', 'L04b00000F02', 'L05+00000F01', 'L05-00000F01', 'L05b00000F01', 'L05x00000F01', 'L17+00000F08', 'L22+00000F10', 'L22b00000F10', 'L22x00000F10', 'L19+00000FDH', 'L20+00000FUX', 'L21+00000F09', 'S02+00000FRB', 'S02-00000FRB', 'S02x00000FRB', 'S02b00000FRB', 'S03+00000FDP', 'S03-00000FDP', 'S03b00000FDP')*/ 
 order by t.TradeNum
"@

  $SqlData = Invoke-Sqlcmd -Query $SQLQuery2 -ServerInstance '10.1.110.73' -Database 'QExport' -Username 'SvcActimize' -Password 'SvcRead123'
  if ($SqlData.Count -ne 0)
  {
      $SqlData | ForEach-Object `
    {
              $_.1  + ';'+
              $_.2  + ';'+
              $_.3  + ';'+
              $_.4  + ';'+
              $_.5  + ';'+
              $_.6  + ';'+
              $_.7  + ';'+
              $_.8  + ';'+
              $_.9  + ';'+
              $_.10 + ';'+
              $_.11 + ';'+
              $_.12 + ';'+
              $_.13 + ';'+
              $_.14 + ';'+
              $_.15 + ';'+
              $_.16 + ';'+
              $_.17 + ';'+
              $_.18 + ';'+
              $_.19 + ';'+
              $_.20 + ';'+
              $_.21 + ';'+
              $_.22
    } | Out-File "$TargetPath.csv" -Encoding default
  }  

}
Finally
{
  If ($Error) 
  { 
    '{0}{1}' -f (Get-Date -Format 'yyyyMMdd'),(" - ERROR") | Out-File $Log -Append
    $Error | Out-File $Log -Append
  } 
  Else
  {    
    '{0}{1}' -f (Get-Date -Format 'yyyyMMdd'),(" - OK") | Out-File $Log -Append
  }
}