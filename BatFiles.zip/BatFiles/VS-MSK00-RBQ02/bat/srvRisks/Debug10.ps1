﻿$SrvRisks  = "C:\QORT\srvComp\srvRisks\Starter.ini"
$content =  [System.IO.File]::ReadAllText($SrvRisks,[text.encoding]::Default) -Replace 'DebugLevel=1','DebugLevel=10'
[System.IO.File]::WriteAllText($SrvRisks,$content,[text.encoding]::Default)


