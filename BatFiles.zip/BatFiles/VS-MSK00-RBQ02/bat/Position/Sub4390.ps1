﻿$SQLquery   = 'select * from Position with (nolock) where 1=1 and Subacc_ID = 4390'
$7Zip       = "C:\Program Files\7-Zip\7z.exe"
$Date       = (Get-Date).ToString('yyyyMMdd')
$TargetPath = 'C:\bat\Position\'+$Date+'_Rez.csv'

Invoke-Sqlcmd -query $SQLquery -serverinstance msk00-sql08-rb -database QORT_DB_PROD -Username 'QORT' -Password 'QORTDB' | Export-Csv $TargetPath -Delimiter ";" -NoTypeInformation

&$7Zip a -sdel ('C:\bat\Position\Archive'+'.zip') $TargetPath