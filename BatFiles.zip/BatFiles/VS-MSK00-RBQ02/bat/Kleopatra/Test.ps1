﻿$Sourse      = "E:\Logs\"
$OpenKey     = "C:\bat\Kleopatra\qort_renbr.asc"
$AzureStor   = "https://staweu01col01rencap.blob.core.windows.net/backups/QORT_LOGS/QORT_RENBR"
$AzSASkey    = "?sv=2016-05-31&ss=b&srt=sco&sp=rwdlac&se=2025-01-09T21:51:48Z&st=2017-03-10T13:51:48Z&spr=https&sig=Nn34CnCk%2BYu42VEO1pSYQK6AacEr2xvZvpieiN1K1PY%3D"
$Azcopy      = "C:\Program Files (x86)\Microsoft SDKs\Azure\AzCopy\AzCopy.exe"

Get-ChildItem $Sourse  -Recurse  |  % `
{
 $SourcePath  =  $_.DirectoryName
 $DestPath    =  ($AzureStor+'/'+$_.Directory.Name)
 &$Azcopy  /Source:$SourcePath /Dest:$DestPath  /DestSAS:$AzSASkey /S
 #echo "staweu01col01rencap.blo"+($_.Directory.Name)
}

&$Azcopy /Source:C:\temp\Test /Dest:https://staweu01col01rencap.blob.core.windows.net/backups/QORT_LOGS/QORT_RENBR/Test /DestSAS:"?sv=2016-05-31&ss=b&srt=sco&sp=rwdlac&se=2025-01-09T21:51:48Z&st=2017-03-10T13:51:48Z&spr=https&sig=Nn34CnCk%2BYu42VEO1pSYQK6AacEr2xvZvpieiN1K1PY%3D" /S


Get-ChildItem $Sourse  -Recurse -File *.zip | % `
{
 $_.DirectoryName
 $_.Directory.Name
}


Get-ChildItem $Sourse  -Recurse -File *.zip |  % `
{
 #Azcopy /Source:$_.DirectoryName /Dest:$AzureStor+""
 echo ('/Source:'+$_.DirectoryName) ('/Dest:'+$AzureStor+'/'+$_.Directory.Name) ('/DestSAS:'+$AzureStor)

}

Get-ChildItem $Sourse  -Recurse -File *.gpg | ForEach-Object `
{
  #echo ($_.DirectoryName+'\'+$_.BaseName+'.gpg')
  #gpg --always-trust --yes  -e -r qort_renbr $_.FullName
  #If (Test-Path ($_.FullName+'.gpg'))
  #{
    #Remove-Item $_.FullName
    $SourcePath  =  $_.DirectoryName
    $DestPath    =  ($AzureStor+'/'+$_.Directory.Name)
    $GPGName     =  ($_.Name)
    &$Azcopy  /Source:$SourcePath /Dest:$DestPath  /DestSAS:$AzSASkey /Pattern:$GPGName
    #Remove-Item $_.FullName
  #}

}

&$Azcopy /Source:$SourcePath /Dest:$DestPath /DestSAS:$AzSASkey /S

Get-ChildItem $Sourse  -Recurse -File | % {$_.Name}