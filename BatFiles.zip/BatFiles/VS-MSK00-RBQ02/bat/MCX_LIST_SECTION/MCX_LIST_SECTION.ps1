﻿$ErrorActionPreference = "Stop" 

Try
{
  If (!(Get-EventLog -LogName Application -Source "MCX_LIST_SECTION" -ErrorAction SilentlyContinue))
  {
    New-EventLog -LogName Application -Source "MCX_LIST_SECTION"
  }
  
  $Log = "C:\bat\MCX_LIST_SECTION\mcx_list_section.log"
  Invoke-WebRequest "http://www.moex.com/ru/listing/securities-list-csv.aspx?type=2" -Outfile "C:\bat\MCX_LIST_SECTION\cot.csv"
  $a = Import-Csv "C:\bat\MCX_LIST_SECTION\cot.csv" -Delimiter ';' -Encoding default
  
  $conn = New-Object System.Data.SqlClient.SqlConnection
  $conn.ConnectionString = "Server=MSK00-SQL08-RB;Database=QORT_TDB_PROD;Integrated Security=SSPI;"
  Write-Host $conn.open()
  
  $cmd = New-Object System.Data.SqlClient.SqlCommand
  $cmd.connection = $conn
  
  $cmd.commandtext = "TRUNCATE TABLE MCX_LIST_SECTION"
  $cmd.ExecuteNonQuery()
   
  foreach ($item in $a) 
      {
      if ($item.ISIN -ne '')
      {
  
      $cmd.commandtext = "INSERT INTO MCX_LIST_SECTION (ISIN,LIST_SECTION,TRADE_CODE) VALUES('{0}','{1}','{2}')" -f
          $item.ISIN, $item.LIST_SECTION, $item.TRADE_CODE
      $cmd.ExecuteNonQuery()
      <#Write-Host $item.ISIN, 
                 $item.LIST_SECTION,
                 $item.TRADE_CODE
                 #>
                 }
      }
  
  $cmd.CommandText = "
  
  if (select count(*) from [MCX_LIST_SECTION]) > 100
  insert into Securities (SecCode, Asset_ShortName, TSSection_Name, QuoteList, IsProcessed, ET_Const)
  select s.SecCode, a.ShortName, tss.Name, 5, 1, 4 from QORT_DB_PROD..Securities s
  inner join QORT_DB_PROD..Assets a
    on a.id = s.Asset_ID
  inner join QORT_DB_PROD..TSSections tss
    on s.TSSection_ID = tss.id
  left join [MCX_LIST_SECTION] mls
    on mls.ISIN = a.ISIN
  where s.QuoteList <> 5
  and s.Enabled = 0
  and a.Enabled = 0
  and a.AssetClass_Const not in (3,4)
  and mls.ISIN is null
  
  insert into Securities (SecCode, Asset_ShortName, TSSection_Name, QuoteList, IsProcessed, ET_Const)
  SELECT 
  s.SecCode,
  a.ShortName,
  tss.Name,
  replace(replace(replace(m.LIST_SECTION, 'Первый уровень', 10), 'Второй уровень', 11), 'Третий уровень', 12),
  1,
  4
  
    FROM [QORT_TDB_PROD].[dbo].[MCX_LIST_SECTION] m 
    inner join QORT_DB_PROD..Assets a
      on a.ISIN = m.ISIN
    inner join QORT_DB_PROD..Securities s 
      on s.Asset_ID = a.id
    inner join QORT_DB_PROD..TSSections tss
      on tss.id = s.TSSection_ID
    where replace(replace(replace(m.LIST_SECTION, 'Первый уровень', 10), 'Второй уровень', 11), 'Третий уровень', 12) <> s.QuoteList
    and s.Enabled = 0
    and a.Enabled = 0
  "
  
  $cmd.ExecuteNonQuery()
  
  $conn.close()
}
Finally
{
  If ($Error) 
  { 
    Write-EventLog -LogName Application -Source "MCX_LIST_SECTION" -EntryType Information -EventId 1 -Message "MCX_LIST_SECTION Error"
	'{0}{1}' -f (Get-Date -Format 'yyyyMMdd'),(" - ERROR") | Out-File $Log -Append
    $Error | Out-File $Log -Append
  } 
  Else
  {    
    Write-EventLog -LogName Application -Source "MCX_LIST_SECTION" -EntryType Information -EventId 2 -Message "MCX_LIST_SECTION Ok"
	'{0}{1}' -f (Get-Date -Format 'yyyyMMdd'),(" - OK") | Out-File $Log -Append
  }
}
