﻿$SoursePath = "C:\GRDBServices\"
$7Zip       = "C:\Program Files\7-Zip\7z.exe"



#Get-ChildItem $SoursePath -Recurse | Where-Object {$_.Name -match "(\d+)-(\d+)-(\d+).*txt" -and $_.Extension -eq '.txt' } | % `
#Get-ChildItem $SoursePath -Recurse | Where-Object {$_.Name -match "ServiceLog 2018-08-09 13-04.txt" -and $_.Extension -eq '.txt' } | % `
Get-ChildItem $SoursePath -Recurse  | Where-Object {$_.Name -match "(\d+)-(\d+)-(\d+).*txt" -and $_.Extension -eq '.txt' -and $_.LastWriteTime -le ((Get-Date).AddMinutes(-15))} | % `
{
 $FullName      = $_.FullName
 $DirectoryName = $_.DirectoryName
 $BaseName      = $_.BaseName
 $TragetPath    = ($DirectoryName+"\Logs\"+$BaseName+".zip") 
 #$TragetPath 
 #$FullName
 #((Get-Date).AddMinutes(-15))
 #$_.LastWriteTime
 &$7Zip a -sdel $TragetPath $FullName
 Test-Path($TragetPath)
 {
    Remuve-Item $FullName
 }
}