﻿#Requires -RunAsAdministrator
<#
Скрипипт пренозначен для бекапа логов QORT.
Альтернативное использование мало вероятно.

Как запустить в Echo Off?

Добавить описание отсновных блоков


#> 



Param(
       [Parameter(Mandatory = $False, Position = 0)]
       [String]$SourseDir = 'C:\QORT\', # Откуда
       [Parameter(Mandatory = $False, Position = 1)]
       [String]$TargetDir = 'C:\Log\', # Куда копируем
       [Parameter(Mandatory = $False, Position = 2)]
       [Int32]$Slash = 1, # после какого слеша забираем путь из $SourseDir
       [Parameter(Mandatory = $False, Position = 3)]
       [Int32]$Ini = 1, # 1 - бекап ini-файлов ; 0 - без копирования
	   [Int32]$Dmp = 1, # 1 - бекап dmp-файлов ; 0 - без копирования
       [Parameter(Mandatory = $False, Position = 4)]
       [Int32]$OldLogs = 0, # Удаление логов. Ставь 0, если не нужно удлать старые директории с логами из $TargetDir
                            # Так же есть проверка, что имя ПК содержит UAT
       [Parameter(Mandatory = $False, Position = 5)]
       [Int32]$EventLog = 1  # Нужно ли записать разультат работы скрипта в EvaentLog Windows.
	                         # На EvaentLog легко можно натравить zabbix, и отслеживать результат выполения выполнения скрипта.
							 # 1 - Да ; 0 - Нет
     )


$ErrorActionPreference = "Continue" # В случае ошибки, выполнение скрипта останавливается/продолжается
<#
Stop
Inquire
Continue
SilentlyContinue
#>
Try
{       
  $SourseDir     = $SourseDir.TrimEnd('\')
  $SourseDir     = "$SourseDir\"
  $TargetDir     = $TargetDir.TrimEnd('\')
  $TargetDir     = "$TargetDir\"
  $ErrorLog      = "$PSScriptRoot\ArchErrorLog.log" # Пусть к файлу логов, по умолчанию текущме расположение скрипта
  $OD            = (Get-Date).ToString('yyyyMMdd')
  #$PositionerLog = "C:\QORT\srvComp\SrvPositioner\srvPositioner_$OD.log"
  $PositionerLog = "$SourseDir"+"srvComp\SrvPositioner\srvPositioner_$OD.log"
  $7Zip          = "C:\Program Files\7-Zip\7z.exe"
  
  If ($SourseDir -notmatch 'QORT'){Write-Error "SourseDir variable must match QORT"} # В пути $SourseDir должно быть слово QORT
  $a = $SourseDir,$TargetDir,$7Zip  # Проверяем валидность путей
  Foreach ($srt in $a)
  {
    If (Test-Path $srt)
    {}
    Else
    {
      Write-Error " Path $srt is not valid"
    }
  }
  
  #ini-Files blok Не зависит от ОД
  If ($Ini -eq 1)
  {
    Get-ChildItem $SourseDir *.ini -Recurse | ForEach-Object `
    {
      $NewTarget = ("$TargetDir"+(Get-Date).ToString("yyyMMdd")+'\'+([string]::Join('\',$_.DirectoryName.Split('\')[$Slash..10000]))+'\')
      If (!(Test-Path $NewTarget))
      {
        New-Item -ItemType "Directory" -Path $NewTarget
      }
      Copy-Item $_.FullName -Destination $NewTarget -Force   
    }
  }
  
  # Архивация логов  
  If (Test-Path $PositionerLog) # Если текущий лог позиционера равен текущему ОД
     {
       Get-ChildItem $SourseDir *.log -Recurse -Exclude "*$OD.log" | Where-Object {$_.Name -match '\d{8}'} | ForEach-Object `
       {
         $FullName  = $_.FullName
         $BaseName  = $_.BaseName
         $DirPath   = $_.DirectoryName
         $Nextlog   = (Get-Date).ToString("yyyyMMddHHmmss")
         $LogDate   = $_.Name | Select-String -Pattern "(\d{8})" | ForEach-Object {($_.Matches[0].groups[1].Value)}
         $NewTarget = ($TargetDir+"$LogDate\"+([string]::Join('\',$DirPath.Split('\')[$Slash..10000]))+'\')   
         If (!(Test-Path $NewTarget)) # Если путь из переменной $NewTarget не существует
         {
           New-Item -ItemType "Directory" -Path $NewTarget
		   $NewName = ($BaseName+'_'+$Nextlog+'.log')
		   Rename-Item $FullName -NewName $NewName	
           &$7Zip a -mx1 ($NewTarget+$BaseName+'.zip') ("$DirPath\"+$NewName)
		   if (Test-Path ($NewTarget+$BaseName+'.zip'))
		   {
		     Remove-Item -Path ($NewTarget+$BaseName+'.zip')
		   }
           # a     Добавить в архив
           # -sdel Удалить после добавления		   
         }
         Else 
         {
           If(Test-Path ($NewTarget+$BaseName+'.zip'))
           {
             $NewName = ($BaseName+'_'+$Nextlog+'.log')
             Rename-Item $FullName -NewName $NewName
             &$7Zip a -sdel -mx1  ($NewTarget+$BaseName+'.zip') ("$DirPath\"+$NewName)
           }
           Else
           {
             $NewName = ($BaseName+'_'+$Nextlog+'.log')
			 Rename-Item $FullName -NewName $NewName	
			 &$7Zip a -sdel -mx1  ($NewTarget+$BaseName+'.zip') ("$DirPath\"+$NewName)
           }
         }
       }
     }
  
  # Архивация dmp
  If ($Dmp -eq 1)
  {
    Get-ChildItem $SourseDir *.dmp -Recurse | ForEach-Object `
	{
      $FullName  = $_.FullName
      $BaseName  = $_.BaseName
      $DirPath   = $_.DirectoryName
      $LogDate   = $_.Name | Select-String -Pattern "(\d{8})" | ForEach-Object {($_.Matches[0].groups[1].Value)}
      $NewTarget = ($TargetDir+"$LogDate\"+([string]::Join('\',$DirPath.Split('\')[$Slash..10000]))+'\')   
      If (!(Test-Path $NewTarget))
      {
         New-Item -ItemType "Directory" -Path $NewTarget
         &$7Zip a -sdel -mx1  ($NewTarget+$BaseName+'.zip') $FullName
         # a     Добавить в архив
         # -sdel Удалить после добавления	
      }
      Else
      {
        &$7Zip a -sdel -mx1  ($NewTarget+$BaseName+'.zip') $FullName
        # a     Добавить в архив
        # -sdel Удалить после добавления
      }
    }
  }
  #Удаляем старые логи
  If ((Get-WmiObject -Class Win32_ComputerSystem -Property Name).Name -match 'UAT') # Проверка, что имя ПК содержит UAT
  {
    Get-ChildItem $TargetDir -Directory | Where-Object {$_.Name -match '^\d{8}$'} | ForEach-Object `
    {
      $LogDay = ([datetime]::parseexact($_.Name,"yyyyMMdd",[System.Globalization.CultureInfo]::InvariantCulture))
      If ($LogDay -lt (Get-Date).AddDays($OldLogs) -and (Get-Date).AddDays($OldLogs) -lt (Get-Date))
      {
        Remove-Item -Path $_.FullName -Recurse -Force
      }
    }
  }
}
Finally
{
  If($EventLog -eq 1)
  {
    If (Get-EventLog -LogName Application -Source "ArchQortLog" -ErrorAction SilentlyContinue)
	{
	  If($Error)
	  {
	    Write-EventLog -LogName Application -Source "ArchQortLog" -EntryType Information -EventId 1 -Message "ArchQortLog Error"
		(Get-Date).ToString('dd.MM.yyyy HH:mm:ss') | Out-File $ErrorLog -Append
		$Error | Format-List -Property * -Force    | Out-File $ErrorLog -Append		
	  }
	  Else
	  {
	    Write-EventLog -LogName Application -Source "ArchQortLog" -EntryType Information -EventId 2 -Message "ArchQortLog OK"
	  }
	}
	Else
	{
	  New-EventLog -LogName Application -Source "ArchQortLog"
	  If($Error)
	  {
	    Write-EventLog -LogName Application -Source "ArchQortLog" -EntryType Information -EventId 1 -Message "ArchQortLog Error"
		(Get-Date).ToString('dd.MM.yyyy HH:mm:ss') | Out-File $ErrorLog -Append
		$Error | Format-List -Property * -Force    | Out-File $ErrorLog -Append
	  }
	  Else
	  {
	    Write-EventLog -LogName Application -Source "ArchQortLog" -EntryType Information -EventId 2 -Message "ArchQortLog OK"
	  }
	}
  }
  Else
  {
    If($Error)
    {
      (Get-Date).ToString('dd.MM.yyyy HH:mm:ss') | Out-File $ErrorLog -Append
      $Error | Format-List -Property * -Force    | Out-File $ErrorLog -Append
    }
  } 
}

