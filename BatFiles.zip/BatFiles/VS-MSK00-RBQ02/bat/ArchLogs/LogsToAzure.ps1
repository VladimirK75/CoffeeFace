﻿$7Zip  = "C:\Program Files\7-Zip\7z.exe"
$Sourse  = "C:\Log\"
$OpenKey = "C:\bat\Kleopatra\qort_renbr.asc"
$SourceStorageAccount = "staweu01col01rencap"
$SourceStorageKey = '?sv=2016-05-31&ss=b&srt=sco&sp=rwdlac&se=2025-01-09T21:51:48Z&st=2017-03-10T13:51:48Z&spr=https&sig=Nn34CnCk%2BYu42VEO1pSYQK6AacEr2xvZvpieiN1K1PY%3D'
$SourceStorageContext = New-AzureStorageContext –StorageAccountName $SourceStorageAccount -SasToken $SourceStorageKey
gpg --import $OpenKey


#Get-ChildItem $Sourse -Directory |  select Name, LastWriteTime
Get-ChildItem $Sourse -Directory | Where-Object {$_.LastWriteTime -le (Get-Date).AddDays(-30)} | ForEach-Object `
{

         $FullName     = $_.FullName
         $BaseName     = $_.BaseName
         $date = [datetime]::ParseExact($BaseName,'yyyyMMdd',$null)
         $date = $date.ToString("yyyy-M-d")
         #($Sourse+$date+' - '+$BaseName+'.zip')
         $ZipName = ($Sourse+$date+' - '+$BaseName+'.zip')
         &$7Zip a -sdel $ZipName $FullName
         If (Test-Path $ZipName)
         {
           Remove-Item $FullName -Recurse -Force
         }

         gpg --always-trust --yes  -e -r qort_renbr $ZipName
         If (Test-Path ($ZipName+'.gpg'))
         {
          Echo $ZipName
          Remove-Item $ZipName -Force
         }

         Get-ChildItem ($ZipName+'.gpg') | ForEach-Object `
         {
           $Name     = $_.Name
           $Len      = $_.Length
           $FileName = $_.FullName 
           $Blob = Get-AzureStorageBlob -Context $SourceStorageContext -Container 'backups' -Blob "Retention5years/VS-MSK00-RBQ02/RENBR/$Name"
           if($Blob)
           {
            $Name = $Name -replace '.zip.gpg' , ('-'+(Get-Date).ToString("yyyyMMddHHmmss")+'.zip.gpg')
           }

           Set-AzureStorageBlobContent -Context $SourceStorageContext -File $FileName -Container "backups" -Blob "Retention5years/VS-MSK00-RBQ02/RENBR/$Name"
           $Blob = Get-AzureStorageBlob -Context $SourceStorageContext -Container 'backups' -Blob "Retention5years/VS-MSK00-RBQ02/RENBR/$Name"
           If ($Len -eq $Blob.Length)
           {
             Remove-Item $FileName -Force
             Echo $FileName
           }          
         }
}