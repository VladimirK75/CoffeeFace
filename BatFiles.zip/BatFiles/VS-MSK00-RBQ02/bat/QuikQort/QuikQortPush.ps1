$TelChatID = Select-String -Path "C:\bat\Pushover\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
$SqlQuery  = "SELECT * FROM QQ_Renbr WITH(NOLOCK)"
$CURLEXE   = 'C:\bat\QuikQort\curl.exe'

Add-Type -Path "C:\bat\QuikQort\NReco.ImageGenerator.dll"
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")



Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlData = Select-Sql "VS-WEU00-SQL09\RPT" "ReportsData"  $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
$SqlData.Tables.rows | ConvertTo-Html  -Property tradedate,quikclasscode,clientcode,security_code,QUIK_sum_renbr,QORT_sum_renbr -As Table > "$PSScriptRoot\discrepancy.htm" -CssUri "$PSScriptRoot\HtmlCss.css"


$html = Get-Content $PSScriptRoot\discrepancy.htm
$h2image = new-object NReco.ImageGenerator.HtmlToImageConverter
$imageFormat = [NReco.ImageGenerator.ImageFormat]::Jpeg
$jpeg = $h2image.generateImage($html, $imageformat)
$dataStream = New-Object System.IO.MemoryStream(,$jpeg)
$img = [System.Drawing.Image]::FromStream($dataStream)
$svg = $PSScriptRoot+'\Image.jpg'
$img.save($svg)


If ($SqlData.Tables.Rows.Count -ne 0)
{
  Foreach ($a in $TelChatID)
  {
    #Send-TelMessage "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR Quik-Qort trades discrepancy $Disc"
	#Send-TelPicture "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR Quik-Qort trades discrepancy $Disc" "$PSScriptRoot\Image.jpg"
	&$CURLEXE -k -s --form-string 'token=aj4yvf7pdqxh3cyo1w7d86f7u2qdys' --form-string "user=$a" --form-string "message=<b>$Disc</b>" --form-string "html=1" --form-string "title=PROBLEM:RENBR Quik-Qort trades discrepancy" -F "attachment=@C:\bat\QuikQort\Image.jpg;filename=Image" 'https://api.pushover.net/1/messages.json'
  }
}
Else
{
  Foreach ($a in $TelChatID)
  {
    $Day = Get-Date -Format yyyyMMdd
	#Send-TelMessage "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "OK:RENBR $Day Quik-Qort trades discrepancy"
	#Send-TelPicture "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR Quik-Qort trades discrepancy $Disc" "$PSScriptRoot\Image.jpg"
	&$CURLEXE -k -s --form-string 'token=aj4yvf7pdqxh3cyo1w7d86f7u2qdys' --form-string "user=$a" --form-string "message=$Day Quik-Qort trades discrepancy" --form-string "html=1" --form-string "title=OK:RENBR Quik-Qort trades discrepancy" 'https://api.pushover.net/1/messages.json'
  }
}
