﻿$TelChatID = Select-String -Path "C:\bat\Telegram\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
$SqlQuery  = "SELECT * FROM QQ_Renbr WITH(NOLOCK)"

Function Send-Telegram
{ 
  Param(
         [String]$Token 
        ,[String]$ChatId
        ,[String]$Text
       )
   $PayLoad = @{ "parse_mode" = "Markdown"; "disable_web_page_preview" = "True" }
   $URL = "https://api.telegram.org/bot$Token/sendMessage?chat_id=$ChatId&text=$Text"
   $Request = Invoke-WebRequest -Uri $URL -Method Post `
              -ContentType "application/json; charset=utf-8" `
              -Body (ConvertTo-Json -Compress -InputObject $PayLoad) 

}

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}

$SqlData = Select-Sql "VS-WEU00-SQL09\RPT" "ReportsData"  $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}

If ($SqlData.Tables.Rows.Count -ne 0)
{
  Foreach ($a in $TelChatID)
  {
    Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR Quik-Qort trades discrepancy $Disc"
  }
}