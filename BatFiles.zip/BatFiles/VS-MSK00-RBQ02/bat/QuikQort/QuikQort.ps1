$TelChatID = Select-String -Path "C:\bat\Telegram\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
$SqlQuery  = "SELECT * FROM QQ_Renbr WITH(NOLOCK)"

Add-Type -Path "C:\bat\Telegram\Newtonsoft.Json.dll"
Add-Type -Path "C:\bat\Telegram\NetTelegramBotApi.dll"
Add-Type -Path "C:\bat\Telegram\NReco.ImageGenerator.dll"
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

Function Send-TelMessage
{ 
  Param(
         [String]$Token 
        ,[String]$ChatId
        ,[String]$Text
       )
   $bot =  New-Object NetTelegramBotApi.TelegramBot($Token)
   $WebProxy = New-Object System.Net.WebProxy("http://lon3.sme.zscaler.net:80",$true)
   $bot.WebProxy = $WebProxy
   $reqAction = New-Object NetTelegramBotApi.Requests.SendMessage($ChatId, $Text);
   $bot.MakeRequestAsync($reqAction).Wait()
}

Function Send-TelPicture
{ 
  Param(
         [String]$Token		 
        ,[String]$ChatId
        ,[String]$Text
		,[String]$ImageFile
       )
  $bot =  New-Object NetTelegramBotApi.TelegramBot($Token)
  $WebProxy = New-Object System.Net.WebProxy("http://lon3.sme.zscaler.net:80",$true)
  $bot.WebProxy = $WebProxy	   
  $fileStream = [System.IO.File]::OpenRead($ImageFile)
  $req = New-Object NetTelegramBotApi.Requests.SendPhoto($ChatId,$( New-Object NetTelegramBotApi.Requests.FileToSend($fileStream, "Telegram_logo.png")))
  $req.Caption = $Text
  $msg = $bot.MakeRequestAsync($req).Result;
  $uploadedPhotoId = $msg.Photo[$msg.Photo.Count -1].FileId
  $fileStream.close()
}

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlData = Select-Sql "VS-WEU00-SQL09\RPT" "ReportsData"  $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
$SqlData.Tables.rows | ConvertTo-Html  -Property tradedate,quikclasscode,clientcode,security_code,QUIK_sum_renbr,QORT_sum_renbr -As Table > "$PSScriptRoot\discrepancy.htm" -CssUri "$PSScriptRoot\HtmlCss.css"


$html = Get-Content $PSScriptRoot\discrepancy.htm
$h2image = new-object NReco.ImageGenerator.HtmlToImageConverter
$imageFormat = [NReco.ImageGenerator.ImageFormat]::Jpeg
$jpeg = $h2image.generateImage($html, $imageformat)
$dataStream = New-Object System.IO.MemoryStream(,$jpeg)
$img = [System.Drawing.Image]::FromStream($dataStream)
$svg = $PSScriptRoot+'\Image.jpg'
$img.save($svg)


If ($SqlData.Tables.Rows.Count -ne 0)
{
  Foreach ($a in $TelChatID)
  {
    #Send-TelMessage "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR Quik-Qort trades discrepancy $Disc"
	Send-TelPicture "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR Quik-Qort trades discrepancy $Disc" "$PSScriptRoot\Image.jpg"
  }
}
Else
{
  Foreach ($a in $TelChatID)
  {
    $Day = Get-Date -Format yyyyMMdd
	Send-TelMessage "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "OK:RENBR $Day Quik-Qort trades discrepancy"
	#Send-TelPicture "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:RENBR Quik-Qort trades discrepancy $Disc" "$PSScriptRoot\Image.jpg"
  }
}
