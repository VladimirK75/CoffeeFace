﻿Get-Service *quik* | % `
{
 Stop-Service $_.Name 
 Set-Service $_.Name -StartupType Disabled 
}