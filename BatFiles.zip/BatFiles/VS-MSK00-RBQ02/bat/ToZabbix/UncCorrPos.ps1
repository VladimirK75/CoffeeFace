﻿param(

		[Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 90
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
with tmp_transfer(ExternalID)
     as (select concat(its1.ExternalTransactionID, '/', its0.ExternalID)
           from QORT_DDM..ImportedTranSettlement its0 with(nolock)
           inner join QORT_DDM..ImportedTranSettlement its1 with(nolock) on its0.ExternalID = its1.ExternalID
                                                                            and its1.DdmStatus <> 'Cancelled'
          where its0.DdmStatus = 'Cancelled'
                and its0.EventDateTime > '2019-10-10'
                and datediff(hh, its0.EventDateTime, getdate()) > 1
          group by concat(its1.ExternalTransactionID, '/', its0.ExternalID))
     select BackID = tt.ExternalID
       from tmp_transfer tt
      where 1 = 1
            and exists (select 1
                          from QORT_DB_PROD..CorrectPositions cp with(nolock)
                         where 1 = 1
                               and cp.BackID like ExternalID
                               and cp.RegistrationDate > 20171000
                               and cp.IsCanceled = 'n')
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result