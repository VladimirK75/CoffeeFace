﻿param(

		[Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 7
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select sd.id
from QORT_DDM..ImportedTranSettlement s with (nolock, index=I_ImportedTranSettlement_ProcessingState)
inner join  QORT_DDM..ImportedTranSettlementDetails sd with (nolock)
on s.ID = sd.SettlementID
and not exists (select 1 from QORT_DDM..ImportedTranSettlement its2 with(nolock)
                    where its2.ExternalID = s.ExternalID
                    and its2.Version > s.Version)	
where 1=1
and sd.ProcessingState like 'erroron%'
and sd.AuditdateTime >= GETDATE()-$Period  
and patindex('%deadlock%',sd.ProcessingMessage) >0

UNION

select  sd.id
from QORT_DDM..ImportedTradeSettlement s with (nolock)
inner join  QORT_DDM..ImportedTradeSettlementDetails sd with (nolock, index=I_ImportedTradeSettlementDetails_SettlementID_ProcessingState)
on s.ID = sd.SettlementID
and not exists (select 1 from QORT_DDM..ImportedTradeSettlement its2 with(nolock)
                    where its2.ExternalID = s.ExternalID
                    and its2.Version > s.Version)	
where 1=1
and sd.ProcessingState like 'erroron%'
and s.EventDateTime >= GETDATE()-$Period  
and patindex('%deadlock%',sd.ProcessingMessage) >0
"@
$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DDM" $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result