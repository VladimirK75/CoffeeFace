﻿param(

        [Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 6
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select tor.ProcessingState, tor.ProcessingMessage, tor.status, tor.ID, tor.ExternalID,AuditDateTime
  from QORT_DDM..TradeOrders tor with(nolock)
where 1=1
--and id = 29647
and datediff(day, tor.AuditdateTime, getdate()) < $Period  
and isnull(tor.ProcessingState, '') <> 'Processed'
and tor.Status <> 'Cancelled'
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DDM" $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result