Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select COUNT(*) as Cnt
from QORT_DB_PROD..Trades with (nolock)
where 1=1
and TradeDate = [dbo].[fn_qort_getdate](GETDATE())
and [dbo].[fn_getTimeFromInt](created_time) >= CONVERT (time, (SELECT DATEADD(MINUTE,-10,GETDATE())))
and QUIKClassCode != ''
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$SqlData.Tables.Rows.cnt