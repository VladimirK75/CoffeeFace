﻿<#
15.08.2017 - Александр PadreRamirez Никишин footman.ru@gmail.com

Скрипт содежит 3 параметра
1. Какой тип кросс-курса мы хотим мониторить
   По умолчанию CollateralRate
2. Нужли ли при этом учитывать календарь.
   По умолчанию 1, т.е используем.
   Календарь зашит в запросе $SqlQuery WHERE Calendar_ID = 5.
   Т.е всегда Calendar_ID = 5
3. Парамерт влияет на дату в формате -T+ за которую нужно проверить кросс-курс.
   По умолчанию равен 0
Сам скрипт делает запос к БД и позврящает 0 - если все хорошо, 1 - если все плохо.
В какую БД и с какими парамрами выполнять запрос зашито в функции Select-Sql и передается с параметрами.
#>

Param(
       [Parameter(Mandatory = $False, Position = 0)]
       [String]$CurrType = 'CollateralRate',
       [Parameter(Mandatory = $False, Position = 1)]
       [Int32]$Calendar = 1,
       [Parameter(Mandatory = $False, Position = 2)]
       [Int32]$TPlus = 0
     )

$DayOfWeek = (Get-Date).DayOfWeek
$Day       = ((Get-Date).AddDays($TPlus)).ToString("yyyyMMdd")
$OutItems  = New-Object System.Collections.Generic.List[System.Object]
$Result    = 0

$SqlQuery  = 
@"
SELECT [date]
FROM QORT_DB_PROD..CalendarDates with(nolock)
WHERE Calendar_ID = 5
"@
$SqlQuery2 = 
@"
SELECT *
FROM QORT_TDB_PROD..CrossRates with(nolock)
WHERE 1=1
AND InfoSource = '$CurrType' 
AND Date = $Day
AND Ask != 0
AND Bid != 0
"@
Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


If($Calendar) # С календарем
{
  $SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB'
  foreach ($row in $SqlData.Tables.Rows)
  {
    $OutItems.Add($row[0].ToString())
  }

  If($DayOfWeek -in "Saturday","Sunday") # Суббота Воскресение
  {
    If($Day -in $OutItems) # Если выходной является рабочим днем
    {
      $SqlData2  = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery2 'QORT' 'QORTDB'
      $CountRows = $SqlData2.Tables.date.Count
      If ($CountRows -eq 0)
      {
        $Result = 1
        Return $Result
      }
	  Else
	  {
	    Return $Result
	  }
    }
    Else
     {
       Return $Result 
     }
  }
  Else # Все остальные дни
  {
    If($Day -in $OutItems) # Если рабочий день выходной
    {
      Return $Result
    }
    Else # Если рабочий день не выходной
    { 
      $SqlData2  = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery2 'QORT' 'QORTDB'
      $CountRows = $SqlData2.Tables.date.Count
      If ($CountRows -eq 0)
      {
        $Result = 1
        Return $Result
      }
	  Else 
	  {
	    Return $Result
	  }
    }
  }
}
Else # Без календаря
{
  $SqlData2  = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery2 'QORT' 'QORTDB'
  $CountRows = $SqlData2.Tables.date.Count
  If ($CountRows -eq 0)
  {
    $Result = 1
    Return $Result
  }
  Else 
  {
    Return $Result
  }
}