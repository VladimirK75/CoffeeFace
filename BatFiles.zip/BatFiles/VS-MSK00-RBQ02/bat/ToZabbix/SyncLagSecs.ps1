﻿Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $SqlConnection.Close()
  Return $DataSet 
}


$SqlQuery  = 
@"
;WITH UpTime AS
                      (
                      SELECT DATEDIFF(SECOND,create_date,GETDATE()) [upTime_secs]
                      FROM sys.databases
                      WHERE name = 'tempdb'
                      ),
       AG_Stats AS 
                      (
                      SELECT AR.replica_server_name,
                                HARS.role_desc, 
                                Db_name(DRS.database_id) [DBName], 
                                CAST(DRS.log_send_queue_size AS DECIMAL(19,2)) log_send_queue_size_KB, 
                                (CAST(perf.cntr_value AS DECIMAL(19,2)) / CAST(UpTime.upTime_secs AS DECIMAL(19,2))) / CAST(1024 AS DECIMAL(19,2)) [log_KB_flushed_per_sec]
                      FROM   sys.dm_hadr_database_replica_states DRS 
                      INNER JOIN sys.availability_replicas AR ON DRS.replica_id = AR.replica_id 
                      INNER JOIN sys.dm_hadr_availability_replica_states HARS ON AR.group_id = HARS.group_id 
                             AND AR.replica_id = HARS.replica_id 
                      --I am calculating this as an average over the entire time that the instance has been online.
                      --To capture a smaller, more recent window, you will need to:
                      --1. Store the counter value.
                      --2. Wait N seconds.
                      --3. Recheck counter value.
                      --4. Divide the difference between the two checks by N.
                      INNER JOIN sys.dm_os_performance_counters perf ON perf.instance_name = Db_name(DRS.database_id)
                             AND perf.counter_name like 'Log Bytes Flushed/sec%'
                      CROSS APPLY UpTime
                      ),
       Pri_CommitTime AS 
                      (
                      SELECT replica_server_name
                                    , DBName
                                    , [log_KB_flushed_per_sec]
                      FROM   AG_Stats
                      WHERE  role_desc = 'PRIMARY'
                      ),
       Sec_CommitTime AS 
                      (
                      SELECT replica_server_name
                                    , DBName
                                    --Send queue will be NULL if secondary is not online and synchronizing
                                    , log_send_queue_size_KB
                      FROM   AG_Stats
                      WHERE  role_desc = 'SECONDARY'
                      )
SELECT p.replica_server_name [primary_replica]
       , p.[DBName] AS [DatabaseName]
       , s.replica_server_name [secondary_replica]
       , CAST(s.log_send_queue_size_KB / p.[log_KB_flushed_per_sec] AS BIGINT) [Sync_Lag_Secs]
FROM Pri_CommitTime p
LEFT JOIN Sec_CommitTime s ON [s].[DBName] = [p].[DBName]

"@




$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB'


write-host -NoNewline "{"
write-host -NoNewline " `"data`":["
#write-host

$n = 0
foreach ($objItem in $SqlData.Tables.Rows) {
 $n = $n + 1
 #$line =  "{`"{#PID}`":`"" +$objItem.ProcessId + `"{#PID}`":`""}"
 $DatabaseName = $objItem.DatabaseName
 $SyncLagSecs = $objItem.Sync_Lag_Secs
 $line=@"
{"{#DATABASENAME}": "$DatabaseName" , "{#SYNCLAGSECS}": "$SyncLagSecs"}
"@
 If ($n -lt $SqlData.Tables.Rows.Count ) { $line = "$line,"}
 write-host -NoNewline $line
}

#write-host
write-host -NoNewline " ]"
write-host -NoNewline "}"
#write-host