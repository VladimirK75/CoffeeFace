Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select *
from Trades with (nolock) 
where 1=1
and TradeDate = (CONVERT(varchar(8),GETDATE(), 112))
and IsProcessed = 'n'
and replace(convert(varchar, getdate(), 14),':','') - created_time > 1000000
and Enabled = 0
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result