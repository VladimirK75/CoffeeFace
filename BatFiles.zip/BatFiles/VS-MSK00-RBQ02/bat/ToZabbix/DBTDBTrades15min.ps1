Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select
--*
COUNT(*) as Cnt
--dbt.* 
--top 10 [dbo].[fn_getTimeFromInt](modified_time),modified_time,*
from QORT_DB_PROD..Trades dbt with (nolock)
where 1=1
and modified_date = [dbo].[fn_qort_getdate](GETDATE())
and IsProcessed = 'y'
and [dbo].[fn_getTimeFromInt](modified_time) <= CONVERT (time, (SELECT DATEADD(MINUTE,-15,GETDATE())))
and not exists (select null from QORT_TDB_PROD..Trades tdbt with (nolock) where 1=1 and tdbt.SystemID = dbt.id and dbt.modified_date = tdbt.ModifiedDate and dbt.modified_time = tdbt.ModifiedTime)
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$SqlData.Tables.Rows.cnt