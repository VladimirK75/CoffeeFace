Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
SELECT COUNT(*) 
FROM QORT_TDB_PROD..DataAlerts_Atom daa with (nolock) 
inner join QORT_TDB_PROD..Trades t with (nolock) on t.id = daa.Record_ID 
WHERE 1=1 
and isprocessed < 2 
and tc_const = 1 
and TradeDate = CONVERT(varchar(8),GETDATE(),112)
and QORT_TDB_PROD.dbo.fn_getTimeFromInt(TradeTime) < CONVERT(TIME, DATEADD (MINUTE,-5,GETDATE()))
and RecordStatus = 0

"@
$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$SqlData.Tables.Rows.Column1