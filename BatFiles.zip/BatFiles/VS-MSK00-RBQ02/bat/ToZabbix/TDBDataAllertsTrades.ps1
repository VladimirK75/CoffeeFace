$SQLServer = "MSK00-SQL08-RB" #use Server\Instance for named SQL instances! 
$SQLDBName = "QORT_TDB_PROD"
$SqlQuery = "select COUNT(*) from QORT_TDB_PROD..DataAlerts_Atom daa with (nolock) inner join QORT_TDB_PROD..Trades t with (nolock) on t.id = daa.Record_ID where 1=1 and isprocessed = 2 and tc_const = 1 and TradeDate = convert(varchar(8),getdate(),112) and RecordStatus = 0"


$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; uid=QORT; pwd=QORTDB; Database = $SQLDBName;MultiSubnetFailover=true; Integrated Security = False"

$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection

$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd

$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)

$SqlConnection.Close()

foreach ($row in $DataSet.Tables.Rows)
 
{
 
$Count = $row[0].ToString()
 
}

& c:\bat\tozabbix\zabbix_sender.exe -c c:\zabbixagent\zabbix_agentd.conf -k TDBDataAllertsTrades -o $Count

