﻿# Мониторинг даты исполнения корректировок TDB/DB
# При импоре корректировок через EAI может возникнуть следующая ситуация
# В процессе обработки TDB корерктировки (Isprocessed = 2) приходит update даты исполения
# Но так как записть уже обрабатывается, то полсе обработки просталяется (Isprocessed = 3) и update не проходит

param(

		[Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 14
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select 'QORT Renbr' as QORT, Cor_DB.BackID, Cor_DB.RegistrationDate, Cor_DB.date as DB_Date, Cor_TDB.date as TDB_Date
from QORT_DB_PROD.dbo.CorrectPositions Cor_DB with (nolock) 
                left join QORT_TDB_PROD.dbo.CorrectPositions Cor_TDB with (nolock) on Cor_DB.BackID = Cor_TDB.BackID
where Cor_DB.RegistrationDate > convert(char(8), GETDATE() -$Period, 112)
  and Cor_TDB.RegistrationDate > convert(char(8), GETDATE() -$Period, 112)
  and Cor_DB.IsCanceled = 'n'
  and Cor_TDB.IsProcessed = 3
  and Cor_DB.date = 0
  and (Cor_TDB.date is not null and Cor_TDB.date <> 0)
"@
$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result