﻿param(

		[Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 90
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select ISIN,Marking,RegistrationCode,*
from QORT_DB_PROD..Assets with (nolock)
where ISIN in
(
select ISIN
from QORT_DB_PROD..Assets with (nolock)
where 1=1
and Enabled = 0
and ShortName not like '%OLD%'
and AssetSort_Const not in (17,18,19)
and id not in (71296,71280,71293) -- Мегаисключение(костыль) 71296 RU000A0F5UN3 OGK5 | 71280 RU000A0JPNM1 IRAO | 71293 RU000A0JRAF8 NMOS
and ISIN not in ('***','','N/A')
GROUP BY ISIN
HAVING COUNT(*) > 1
)
and Marking = RegistrationCode
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result