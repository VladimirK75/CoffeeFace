#
# LastModifiedFile.ps1
#

param(
        [Parameter(Mandatory = $False, Position = 0)]
		[string]$Path        = 'C:\qort\srvComponents\srvTDB\srvTDB_*.log',
		[Parameter(Mandatory = $False, Position = 1)]
        [Int32]$Interaval     = 10
     )

$StartDate = (Get-Date)
$LastWriteTime = Get-ChildItem $Path | Sort {$_.LastWriteTime} | select -last 1 | ForEach-Object {$_.LastWriteTime}
if (($StartDate - $LastWriteTime).TotalMinutes -gt $Interaval) 
{
  $Result = 1
}
else 
{
  $Result = 0
}
$Result