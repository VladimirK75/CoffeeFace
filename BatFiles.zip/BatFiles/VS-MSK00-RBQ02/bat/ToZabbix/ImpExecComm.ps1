Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandTimeout = 120
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select count(*) as total
from QORT_TDB_PROD..ImportExecutionCommands nolock
where IsProcessed<3
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$SqlData.Tables.Rows.total