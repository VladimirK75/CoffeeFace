﻿$SourseDir = 'C:\QORT\'
$TargetDir = '\\VS-MSK00-RBQ02\c$\Log\'
$7Zip          = "C:\Program Files\7-Zip\7z.exe"
$Slash = 1



Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $SqlConnection.Close()
  Return $DataSet 
}


$SqlQuery  = "SELECT TOP 1 Day FROM OperationDays WITH(NOLOCK) ORDER BY Day DESC"
$SqlData   = Select-Sql "MSK00-SQL08-RB" "QORT_DB_PROD" $SqlQuery 'QORT' 'QORTDB'
$OD    = $SqlData.Tables.Rows.Day
$TODAY     = Get-Date -Format yyyyMMdd



  If ($TODAY -eq $OD)
    {
       Get-ChildItem $SourseDir *.log -Recurse -Exclude "*$OD.log" | Where-Object {$_.Name -match '\d{8}'} | ForEach-Object `
       {
         $FullName  = $_.FullName
         $BaseName  = $_.BaseName
         $DirPath   = $_.DirectoryName
         $Nextlog   = (Get-Date).ToString("yyyyMMddHHmmss")
         $LogDate   = $_.Name | Select-String -Pattern "(\d{8})" | ForEach-Object {($_.Matches[0].groups[1].Value)}
         $NewTarget = ($TargetDir+"$LogDate\"+([string]::Join('\',$DirPath.Split('\')[$Slash..10000]))+'\')   
         If (!(Test-Path $NewTarget)) # Если путь из переменной $NewTarget не существует
         {
           New-Item -ItemType "Directory" -Path $NewTarget
		   $NewName = ($BaseName+'_'+$Nextlog+'.log')
		   Rename-Item $FullName -NewName $NewName	
           &$7Zip a -mx1  ($NewTarget+$BaseName+'.zip') ("$DirPath\"+$NewName)
		   if (Test-Path ($NewTarget+$BaseName+'.zip'))
		   {
		     Remove-Item -Path ($NewTarget+$BaseName+'.zip')
		   }
           # a     Добавить в архив
           # -sdel Удалить после добавления		   
         }
         Else 
         {
           If(Test-Path ($NewTarget+$BaseName+'.zip'))
           {
             $NewName = ($BaseName+'_'+$Nextlog+'.log')
             Rename-Item $FullName -NewName $NewName
             &$7Zip a -sdel -mx1  ($NewTarget+$BaseName+'.zip') ("$DirPath\"+$NewName)
           }
           Else
           {
             $NewName = ($BaseName+'_'+$Nextlog+'.log')
			 Rename-Item $FullName -NewName $NewName	
			 &$7Zip a -sdel -mx1  ($NewTarget+$BaseName+'.zip') ("$DirPath\"+$NewName)
           }
         }
       }
       
     }