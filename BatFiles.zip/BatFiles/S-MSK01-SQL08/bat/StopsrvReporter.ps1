Stop-Service QORTsrvReporter -Force
