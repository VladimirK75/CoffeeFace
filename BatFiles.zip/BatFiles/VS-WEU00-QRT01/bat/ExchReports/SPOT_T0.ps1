﻿$yyyyMM  = ((Get-Date).AddDays(-1)).ToString("yyyy-MM")
$ddMMyy  = ((Get-Date).AddDays(-1)).ToString("ddMMyy")
#Get-ChildItem  "C:\bat\ExchReports\MMVB\SPOT\T0\*.xml" -Recurse | Remove-Item -Force

Get-ChildItem "\\rencap.com\Files\MSK01-Applications\AppData\MICEXReports\statements\RENBR\ФБ ММВБ\$yyyyMM\*SEM21*$ddMMyy*.xml" | % `
{
  Copy-Item $_.FullName "C:\QORT\ExchReports\Reports\"
}