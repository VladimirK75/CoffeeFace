﻿$7Zip  = "C:\Program Files\7-Zip\7z.exe"
Get-ChildItem C:\QORT\SrvComp\SrvCommissioner\CommissionsReport\*.xls | % `
{
         $FullName  = $_.FullName
         $BaseName  = $_.BaseName
         $DirPath   = $_.DirectoryName
         $LogDate = $_.Name | Select-String -Pattern "(.....)" | ForEach-Object {($_.Matches[0].groups[1].Value)}
         #$DirPath+'\'+$LogDate+'.zip'
         &$7Zip a -sdel ($DirPath+'\'+$LogDate+'.zip') $FullName
}