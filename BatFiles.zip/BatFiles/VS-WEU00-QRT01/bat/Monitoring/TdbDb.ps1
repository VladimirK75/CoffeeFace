﻿Function Send-Telegram
{ 
  Param(
         [String]$Token 
        ,[String]$ChatId
        ,[String]$Text
       )
   $PayLoad = @{ "parse_mode" = "Markdown"; "disable_web_page_preview" = "True" }
   $URL     = "https://api.telegram.org/bot$Token/sendMessage?chat_id=$ChatId&text=$Text"
   $Request = Invoke-WebRequest -Uri $URL -Method Post `
              -ContentType "application/json; charset=utf-8" `
              -Body (ConvertTo-Json -Compress -InputObject $PayLoad) 

}

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $SqlConnection.Close()
  Return $DataSet 
}

$TelChatID  = Select-String -Path "C:\bat\Telegram\ChatID.txt" -Pattern ':(.*)' -AllMatches | ForEach-Object {($_.Matches[0].groups[1].Value)}
$Date       = ((Get-Date).AddDays(-1)).ToString('yyyyMMdd')
$SqlQuery1  =
@"
select count(*) as Count
from QORT_DB_PROD..trades with (nolock) 
where tradedate = $Date
and IsProcessed = 'y'
and id not in (
                           select systemid 
                           from QORT_TDB_PROD..trades with (nolock) 
                           where tradedate = $Date
                )
"@
$SqlQuery2  = 
@"
select count(*) as Count
from QORT_DB_PROD..Phases with (nolock) 
where PhaseDate = $Date
and InfoSource in ('SYSTEM', 'QUIK', 'MICEX')
and id not in (
                           select systemid 
                           from QORT_TDB_PROD..Phases with (nolock) 
                           where Date = $Date
                           and InfoSource in ('SYSTEM', 'QUIK', 'MICEX')
               )
"@
$SqlQuery3  =
@"
select count(*) as Count
from QORT_TDB_PROD..Phases  with (nolock) 
where Date = $Date
and Iscanceled = 'n'
and systemid in (
                     select id 
                     from QORT_DB_PROD..Phases with (nolock) 
                     where PhaseDate = $Date
                     and Iscanceled = 'y'
                )
"@


$SqlData1 = Select-Sql "QORT_DMA\QORT_DMA" "QORT_DB_PROD"  $SqlQuery1 'QORT' 'QORTDB'
$SqlData2 = Select-Sql "QORT_DMA\QORT_DMA" "QORT_DB_PROD"  $SqlQuery2 'QORT' 'QORTDB'
$SqlData3 = Select-Sql "QORT_DMA\QORT_DMA" "QORT_DB_PROD"  $SqlQuery3 'QORT' 'QORTDB'

if($SqlData1.Tables.rows.Count -eq 0)
{
  Foreach ($a in $TelChatID)
  {
    Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "OK:OFFSHORE $Date  DB-TDB Trades"
  }
}
else
{
  Foreach ($a in $TelChatID)
  {
    $Dif = $SqlData1.Tables.rows.Count
    Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:OFFSHORE $Date DB-TDB Trades discrepancy $Dif"
  }
}

if($SqlData2.Tables.rows.Count -eq 0 -and $SqlData3.Tables.rows.Count -eq 0)
{
  Foreach ($a in $TelChatID)
  {
    Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "OK:OFFSHORE $Date DB-TDB Phases"
  }
}
else
{
  Foreach ($a in $TelChatID)
  {
    $Dif  = $SqlData2.Tables.rows.Count
    $Dif2 = $SqlData3.Tables.rows.Count
    Send-Telegram "149359321:AAHmHflNAGgD24FtlZd8Qen5h7MSvKATL0c" $a "ERROR:OFFSHORE $Date DB-TDB Phases discrepancy $Dif, Iscanceled discrepancy $Dif2"
  }
}