﻿$SrvPositioner  = "C:\QORT\srvComp\SrvPositioner\srvPositioner.ini"
$content =  [System.IO.File]::ReadAllText($SrvPositioner,[text.encoding]::Default) -Replace ';RemoveFPosOnChangeDay=4','RemoveFPosOnChangeDay=4'
[System.IO.File]::WriteAllText($SrvPositioner,$content,[text.encoding]::Default)
Restart-Service QORTsrvPositioner
TIMEOUT /T 7200 /NOBREAK
$content =  [System.IO.File]::ReadAllText($SrvPositioner,[text.encoding]::Default) -Replace 'RemoveFPosOnChangeDay=4',';RemoveFPosOnChangeDay=4'
[System.IO.File]::WriteAllText($SrvPositioner,$content,[text.encoding]::Default)
Restart-Service QORTsrvPositioner

