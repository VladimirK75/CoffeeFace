﻿################################################
#
#Accept any certificates presented by the CAS
#
################################################

## Create a compilation environment
$Provider=New-Object Microsoft.CSharp.CSharpCodeProvider
$Compiler=$Provider.CreateCompiler()
$Params=New-Object System.CodeDom.Compiler.CompilerParameters
$Params.GenerateExecutable=$False
$Params.GenerateInMemory=$True
$Params.IncludeDebugInformation=$False
$Params.ReferencedAssemblies.Add("System.DLL") | Out-Null

$TASource=@'
  namespace Local.ToolkitExtensions.Net.CertificatePolicy{
    public class TrustAll : System.Net.ICertificatePolicy {
      public TrustAll() { 
      }
      public bool CheckValidationResult(System.Net.ServicePoint sp,
        System.Security.Cryptography.X509Certificates.X509Certificate cert, 
        System.Net.WebRequest req, int problem) {
        return true;
      }
    }
  }
'@ 
$TAResults=$Provider.CompileAssemblyFromSource($Params,$TASource)
$TAAssembly=$TAResults.CompiledAssembly

## We now create an instance of the TrustAll and attach it to the ServicePointManager
$TrustAll=$TAAssembly.CreateInstance("Local.ToolkitExtensions.Net.CertificatePolicy.TrustAll")
[System.Net.ServicePointManager]::CertificatePolicy=$TrustAll

################################################
#
#Load the EWS API and connect to the CAS/EWS
# EWS API is found at: http://www.microsoft.com/en-us/download/details.aspx?id=28952
#
################################################

## Load Managed API dll
Add-Type -Path "C:\Program Files\Microsoft\Exchange\Web Services\1.2\Microsoft.Exchange.WebServices.dll"

## Set Exchange Version (Exchange2010, Exchange2010_SP1 or Exchange2010_SP2)
$ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP2

## Create Exchange Service Object
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)

## Set Credentials to use two options are availible Option1 to use explict credentials or Option 2 use the Default (logged On) credentials
#Credentials Option 1 using UPN for the windows Account

$creds = New-Object -TypeName Microsoft.Exchange.WebServices.Data.WebCredentials("svccompliance@rencap.com", "LRVW72$+kdbf", "rencap.com")
$service.Credentials = $creds  

#Credentials Option 2
#service.UseDefaultCredentials = $true

## Set the URL of the CAS (Client Access Server) to use two options are availbe to use Autodiscover to find the CAS URL or Hardcode the CAS to use

$MailboxName = "svccompliance@rencap.com"

#CAS URL Option 1 Autodiscover
#$service.AutodiscoverUrl($MailboxName,{$true})
#"Using CAS Server : " + $Service.url 

#CAS URL Option 2 Hardcoded  
$uri=[system.URI] "https://outlook.office365.com/EWS/Exchange.asmx"
$service.Url = $uri

#Bind to the Inbox folder
$Sfha = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.EmailMessageSchema]::HasAttachments, $true)
$folderid= new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox,"svccompliance@rencap.com")   
$Inbox = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$folderid)  

####################################################################################################
#
#This section finds attachments and copies the attachment to the download directory
#
####################################################################################################


$ivItemView = New-Object Microsoft.Exchange.WebServices.Data.ItemView(100)
$downloadDirectory = "\\rencap.com\files\WEU01-Workgroups\INTLF"

$downloadedf = New-Object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::DeletedItems,"svccompliance@rencap.com")
$downloadedfolderid = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$downloadedf)


$rootfolderid = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::MsgFolderRoot,"svccompliance@rencap.com")   
$rootfolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$rootfolderid)
  

$findItemsResults = $Inbox.FindItems($Sfha,$ivItemView)
foreach($miMailItems in $findItemsResults.Items){
	$miMailItems.Load()
	foreach($attach in $miMailItems.Attachments){
		$attach.Load()
		$fiFile = new-object System.IO.FileStream(($downloadDirectory + “\” + $attach.Name.ToString()), [System.IO.FileMode]::Create)
		$fiFile.Write($attach.Content, 0, $attach.Content.Length)
		$fiFile.Close()
		write-host "Downloaded Attachment : " + (($downloadDirectory + “\” + $attach.Name.ToString()))
     
	}
   #$miMailItems.Move($downloadedfolderid.id)
}

####################################################################################################
#
#This section moves emails from the Inbox to a subfolder of "Inbox" called "PROCESSED", make sure to 
#create the folder.
#
####################################################################################################

#Get the ID of the folder to move to  
$fvFolderView =  New-Object Microsoft.Exchange.WebServices.Data.FolderView(100)  
$fvFolderView.Traversal = [Microsoft.Exchange.WebServices.Data.FolderTraversal]::Shallow;
$SfSearchFilter = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.FolderSchema]::DisplayName,"Downloaded")
$findFolderResults = $rootfolder.FindFolders($SfSearchFilter,$fvFolderView)  
  
#Define ItemView to retrive just 100 Items    
$ivItemView =  New-Object Microsoft.Exchange.WebServices.Data.ItemView(100)  
$fiItems = $null    
do{    
    $fiItems = $Inbox.FindItems($Sfha,$ivItemView)   
      #[Void]$service.LoadPropertiesForItems($fiItems,$psPropset)  
        foreach($Item in $fiItems.Items){      
 #           # Copy the Message  
 #           #$Item.Copy($findFolderResults.Folders[0].Id)  
            # Move the Message  
            $Item.Move($findFolderResults.Folders[0].Id)  
        }    
        $ivItemView.Offset += $fiItems.Items.Count    
    }while($fiItems.MoreAvailable -eq $true)  