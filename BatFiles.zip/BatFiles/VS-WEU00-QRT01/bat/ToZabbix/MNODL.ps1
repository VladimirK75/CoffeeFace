$SQLServer = "MSK00-SQL11-1\QORT_DMA" #use Server\Instance for named SQL instances! 
$SQLDBName = "QORT_DB_PROD"
$SqlQuery = "/*declare @text varchar(max)
set @text = ''
select 
@text = @text + 
'DEPO:  FIRM_ID = MC0189400000; SECCODE = MNOD.L;CLIENT_CODE = RW331/' + left(SubAccCode,6) + '; OPEN_BALANCE = ' + cast(sum(VolFreeStart) as varchar(10)) + '; OPEN_LIMIT = 0; TRDACCID = L01-WEST; LIMIT_KIND = 2;
'

from Position
inner join Subaccs s
	on s.id = Position.Subacc_ID
inner join Assets a 
	on Position.Asset_ID = a.id
where a.ISIN in ('US60365V1044','US55315J1025','US46626D1081') and a.Enabled=0
and SubAccCode not like '%RESEC%'
and VolFreeStart <> 0
group by left(SubAccCode,6)

select 
@text = @text + 
'DEPO:  FIRM_ID = MC0189400000; SECCODE = LKOD.L;CLIENT_CODE = RW331/' + left(SubAccCode,6) + '; OPEN_BALANCE = ' + cast(sum(VolFreeStart) as varchar(10)) + '; OPEN_LIMIT = 0; TRDACCID = L01-WEST; LIMIT_KIND = 2;
'
from Position
inner join Subaccs s
	on s.id = Position.Subacc_ID
inner join Assets a 
	on Position.Asset_ID = a.id
where a.ISIN in ('US6778621044','US69343P1057') and a.Enabled=0
and SubAccCode not like '%RESEC%'
and VolFreeStart <> 0
group by left(SubAccCode,6)

select @text*/

declare @text varchar(max)
set @text = ''
select 
@text = @text + 
'DEPO:  FIRM_ID = MC0189400000; SECCODE = ATAD.L;CLIENT_CODE = RW331/' + left(SubAccCode,6) + '; OPEN_BALANCE = ' + cast(sum(VolFreeStart) as varchar(10)) + '; OPEN_LIMIT = 0; TRDACCID = L01-WEST; LIMIT_KIND = 2;
'
from Position
inner join Subaccs s
	on s.id = Position.Subacc_ID
inner join Assets a 
	on Position.Asset_ID = a.id
where a.ISIN in ('US6708312052','US8766292051') and a.Enabled=0
and SubAccCode not like '%RESEC%'
and VolFreeStart <> 0
group by left(SubAccCode,6)

select @text

"

$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; uid=QORT; pwd=QORTDB1; Database = $SQLDBName; Integrated Security = False"

$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection

$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd

$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)

$SqlConnection.Close()

foreach ($row in $DataSet.Tables[0].Rows)
 
{
 
$Count = $row[0].ToString()
 
}
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

#Write-Host($Count) > \\vs-msk11-exp01\FillLimits\mnod.lim
Out-file  -filepath \\vs-msk11-exp01\FillLimits\mnod.lim -inputobject $Count -encoding ASCII

$smtpServer = "relay.rencap.com"
$file = "C:\mnod.lim"
$att = new-object Net.Mail.Attachment($file)
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
$msg.From = "CustomLimits@rencap.com"
$msg.To.Add("aleonov@rencap.com")
$msg.To.Add("pperfilov@rencap.com")
$msg.To.Add("ykhatkevich@rencap.com")
$msg.To.Add("ITSupportETG@rencap.com")
$msg.Priority = [System.Net.Mail.MailPriority]::High
$msg.Subject = "MNOD.L limits file copied to FillLimits folder"
$msg.Body = $Count
$msg.Attachments.Add($att)
$smtp.Send($msg)
$att.Dispose()
