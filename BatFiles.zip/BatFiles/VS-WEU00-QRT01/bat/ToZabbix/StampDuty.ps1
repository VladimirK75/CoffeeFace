﻿param(

		[Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 90
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandTimeout = 120
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $sqlConnection.Close()
  Return $DataSet
}


$SqlQuery  = 
@"
DECLARE
@QORTDATE int = [dbo].[fn_qort_getdate](DATEADD(day, -7, GETDATE()))

select 
--p2.id,daa.*
p1.Trade_ID,p1.id,p2.id,daa.*
from QORT_DB_PROD..Phases p1 with (nolock)
left join QORT_TDB_PROD..Phases p2 with (nolock) on p1.id = p2.SystemID
left join QORT_TDB_PROD..DataAlerts_Atom daa with (nolock) on  daa.Record_ID = p2.id
where 1=1
and p2.TSSection_Name IN ('SPOT: OTC','LSE SDRT')
and PhaseDate >= @QORTDATE
and modified_date >= @QORTDATE
and p1.PC_Const in (9,11)
and (daa.iid is NULL OR daa.IsProcessed !=2)
"@
$SqlData = Select-Sql "QORT_DMA\QORT_DMA" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB1'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result