$SQLServer = "QORT_DMA\QORT_DMA" #use Server\Instance for named SQL instances! 
$SQLDBName = "QORT_TDB_PROD"
$SqlQuery = "select count(*) from Trades with (nolock) where TradeDate = convert(varchar(8),getdate(),112) and QUIKClassCode != ''"

$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; uid=QORT; pwd=QORTDB1; Database = $SQLDBName; Integrated Security = False"

$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection

$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd

$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)

$SqlConnection.Close()

foreach ($row in $DataSet.Tables[0].Rows)
 
{
 
$Count = $row[0].ToString()
 
}

& c:\bat\tozabbix\zabbix_sender.exe -c c:\ZabbixAgent\zabbix_agentd.conf -k TDBTradeCount -o $Count

