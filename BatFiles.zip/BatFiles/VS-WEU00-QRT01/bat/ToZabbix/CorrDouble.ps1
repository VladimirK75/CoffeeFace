﻿param(

		[Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 90
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}


$SqlQuery  = 
@"
select	'QORT Offshore' as QORT,
		--comment,	
		SUBSTRING(backid, 1, CASE WHEN CHARINDEX('/', backid) > 0 THEN CHARINDEX('/', backid)-1
                           ELSE LEN(backid)
                        END) as transferid,
		ct_const, 
		count(*) as count
from QORT_DB_PROD..CorrectPositions WITH(NOLOCK)
where registrationdate > CONVERT(CHAR(8), GETDATE() -$Period, 112)
and IsCanceled = 'n'
and comment <> 'MigrationToRenbr 20170802'
group by	--comment, 
			SUBSTRING(backid, 1, CASE WHEN CHARINDEX('/', backid) > 0 THEN CHARINDEX('/', backid)-1
                           ELSE LEN(backid)
                        END), 
			ct_const
having count(*)>1
"@
$SqlData = Select-Sql "QORT_DMA\QORT_DMA" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB1'
$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result