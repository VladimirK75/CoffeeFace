﻿# Мониторинг сделок с незаполнеными полями ChildTradeSubAccOwner_ShortName ChildTradeSubAccOwner_BOCode

param(

		[Parameter(Mandatory = $False, Position = 0)]
        [Int32]$Period       = 14
     )

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  Return $DataSet
}

$TODAY     = Get-Date -Format yyyyMMdd


$SqlQuery  = 
@"
select *
from Trades with (nolock)
where 1=1
and tradeDate = $TODAY
and Tssection_name in ('T+2','MCX_OTC')
and ChildTradeSubAccOwner_BOCode is null
and SubAcc_Code = 'EXO_RESEC'
"@
$SqlData = Select-Sql "QORT_DMA\QORT_DMA" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB1'

$Disc = $SqlData.Tables.Rows | Measure-Object | ForEach-Object {$_.Count}
if ($Disc -ne 0)
{
  $Result = $Disc
}
else
{
  $Result = 0
}
$Result