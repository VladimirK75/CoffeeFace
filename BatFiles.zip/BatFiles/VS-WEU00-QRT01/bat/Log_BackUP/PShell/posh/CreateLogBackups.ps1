Import-Module Pscx

$pcsx = Get-ChildItem C:\Windows\System32\WindowsPowerShell\v1.0\Modules\Pscx
if ($pcsx) {
$qortfolder = Get-ChildItem C:\QORT
if ($qortfolder) {
#$lockfile = Get-Item C:\Windows\Temp\lockfileqort.txt
if (!$lockfile) {
#New-Item C:\Windows\Temp\ -Name lockfileqort.txt -Type File
$CurrentDate = (Get-Date).AddDays(-1)
#gci C:\LOG | sort LastWriteTime | select -last 1 | ForEach {$LastFileDate = $_.LastWriteTime}

#�������� ���� � ����� � ���� 01-09, � �� ������ 1-9
#if ($LastFileDate.Day -lt 10) {
#$oldday = "0" + $LastFileDate.Day
#}
#else {
#$oldday = $LastFileDate.Day
#}

#if ($LastFileDate.Month -lt 10) {
#$oldmonth = "0" + $LastFileDate.Month
#}
#else {
#$oldmonth = $LastFileDate.Month
#}

if ($CurrentDate.Day -lt 10) {
$newday = "0" + $CurrentDate.Day
}
else {
$newday = $CurrentDate.Day
}

if ($CurrentDate.Month -lt 10) {
$newmonth = "0" + $CurrentDate.Month
}
else {
$newmonth = $CurrentDate.Month
}


$newfoldername = [string]$CurrentDate.Year + [string]$newmonth + [string]$newday 
$isfolder=0
Get-ChildItem C:\LOG | ForEach { if ($_.Name -eq $newfoldername) {$isfolder=1} }
if (!$isfolder) {

#������� ����� �����
New-Item C:\LOG -Name $newfoldername -Type Directory

#������� ��������� �����
New-Item C:\LOG\$newfoldername -Name server -Type Directory
New-Item C:\LOG\$newfoldername -Name SrvComp -Type Directory
New-Item C:\LOG\$newfoldername\SrvComp -Name SrvCommissioner -Type Directory
New-Item C:\LOG\$newfoldername\SrvComp -Name SrvPositioner -Type Directory
New-Item C:\LOG\$newfoldername\SrvComp -Name srvQUIK -Type Directory
New-Item C:\LOG\$newfoldername\SrvComp -Name srvQUIKCETS -Type Directory
New-Item C:\LOG\$newfoldername\SrvComp -Name SrvReporter -Type Directory
New-Item C:\LOG\$newfoldername\SrvComp -Name SrvRisks -Type Directory
New-Item C:\LOG\$newfoldername\SrvComp -Name srvTDB -Type Directory


$filemask = "*_" + [string]$CurrentDate.Year + [string]$newmonth  + [string]$newday + ".log"
#write-host $filemask
#���������� ����� �����
Move-Item C:\QORT\server\$filemask C:\LOG\$newfoldername\server
Move-Item C:\QORT\SrvComp\SrvCommissioner\$filemask C:\LOG\$newfoldername\SrvComp\SrvCommissioner
Move-Item C:\QORT\SrvComp\SrvPositioner\$filemask C:\LOG\$newfoldername\SrvComp\SrvPositioner
Move-Item C:\QORT\SrvComp\srvQUIK\$filemask C:\LOG\$newfoldername\SrvComp\srvQUIK
Move-Item C:\QORT\SrvComp\srvQUIKCETS\$filemask C:\LOG\$newfoldername\SrvComp\srvQUIKCETS
Move-Item C:\QORT\SrvComp\SrvReporter\$filemask C:\LOG\$newfoldername\SrvComp\SrvReporter
Move-Item C:\QORT\SrvComp\SrvRisks\$filemask C:\LOG\$newfoldername\SrvComp\SrvRisks
Move-Item C:\QORT\SrvComp\srvTDB\$filemask C:\LOG\$newfoldername\SrvComp\srvTDB



#����� �� ������� �����
$destination = "C:\LOG\" + $newfoldername + "\"

#SERVER
#�������� � �������, ���������� �������� ����� ���������
#cd C:\LOG\$newfoldername
cd C:\LOG\$newfoldername\server

#������� ��� ������
$zipfilename = "server_" + $newfoldername + ".zip"

#�������� �����
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvCommissioner
$zipfilename = "SrvCommissioner_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvPositioner
$zipfilename = "SrvPositioner_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\srvQUIK
$zipfilename = "srvQUIK_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\srvQUIKCETS
$zipfilename = "srvQUIKCETS_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvReporter
$zipfilename = "SrvReporter_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\SrvRisks
$zipfilename = "SrvRisks_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd C:\LOG\$newfoldername\SrvComp\srvTDB
$zipfilename = "srvTDB_" + $newfoldername + ".zip"
Write-Zip * ($destination + $zipfilename)

cd c:\LOG
#Start-sleep -s 600
#������ �������� �����
#Remove-Item C:\LOG\$newfoldername\* -recurse -exclude *.zip -force
#Remove-Item C:\Windows\Temp\lockfileqort.txt -force
}
else {
#Remove-Item C:\Windows\Temp\lockfileqort.txt
Write-Host -Fore Yellow "You've already ran the script today. Please rename the folder."
}
}
else {
Write-Host -Fore Yellow "There are other scripts running. Please wait for them to finish."
}
}
else {
Write-Host -Fore Yellow "No C:\QORT Folder Found"
}
}
else {
Write-Host -Fore Yellow "This PC is not ready for running this script. Please contact IT BSG"
}
