﻿$ErrorActionPreference = "Stop"

Try
{
  $ErrorLog  = "$PSScriptRoot\ArchiveSettlementLog.log"
  $SourseDir = "E:\DDMSettlementService_Log\"
  $TragetDir = "E:\DDMSettlementService_Log\backup\"
  $7Zip      = "C:\Program Files\7-Zip\7z.exe"
  $Day       = (Get-Date).ToString("yyyy-MM-dd")
  $DelDays   = -60
  
  Get-ChildItem $SourseDir | Where-Object {$_.Name -match "(\d+)-(\d+)-(\d+).log" -and $_.Name -notmatch $Day } | ForEach-Object `
  {  
    $ArchName = $_.BaseName | Select-String -Pattern '(\d+-\d+-\d+)'| ForEach-Object {($_.Matches[0].groups[1].Value)}
    &$7Zip u ($TragetDir+$ArchName +'.zip') $_.FullName
    Remove-Item -Path $_.Fullname
  }
    
  # Удаляем старые архивы
  Get-ChildItem $TragetDir *.zip | Where-Object {$_.CreationTime -lt ((Get-Date).AddDays($DelDays))} | ForEach-Object `
  {
    Remove-Item $_.Fullname
  }
}
Finally
{
  (Get-Date).ToString('dd.MM.yyyy HH:mm:ss') | Out-File $ErrorLog -Append
  $Error | Out-File $ErrorLog -Append
}


Try
{
  $ErrorLog  = "$PSScriptRoot\ArchiveSettlementLog.log"
  $SourseDir = "E:\QORT2DDM_Log\"
  $TragetDir = "E:\QORT2DDM_Log\backup\"
  $7Zip      = "C:\Program Files\7-Zip\7z.exe"
  $Day       = (Get-Date).ToString("yyyy-MM-dd")
  $DelDays   = -60
  
  Get-ChildItem $SourseDir | Where-Object {$_.Name -match "(\d+)-(\d+)-(\d+).log" -and $_.Name -notmatch $Day } | ForEach-Object `
  {  
    $ArchName = $_.BaseName | Select-String -Pattern '(\d+-\d+-\d+)'| ForEach-Object {($_.Matches[0].groups[1].Value)}
    &$7Zip u ($TragetDir+$ArchName +'.zip') $_.FullName
    Remove-Item -Path $_.Fullname
  }
    
  # Удаляем старые архивы
  Get-ChildItem $TragetDir *.zip | Where-Object {$_.CreationTime -lt ((Get-Date).AddDays($DelDays))} | ForEach-Object `
  {
    Remove-Item $_.Fullname
  }
}
Finally
{
  (Get-Date).ToString('dd.MM.yyyy HH:mm:ss') | Out-File $ErrorLog -Append
  $Error | Out-File $ErrorLog -Append
}
