﻿
$items =  Get-WmiObject -Class Win32_Process -filter "Name='java.exe'"


write-host -NoNewline "{"
write-host -NoNewline " `"data`":["
#write-host


$n = 0
foreach ($objItem in $Items) {
 $n = $n + 1
 $sid = $objItem.ProcessId
 $ItemName = $objItem.CommandLine
 $ItemName = $ItemName -split '-'
 $ItemName = $ItemName -match '.*classpath(.*).jar'
 $ItemName = $ItemName -split ';'
 $ItemName = $ItemName | Select-String -Pattern '.*classpath(.*).jar' | % {$_.Matches[0].groups[1].value}
 $ItemName = $ItemName -replace '[^a-z]',''
 #$line =  "{`"{#PID}`":`"" +$objItem.ProcessId + `"{#PID}`":`""}"
 $line=@"
{"{#PID}": "$sid" , "{#ITEMNAME}": "$ItemName"}
"@
 If ($n -lt $items.Count) { $line = "$line,"}
 write-host -NoNewline $line
}

#write-host
write-host -NoNewline " ]"
write-host -NoNewline "}"
#write-host


<#
write-host "{"
write-host " `"data`":"
Get-WmiObject -Class Win32_Process -filter "Name='java.exe'" | select -Property @{Name='{#PID}'; Expression = {''+$_.ProcessId}} | ConvertTo-Json 
write-host "}"
#>