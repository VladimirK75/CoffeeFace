﻿$File = 'C:\QORT2DDM\QortDdmPublisher_renbr\cache\RenbrNotProcessed_lastIid.property'

Function Select-Sql
{
  Param(
       [String]$SQLServer
      ,[String]$SQLDBName
      ,[String]$SqlQuery
      ,[String]$Uid
      ,[String]$Pwd
      )
  $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
  $SqlConnection.ConnectionString = "Server = $SQLServer; uid=$Uid; pwd=$Pwd; Database = $SQLDBName; Integrated Security = False"
  $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
  $SqlCmd.CommandText = $SqlQuery
  $SqlCmd.Connection = $SqlConnection
  $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  $SqlAdapter.SelectCommand = $SqlCmd
  $DataSet = New-Object System.Data.DataSet
  $SqlAdapter = $SqlAdapter.Fill($DataSet)
  $SqlConnection.Close()
  Return $DataSet 
}

$SqlQuery  = 
@"
select top 1 iid+100 as iid
from QORT_TDB_PROD..DataAlerts_Atom with(nolock)
where 1=1
and IsProcessed<2
and TC_Const <> 5
order by iid
"@

$SqlData = Select-Sql "MSK00-SQL08-RB" "QORT_TDB_PROD" $SqlQuery 'QORT' 'QORTDB'
$SqlNum  = $SqlData.Tables.Rows.iid
$FileNum = Select-String -Path $File -Pattern 'lastIid=(\d+)' | % {$_.Matches.Groups[1].Value}

if ($FileNum -ge $SqlNum )
{
  $Result = 1
}
else
{
  $Result = 0
}
$Result