declare @DateFrom   date
      , @DateTo     date
      , @subject    varchar(256)
      , @body       nvarchar(max)
      , @body_table nvarchar(max)
      , @body_sign  nvarchar(max)
      , @recipients varchar(256)  = 'ITSupportBackQORT@rencap.com'
      , @Recipcopy  varchar(256)  = 'vkruglov@rencap.com;TReshetnikova@rencap.com'
drop table if exists #tmp_Orders
select @DateFrom = dateadd(month, -2, getdate())
     , @DateTo = getdate()
create table #tmp_Orders
( OrderNum  bigint
, OrderDate int
, TraderUID int )
select @subject = concat('QORT RENBR Orders (UID) - records from ', format(@DateFrom, 'yyyy-MM-dd'), ' to ', format(@DateTo, 'yyyy-MM-dd'))
while @DateFrom <= @DateTo
    begin
        insert into #tmp_Orders
        select OrderNum = t.TSNUM
             , OrderDate = cast(format(t.SERVER_TIME, 'yyyyMMdd') as float)
             , TraderUID = t.user_id
          from QUIK_50.QUIK_DB.dbo.TRANS as t with(nolock)
          inner join( select o.OrderNum
                           , o.OrderDate
                           , o.TraderUID
                        from QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders)
                       where o.TraderUID = 0
                             and o.orderdate = format(@DateFrom, 'yyyyMMdd') ) o on t.TSNUM = o.OrderNum
         where 1 = 1
               and len(t.TRANS_DATA) > 30
               and t.user_id > 0
               and convert(date, SERVER_TIME, 120) = @DateFrom
        union
        select OrderNum = t.TSNUM
             , OrderDate = cast(format(t.SERVER_TIME, 'yyyyMMdd') as float)
             , TraderUID = t.user_id
          from QUIK_60.QUIK_DB.dbo.TRANS as t with(nolock)
          inner join( select o.OrderNum
                           , o.OrderDate
                           , o.TraderUID
                        from QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders)
                       where o.TraderUID = 0
                             and o.orderdate = format(@DateFrom, 'yyyyMMdd') ) o on t.TSNUM = o.OrderNum
         where 1 = 1
               and len(t.TRANS_DATA) > 30
               and t.user_id > 0
               and convert(date, SERVER_TIME, 120) = @DateFrom
		union
        select OrderNum = t.TSNUM
             , OrderDate = cast(format(t.SERVER_TIME, 'yyyyMMdd') as float)
             , TraderUID = t.user_id
          from QUIK_62.QUIK_DB.dbo.TRANS as t with(nolock)
          inner join( select o.OrderNum
                           , o.OrderDate
                           , o.TraderUID
                        from QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders)
                       where o.TraderUID = 0
                             and o.orderdate = format(@DateFrom, 'yyyyMMdd') ) o on t.TSNUM = o.OrderNum
         where 1 = 1
               and len(t.TRANS_DATA) > 30
               and t.user_id > 0
               and convert(date, SERVER_TIME, 120) = @DateFrom
		union
        select OrderNum = t.TSNUM
             , OrderDate = cast(format(t.SERVER_TIME, 'yyyyMMdd') as float)
             , TraderUID = t.user_id
          from QUIK_65.QUIK_DB.dbo.TRANS as t with(nolock)
          inner join( select o.OrderNum
                           , o.OrderDate
                           , o.TraderUID
                        from QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders)
                       where o.TraderUID = 0
                             and o.orderdate = format(@DateFrom, 'yyyyMMdd') ) o on t.TSNUM = o.OrderNum
         where 1 = 1
               and len(t.TRANS_DATA) > 30
               and t.user_id > 0
               and convert(date, SERVER_TIME, 120) = @DateFrom
		union
        select OrderNum = t.TSNUM
             , OrderDate = cast(format(t.SERVER_TIME, 'yyyyMMdd') as float)
             , TraderUID = t.user_id
          from QUIK_70.QUIK_DB.dbo.TRANS as t with(nolock)
          inner join( select o.OrderNum
                           , o.OrderDate
                           , o.TraderUID
                        from QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders)
                       where o.TraderUID = 0
                             and o.orderdate = format(@DateFrom, 'yyyyMMdd') ) o on t.TSNUM = o.OrderNum
         where 1 = 1
               and len(t.TRANS_DATA) > 30
               and t.user_id > 0
               and convert(date, SERVER_TIME, 120) = @DateFrom
        select @DateFrom = dateadd(dd, 1, @DateFrom)
    end
update o
   set o.TraderUID = t.TraderUID
  from QORT_DB_PROD.dbo.orders o with(rowlock)
  inner join #tmp_Orders t on o.OrderNum = t.OrderNum
                              and o.orderdate = t.orderdate
 where 1 = 1

update trd
   set trd.TraderUID = o.TraderUID
  from QORT_DB_PROD.dbo.Trades trd with(rowlock)
  inner join #tmp_Orders o on o.OrderNum = trd.OrderNum
                              and o.orderdate = trd.TradeDate
where 1=1
and o.TraderUID != trd.TraderUID

select @body = '<html><body><head>
<style type="text/css">
.myTable {border-collapse:collapse;}
.myTable td, .myTable th {padding: 3px; border: 1px solid #000}
.myTable th {background-color: #C0C0C0; text-align: center; font-family: "Arial", Sans-serif; font-size: 13px}
.myTable td {font-family: "Arial", Sans-serif; font-size: 12px; text-align: center}
p {margin: 4px 0px 4px; font-family: "Arial", Sans-serif; font-size: 14px; color: #006600}
</style>
</head>
'
select @body_table = replace(replace(cast(( select td = concat(OrderDate, '</td> <td>', NN)
                                              from( select OrderDate
                                                         , NN = count(1)
                                                      from #tmp_Orders
                                                     group by OrderDate ) tt
                                            order by OrderDate for xml path('tr'), type ) as varchar(max)), '&lt;', '<'), '&gt;', '>')
if isnull(@body_table, '') <> ''
    begin
        set @body_table = concat('<table class="myTable" width=450px>' + '<tr><th>Trade Date</th><th>Count</th></tr>', replace(replace(@body_table, '&lt;', '<'), '&gt;', '>'), '</table>')
end
     else
    set @body_table = concat('<p style="font-size: 12px;color:#A52A2A">There are no Orders without TraderUID in QUIK to setup in QORT fot last month till ', format(getdate(), 'yyyy-MM-dd'), '</p>')
select @body_sign = '<hr />
<p style="font-size: 9px">
Server:&nbsp; S-MSK01-SQL08\QORT_RENBR<br /> 
Job:&nbsp; Update_TraderUID_Orders.Subplan_1<br />
Step:&nbsp;Daily Orders checkup<br />
Author: vkruglov@rencap.com
</p> '
select @body = concat(@body, @body_table, @body_sign, '</body></html>')
select *
into ##Mail_Orders
  from #tmp_Orders
exec msdb.dbo.sp_send_dbmail @profile_name = 'QORTMonitoring'
                           , @recipients = @recipients
                           , @copy_recipients = @Recipcopy
                           , @subject = @subject
                           , @body = @body
                           , @body_format = 'HTML'
                           , @query = 'select * from ##Mail_Orders'
                           , @attach_query_result_as_file = 1
                           , @query_result_separator = ','
                           , @query_result_no_padding = 1
drop table if exists #tmp_Orders
drop table if exists ##Mail_Orders