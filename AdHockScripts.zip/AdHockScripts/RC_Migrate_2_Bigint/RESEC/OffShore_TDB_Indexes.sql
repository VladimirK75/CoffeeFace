CREATE NONCLUSTERED INDEX [I_ExportBlockCommissionOnTrades_AccrualDate_TradeNum_CommissionName] ON [dbo].[ExportBlockCommissionOnTrades]
(
	[AccrualDate] ASC,
	[TradeNum] ASC,
	[CommissionName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [I_ImportTrades_TradeNum_BuySell_TradeDate_TSSectionName_AgreeNum] ON [dbo].[ImportTrades]
(
	[TradeNum] ASC,
	[BuySell] ASC,
	[TradeDate] ASC,
	[TSSection_Name] ASC,
	[AgreeNum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
GO
