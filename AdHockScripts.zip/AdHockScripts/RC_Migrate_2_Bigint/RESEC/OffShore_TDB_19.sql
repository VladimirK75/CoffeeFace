use QORT_TDB_PROD
go
alter table A nocheck constraint all;
alter table Aggregates nocheck constraint all;
alter table ExportBlockCommissionOnTrades nocheck constraint all;
alter table ImportBlockCommissionOnTrades nocheck constraint all;
alter table ImportOrders nocheck constraint all;
alter table ImportTradeInstrs nocheck constraint all;
alter table ImportTradeInstrLinks nocheck constraint all;
alter table ImportTradeLinkIDs nocheck constraint all;
alter table ImportTrades nocheck constraint all;
alter table ImportTradeMessageProperties nocheck constraint all;
alter table Orders nocheck constraint all;
alter table Phases nocheck constraint all;
alter table Reports nocheck constraint all;
alter table TradesMLOperationFactors  nocheck constraint all;

alter table A alter column OrderNum bigint;
alter table A alter column TradeNum bigint;
alter table Aggregates alter column OrderNum bigint;

drop index I_ExportBlockCommissionOnTrades_AccrualDate_TradeNum_CommissionName on dbo.ExportBlockCommissionOnTrades
alter table ExportBlockCommissionOnTrades alter column TradeNum bigint null;
create nonclustered index I_ExportBlockCommissionOnTrades_AccrualDate_TradeNum_CommissionName on dbo.ExportBlockCommissionOnTrades( AccrualDate, TradeNum, CommissionName ) with( data_compression = page );

alter table ImportOrders alter column BOOrderNum bigint not null;
drop index I_ImportOrders_OrderDate_QuikClassCode_OrderNum on dbo.ImportOrders
alter table ImportOrders alter column OrderNum bigint not null;
create nonclustered index I_ImportOrders_OrderDate_QuikClassCode_OrderNum on dbo.ImportOrders( OrderDate, QuikClassCode, OrderNum ) with( data_compression = page );

alter table ImportBlockCommissionOnTrades alter column TradeNum bigint;
alter table ImportTradeInstrs alter column ChangeTrade_TradeNum bigint;
alter table ImportTradeInstrLinks alter column Trade_TradeNum bigint;
alter table ImportTradeLinkIDs alter column ChildTrade_TradeNum bigint;
alter table ImportTradeLinkIDs alter column FatherTrade_TradeNum bigint;
alter table ImportTradeMessageProperties alter column TradeNum bigint;

drop index I_ImportTrades_TradeNum_BuySell_TradeDate_TSSectionName_AgreeNum on dbo.ImportTrades
alter table ImportTrades alter column OrderNum bigint null;
alter table ImportTrades alter column TradeNum bigint null;
alter table ImportTrades alter column TradeNum2 bigint null;
create nonclustered index I_ImportTrades_TradeNum_BuySell_TradeDate_TSSectionName_AgreeNum on dbo.ImportTrades( TradeNum, BuySell, TradeDate, TSSection_Name, AgreeNum ) with( data_compression = page );

truncate table Orders;
alter table Orders alter column OrderNum bigint;

truncate table Phases
alter table Phases alter column TradeNum bigint null;

alter table Reports alter column CpTradeNum bigint null;
alter table Reports alter column TradeNum bigint null;

alter table TradesMLOperationFactors drop constraint PK_TradesMLOperationFactors;
alter table TradesMLOperationFactors alter column TradeNum bigint not null;
alter table TradesMLOperationFactors add constraint PK_TradesMLOperationFactors primary key clustered(TradeNum, BuySell, TradeDate, TSSection_Name, MLT_Const) with(data_compression = page);

alter table A with check check constraint all;
alter table Aggregates with check check constraint all;
alter table ExportBlockCommissionOnTrades  with check check constraint all;
alter table ImportBlockCommissionOnTrades  with check check constraint all;
alter table ImportOrders  with check check constraint all;
alter table ImportTradeInstrs  with check check constraint all;
alter table ImportTradeInstrLinks with check check constraint all;
alter table ImportTrades with check check constraint all;
alter table ImportTradeLinkIDs with check check constraint all;
alter table Orders with check check constraint all;
alter table Phases with check check constraint all;
alter table Reports with check check constraint all;
alter table TradesMLOperationFactors  with check check constraint all;