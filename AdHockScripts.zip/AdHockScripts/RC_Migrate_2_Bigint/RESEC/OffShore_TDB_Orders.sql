use [QORT_TDB_PROD]
go
/*
truncate table dbo.Orders
go
alter table Orders alter column OrderNum bigint
go
*/