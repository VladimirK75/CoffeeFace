use [QORT_DB_PROD]
go
alter table dbo.Orders drop constraint PK_Orders with(online = off)
go
truncate table dbo.Orders
go
declare @sql nvarchar(max)
declare statCursor cursor
for select 'DROP STATISTICS ' + quotename(schema_name(t.schema_id)) + '.' + quotename(t.name) + '.' + quotename(st.name) as sql
      from sys.stats as st
      inner join sys.tables as t on st.object_id = t.object_id
                                    and t.name = 'Orders'
     where st.user_created = 1
    order by 1;
open statCursor;
fetch next from statCursor into @sql
while @@FETCH_STATUS = 0
    begin
        print @sql
        exec sp_executesql @sql
        fetch next from statCursor into @sql
    end  
close statCursor  
deallocate statCursor
go
alter table Orders alter column OrderNum bigint not null
go
alter table dbo.Orders
add constraint PK_Orders primary key clustered(OrderDate asc, QuikClassCode asc, OrderNum asc, Enabled asc)
go