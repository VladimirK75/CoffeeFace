alter table dbo.OriginLinkOrders
add constraint PK_OriginLinkOrders primary key clustered(OrderDate asc, QuikClassCode asc, OrderNum asc)
    with(pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, ignore_dup_key = off, online = off, allow_row_locks = on, allow_page_locks = on, fillfactor = 80) on [PRIMARY]
go
add constraint PK_Orders primary key clustered(OrderDate asc, QuikClassCode asc, OrderNum asc, Enabled asc)
    with(pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, ignore_dup_key = off, online = off, allow_row_locks = on, allow_page_locks = on)
go