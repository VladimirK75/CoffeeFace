use QORT_DB_PROD
go
alter table Aggregates nocheck constraint all;
alter table AllTrades nocheck constraint all;
alter table BlockCommissionOnTrades nocheck constraint all;
alter table ElementalOrders nocheck constraint all;
alter table OriginLinkOrders nocheck constraint all;
													 
alter table TradeInstrs nocheck constraint all;
alter table TradeLinks nocheck constraint all;
alter table TradesHist nocheck constraint all;
alter table SuspectOperations nocheck constraint all;

alter table Aggregates alter column OrderNum bigint;

alter table AllTrades drop constraint PK_AllTrades  
alter table AllTrades alter column TradeNum bigint not null;
alter table dbo.AllTrades add constraint PK_AllTrades primary key clustered(TradeDate, Asset_ID, TSSection_ID, TradeTime, TradeNum) with(data_compression = page);

alter table BlockCommissionOnTrades alter column TradeNum bigint;
alter table ElementalOrders alter column OrderNum bigint;

alter table OriginLinkOrders drop constraint PK_OriginLinkOrders  
alter table OriginLinkOrders alter column OrderNum bigint not null;
alter table OriginLinkOrders add constraint PK_OriginLinkOrders primary key clustered(OrderDate, QuikClassCode, OrderNum) with(data_compression = page);

alter table SuspectOperations alter column TradeNum bigint;
alter table TradeInstrs alter column LinkedOrderNum bigint;
alter table TradeLinks alter column CpTradeNum bigint;
alter table TradeLinks alter column TradeNum bigint;
alter table TradesHist alter column OrderNum bigint;
alter table TradesHist alter column TradeNum bigint;
alter table TradesHist alter column TradeNum bigint;

alter table Aggregates with check check constraint all;
alter table AllTrades with check check constraint all;
alter table BlockCommissionOnTrades	with check check constraint all;
alter table ElementalOrders with check check constraint all;
alter table OriginLinkOrders with check check constraint all;
alter table SuspectOperations  with check check constraint all;
alter table TradeInstrs	 with check check constraint all;
alter table TradeLinks with check check constraint all;
alter table TradesHist with check check constraint all;