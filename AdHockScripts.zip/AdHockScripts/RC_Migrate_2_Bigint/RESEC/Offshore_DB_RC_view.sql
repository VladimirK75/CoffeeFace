use [QORT_DB_PROD]
go
create view dbo.RC_Indexes_Objects
as
     select Table_Name = t.name
          , ColumnsAll = concat(key_definition, ',', include_definition)
          , case si.index_id when 0
                 then N'/* No create statement (Heap) */'
                 else case is_primary_key when 1
                           then N'ALTER TABLE ' + quotename(sc.name) + N'.' + quotename(t.name) + N' ADD CONSTRAINT ' + quotename(si.name) + N' PRIMARY KEY ' + case when si.index_id > 1
                                                                                                                                                                     then N'NON'
                                                                                                                                                                     else N''
                                                                                                                                                                end + N'CLUSTERED '
                           else N'CREATE ' + case when si.is_unique = 1
                                                  then N'UNIQUE '
                                                  else N''
                                             end + case when si.index_id > 1
                                                        then N'NON'
                                                        else N''
                                                   end + N'CLUSTERED ' + N'INDEX ' + quotename(si.name) + N' ON ' + quotename(sc.name) + N'.' + quotename(t.name) + N' '
                      end + /* key def */                      N'(' + key_definition + N')' + /* includes */                      case when include_definition is not null
                                                                                                                                       then N' INCLUDE (' + include_definition + N')'
                                                                                                                                       else N''
                                                                                                                                  end + /* filters */                      case when filter_definition is not null
                                                                                                                                                                                then N' WHERE ' + filter_definition
                                                                                                                                                                                else N''
                                                                                                                                                                           end + /* with clause - compression goes here */
                      case when row_compression_partition_list is not null
                                or page_compression_partition_list is not null
                           then N' WITH (' + case when row_compression_partition_list is not null
                                                  then N'DATA_COMPRESSION = ROW ' + case when psc.name is null
                                                                                         then N''
                                                                                         else+N' ON PARTITIONS (' + row_compression_partition_list + N')'
                                                                                    end
                                                  else N''
                                             end + case when row_compression_partition_list is not null
                                                             and page_compression_partition_list is not null
                                                        then N', '
                                                        else N''
                                                   end + case when page_compression_partition_list is not null
                                                              then N'DATA_COMPRESSION = PAGE ' + case when psc.name is null
                                                                                                      then N''
                                                                                                      else+N' ON PARTITIONS (' + page_compression_partition_list + N')'
                                                                                                 end
                                                              else N''
                                                         end + N')'
                           else N''
                      end + /* ON where? filegroup? partition scheme? */
                      ' ON ' + case when psc.name is null
                                    then isnull(quotename(fg.name), N'')
                                    else psc.name + N' (' + partitioning_column.column_name + N')'
                               end + N';'
            end as     index_create_statement
          , si.index_id
          , si.name as index_name
       from sys.indexes as si
       join sys.tables as t on si.object_id = t.object_id
       join sys.schemas as sc on t.schema_id = sc.schema_id
       left join sys.dm_db_index_usage_stats as stat on stat.database_id = db_id()
                                                        and si.object_id = stat.object_id
                                                        and si.index_id = stat.index_id
       left join sys.partition_schemes as psc on si.data_space_id = psc.data_space_id
       left join sys.partition_functions as pf on psc.function_id = pf.function_id
       left join sys.filegroups as fg on si.data_space_id = fg.data_space_id
       /* Key list */       outer apply( select stuff(( select N', ' + quotename(c.name) + case ic.is_descending_key when 1
                                                                                                then N' DESC'
                                                                                                else N''
                                                                                           end
                                                          from sys.index_columns as ic
                                                          join sys.columns as c on ic.column_id = c.column_id
                                                                                   and ic.object_id = c.object_id
                                                         where ic.object_id = si.object_id
                                                               and ic.index_id = si.index_id
                                                               and ic.key_ordinal > 0
                                                        order by ic.key_ordinal for xml path(''), type ).value( '.', 'NVARCHAR(MAX)' ), 1, 2, '') ) as keys(key_definition)
            /* Partitioning Ordinal */       outer apply( select max(quotename(c.name)) as column_name
                                                            from sys.index_columns as ic
                                                            join sys.columns as c on ic.column_id = c.column_id
                                                                                     and ic.object_id = c.object_id
                                                           where ic.object_id = si.object_id
                                                                 and ic.index_id = si.index_id
                                                                 and ic.partition_ordinal = 1 ) as partitioning_column
                                                        /* Include list */       outer apply( select stuff(( select N', ' + quotename(c.name)
                                                                                                               from sys.index_columns as ic
                                                                                                               join sys.columns as c on ic.column_id = c.column_id
                                                                                                                                        and ic.object_id = c.object_id
                                                                                                              where ic.object_id = si.object_id
                                                                                                                    and ic.index_id = si.index_id
                                                                                                                    and ic.is_included_column = 1
                                                                                                             order by c.name for xml path(''), type ).value( '.', 'NVARCHAR(MAX)' ), 1, 2, '') ) as includes(include_definition)
            /* Partitions */       outer apply( select count(*) as                                                                        partition_count
                                                     , cast(sum(ps.in_row_reserved_page_count) * 8. / 1024. / 1024. as numeric(32, 1)) as reserved_in_row_GB
                                                     , cast(sum(ps.lob_reserved_page_count) * 8. / 1024. / 1024. as numeric(32, 1)) as    reserved_LOB_GB
                                                     , sum(ps.row_count) as                                                               row_count
                                                  from sys.partitions as p
                                                  join sys.dm_db_partition_stats as ps on p.partition_id = ps.partition_id
                                                 where p.object_id = si.object_id
                                                       and p.index_id = si.index_id ) as partition_sums
                                              /* row compression list by partition */       outer apply( select stuff(( select N', ' + cast(p.partition_number as varchar(32))
                                                                                                                          from sys.partitions as p
                                                                                                                         where p.object_id = si.object_id
                                                                                                                               and p.index_id = si.index_id
                                                                                                                               and p.data_compression = 1
                                                                                                                        order by p.partition_number for xml path(''), type ).value( '.', 'NVARCHAR(MAX)' ), 1, 2, '') ) as row_compression_clause(row_compression_partition_list)
     /* data compression list by partition */       outer apply( select stuff(( select N', ' + cast(p.partition_number as varchar(32))
                                                                                  from sys.partitions as p
                                                                                 where p.object_id = si.object_id
                                                                                       and p.index_id = si.index_id
                                                                                       and p.data_compression = 2
                                                                                order by p.partition_number for xml path(''), type ).value( '.', 'NVARCHAR(MAX)' ), 1, 2, '') ) as page_compression_clause(page_compression_partition_list)
      where si.type in ( 0, 1, 2 ) /* heap, clustered, nonclustered */
-- OPTION (RECOMPILE);
go