use QORT_TDB_PROD
go
/*
alter table Phases nocheck constraint all;

declare @sql nvarchar(max)
declare statCursor cursor
for select 'DROP STATISTICS ' + quotename(schema_name(t.schema_id)) + '.' + quotename(t.name) + '.' + quotename(st.name) as sql
      from sys.stats as st
      inner join sys.tables as t on st.object_id = t.object_id
                                    and t.name = 'Phases'
     where st.user_created = 1
    order by 1;
open statCursor;
fetch next from statCursor into @sql
while @@FETCH_STATUS = 0
    begin
        print @sql
        exec sp_executesql @sql
        fetch next from statCursor into @sql
    end  
close statCursor  
deallocate statCursor
go



truncate table Phases
alter table Phases alter column OrderNum bigint null;
alter table Reports with check check constraint all;
*/