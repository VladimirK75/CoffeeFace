use QORT_DB_PROD
go
exec sp_rename 'Trades'
             , 'Trades_old';  
go
exec sp_rename 'Trades_old.PK_Trades'
             , 'PK_Trades_old'
go
drop trigger dbo.T_ON_DISABLE_Trades
go
drop trigger dbo.T_Trades_Gen_Row_ID
go
alter table Trades_old drop constraint DEF_Trades_id
alter table Trades_old drop constraint DEF_Trades_ArgueStatus 
alter table Trades_old drop constraint DEF_Trades_CancelArgueStatus
alter table Trades_old drop constraint DEF_Trades_IsAccrued
alter table Trades_old drop constraint DEF_Trades_IsCoverage
alter table Trades_old drop constraint DEF_Trades_IsDiscount
alter table Trades_old drop constraint DEF_Trades_IsDraft
alter table Trades_old drop constraint DEF_Trades_IsMargin
alter table Trades_old drop constraint DEF_Trades_IsProcessed 
alter table Trades_old drop constraint DEF_Trades_IsRepo2
alter table Trades_old drop constraint DEF_Trades_IsSigned
alter table Trades_old drop constraint DEF_Trades_IsUsed
alter table Trades_old drop constraint DEF_Trades_NullStatus
alter table Trades_old drop constraint DEF_Trades_PayStatus
alter table Trades_old drop constraint DEF_Trades_PutStatus
alter table dbo.Trades_old drop constraint CK_Trades_ArgueStatus
alter table dbo.Trades_old drop constraint CK_Trades_CancelArgueStatus
alter table dbo.Trades_old drop constraint CK_Trades_IsAccrued
alter table dbo.Trades_old drop constraint CK_Trades_IsCoverage
alter table dbo.Trades_old drop constraint CK_Trades_IsDiscount
alter table dbo.Trades_old drop constraint CK_Trades_IsDraft
alter table dbo.Trades_old drop constraint CK_Trades_IsMargin
alter table dbo.Trades_old drop constraint CK_Trades_IsProcessed
alter table dbo.Trades_old drop constraint CK_Trades_IsRepo2
alter table dbo.Trades_old drop constraint CK_Trades_IsSigned
alter table dbo.Trades_old drop constraint CK_Trades_IsUsed
alter table dbo.Trades_old drop constraint CK_Trades_NullStatus
alter table dbo.Trades_old drop constraint CK_Trades_PayStatus
alter table dbo.Trades_old drop constraint CK_Trades_PutStatus
go
create table dbo.Trades
( id                        dbo.ROW_ID not null
, Accruedint                float null
, Accruedint2               float null
, AccruedintPart            float null
, Accruedint2Part           float null
, AgreeNum                  varchar(100) collate Cyrillic_General_CS_AS null
, AgreePlannedDate          dbo.MDATE null
, ArgueDate                 dbo.MDATE null
, ArgueStatus               dbo.YN_FLAG null
, Assets                    float null
, BackDate                  dbo.MDATE null
, BackPrice                 float null
, BOTradeNum                float null
, BrokerFirm_ID             float null
, BuySell                   smallint not null
, CancelArgueDate           dbo.MDATE null
, CancelArgueStatus         dbo.YN_FLAG null
, ChildTradeNum             float null
, ClearFirm_ID              float null
, CloseDate                 dbo.MDATE null
, CloseStatus               int null
, Comment                   dbo.STRING128 null
, CorrectedUser_ID          int null
, Corrected_Date            dbo.MDATE null
, Corrected_Time            dbo.MTIME null
, CpFirm_ID                 float null
, CpTrade_ID                float null
, CrossRate                 float null
, CRT_Const                 smallint null
, CrossRateDate             dbo.MDATE null
, CrossRateShift            smallint null
, CurrPayAsset_ID           float null
, CurrPriceAsset_ID         float null
, DealerFirm                varchar(12) collate Cyrillic_General_CI_AS null
, Discount                  float null
, Enabled                   float not null
, FeePay                    float null
, FeePut                    float null
, FutGO                     float null
, InfoSource                varchar(64) collate Cyrillic_General_CI_AS null
, IsAccrued                 dbo.YN_FLAG null
, IsCoverage                dbo.YN_FLAG null
, IsDiscount                dbo.YN_FLAG null
, IsDraft                   dbo.YN_FLAG null
, IsMargin                  dbo.YN_FLAG null
, IsProcessed               dbo.YN_FLAG null
, IsRepo2                   dbo.YN_FLAG null
, IsShared                  smallint null
, IsSigned                  dbo.YN_FLAG null
, IsUsed                    dbo.YN_FLAG null
, LotQty                    float null
, Margin                    float null
, MaxDiscount               float null
, MinDiscount               float null
, NullStatus                dbo.YN_FLAG null
, NumPeriods                smallint null
, OppositeTradeNum          float null
, OrderNum                  bigint null
, PayAccount_ID             float null
, PayDate                   dbo.MDATE null
, PayPeriod                 smallint null
, PayPlannedDate            dbo.MDATE null
, PayStatus                 dbo.YN_FLAG null
, PercentPayPeriod          smallint null
, PrevMargin                float null
, Price                     float null
, PT_Const                  smallint null
, PutAccount_ID             float null
, PutDate                   dbo.MDATE null
, PutPayType                float null
, PutPeriod                 smallint null
, PutPlannedDate            dbo.MDATE null
, PutStatus                 dbo.YN_FLAG null
, Qty                       float null
, QUIKClassCode             varchar(12) collate Cyrillic_General_CI_AS null
, R2                        float null
, RefundRate                float null
, RepoBasis                 smallint null
, RepoDate2                 dbo.MDATE null
, RepoRate                  float null
, RepoTerm                  smallint null
, RepoTrade_ID              float null
, FunctionType              smallint null
, Security_ID               float null
, SettleCode                varchar(12) collate Cyrillic_General_CI_AS null
, SubAcc_ID                 float null
, TimeBasis                 smallint null
, TimeSpread                smallint null
, TOS_Const                 smallint null
, TradeDate                 dbo.MDATE not null
, TradeInstr_ID             float null
, TradeNum                  bigint not null
, TraderUser_ID             int null
, TradeTime                 dbo.MTIME null
, TSCommission              float null
, TSOffNum                  float null
, TSSection_ID              float not null
, TT_Const                  smallint null
, Volume1                   float null
, Volume2                   float null
, VolumeDiscount            float null
, VT_Const                  smallint null
, Yield                     float null
, SalesManager_ID           int null
, SalesManagerFee           float null
, VarMargin                 float null
, ClearingComission         float null
, ExchangeComission         float null
, TechCenterComission       float null
, Author_ID                 int null
, created_date              dbo.MDATE null
, modified_date             dbo.MDATE null
, created_time              dbo.MTIME null
, modified_time             dbo.MTIME null
, user_created              dbo.USERID null
, user_modified             dbo.USERID null
, Trader                    varchar(12) collate Cyrillic_General_CI_AS null
, DMVSize                   float null
, DMVBase                   float null
, EventDate                 dbo.MDATE null
, Reference                 varchar(16) collate Cyrillic_General_CI_AS null
, BlockSum                  float null
, MarketComm                float null
, BrokerDifComm             float null
, BrokerComm                float null
, TaxComm                   float null
, TV_Const                  smallint null
, QFlags                    bigint null
, OrdExchCode               varchar(64) collate Cyrillic_General_CI_AS null
, SS_Const                  smallint null
, AddStatRegulator          smallint null
, AddStatRegulatorDate      dbo.MDATE null
, AddStatBroker             smallint null
, AddStatBrokerDate         dbo.MDATE null
, AddStatExchange           smallint null
, AddStatExchangeDate       dbo.MDATE null
, AddStatClearing           smallint null
, AddStatClearingDate       dbo.MDATE null
, AddStatClient             smallint null
, AddStatClientDate         dbo.MDATE null
, AddStatCounterparty       smallint null
, AddStatCounterpartyDate   dbo.MDATE null
, AddStatExternalSystem     smallint null
, AddStatExternalSystemDate dbo.MDATE null
, AddStatUser               smallint null
, AddStatUserDate           dbo.MDATE null
, AddStatBackOffice         smallint null
, AddStatBackOfficeDate     dbo.MDATE null
, MasterAgreement_ID        float null
, PutFirmAccount_ID         float null
, PayFirmAccount_ID         float null
, PortfolioValue            float null
, MinMargin                 float null
, InitMargin                float null
, ExtBrokerFirm_ID          float null
, BONum                     varchar(40) collate Cyrillic_General_CI_AS null
, Firm_ID                   float null
, CpSubFirm_ID              float null
, AccruedintPrice           float null
, Accruedint2Price          float null
, AccruedintPartPrice       float null
, Accruedint2PartPrice      float null
, ShareTrade_ID             float null
, Volume1Nom                float null
, Volume2Nom                float null
, TradeInstrBONum           varchar(40) collate Cyrillic_General_CI_AS null
, TraderUID                 int null
, ClassificationCode        varchar(7) collate Cyrillic_General_CI_AS null
, CorrelationCode           varchar(10) collate Cyrillic_General_CI_AS null
, BaseAssetPutDate          dbo.MDATE null
, BaseAssetMeasureCode      varchar(5) collate Cyrillic_General_CI_AS null
, SETTYPE_Const             smallint null
, SETMET_Const              smallint null
, AgreeDateStart            dbo.MDATE null
, AgreeDateEnd              dbo.MDATE null
, PTI_Flags                 int null
, WVI_Flags                 int null
, SSI_Const                 int null
, ConversionRate            float null
, ConversionRate_Asset_ID   float null
, TradeTimeMCS              smallint null
, PayFRQ_Const              smallint null
, RecFRQ_Const              smallint null
, Interest                  float null
, InterestPrice             float null
, MarketPrice               float null
, AuctionPeriod             int null
, constraint PK_Trades primary key clustered(TradeDate asc, BuySell asc, TradeNum asc, TSSection_ID asc, Enabled asc)
  with(pad_index = off, statistics_norecompute = off, ignore_dup_key = off, allow_row_locks = on, allow_page_locks = on) on [TradeDateRangePS_Trades]([TradeDate]) )
on [TradeDateRangePS_Trades]([TradeDate])
go
set ansi_padding on
go
/****** Object:  Index [I_Trades_AgreeNum]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_AgreeNum on dbo.Trades
( AgreeNum asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_BrokerFirmID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_BrokerFirmID on dbo.Trades
( BrokerFirm_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_ChildTradeNum]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_ChildTradeNum on dbo.Trades
( ChildTradeNum asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_ClearFirmID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_ClearFirmID on dbo.Trades
( ClearFirm_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_CpFirmID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_CpFirmID on dbo.Trades
( CpFirm_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_CpTradeID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_CpTradeID on dbo.Trades
( CpTrade_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_CurrPayAssetID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_CurrPayAssetID on dbo.Trades
( CurrPayAsset_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_CurrPriceAssetID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_CurrPriceAssetID on dbo.Trades
( CurrPriceAsset_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_Enabled_CpSubFirm_ID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_Enabled_CpSubFirm_ID on dbo.Trades
( Enabled asc, CpSubFirm_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_Enabled_ExtBrokerFirmID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_Enabled_ExtBrokerFirmID on dbo.Trades
( Enabled asc, ExtBrokerFirm_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_Enabled_FirmID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_Enabled_FirmID on dbo.Trades
( Enabled asc, Firm_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_EventDate]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_EventDate on dbo.Trades
( EventDate asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_ID]    Script Date: 20-Jan-20 13:38:27 ******/
create unique nonclustered index I_Trades_ID on dbo.Trades
( id asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, ignore_dup_key = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, fillfactor = 80 ) on [PRIMARY]
go
/****** Object:  Index [I_Trades_ModifiedDate]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_ModifiedDate on dbo.Trades
( modified_date asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
set ansi_padding on
go
/****** Object:  Index [I_Trades_NullStatus]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_NullStatus on dbo.Trades
( NullStatus asc ) include( id, Accruedint, BuySell, CpFirm_ID, CurrPayAsset_ID, CurrPriceAsset_ID, IsAccrued, IsProcessed, OrderNum, PayAccount_ID, PayPlannedDate, Price, PutDate, PutPlannedDate, Qty, FunctionType, Security_ID, SettleCode, SubAcc_ID, TradeDate, TradeNum, TradeTime, TSSection_ID, TT_Const, Volume1, VarMargin ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, fillfactor = 80 ) on [PRIMARY]
go
/****** Object:  Index [I_Trades_OppositeTradeNum]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_OppositeTradeNum on dbo.Trades
( OppositeTradeNum asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_PayDate_TTConst]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_PayDate_TTConst on dbo.Trades
( PayDate asc, TT_Const asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_PayFirmAccountID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_PayFirmAccountID on dbo.Trades
( PayFirmAccount_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_PayPlannedDate]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_PayPlannedDate on dbo.Trades
( PayPlannedDate asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_PutDate]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_PutDate on dbo.Trades
( PutDate asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_PutFirmAccountID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_PutFirmAccountID on dbo.Trades
( PutFirmAccount_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_PutPayType]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_PutPayType on dbo.Trades
( PutPayType asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_PutPlannedDate]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_PutPlannedDate on dbo.Trades
( PutPlannedDate asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_RepoTradeID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_RepoTradeID on dbo.Trades
( RepoTrade_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_ShareTrade_ID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_ShareTrade_ID on dbo.Trades
( Enabled asc, ShareTrade_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_ShareTradeID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_ShareTradeID on dbo.Trades
( ShareTrade_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, fillfactor = 80 )
go
/****** Object:  Index [I_Trades_SubaccID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_SubaccID on dbo.Trades
( SubAcc_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
set ansi_padding on
go
/****** Object:  Index [I_Trades_SubAccID_TradeDate_BONum]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_SubAccID_TradeDate_BONum on dbo.Trades
( SubAcc_ID asc, TradeDate asc, BONum asc ) include( AgreeNum, BuySell ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_TradeDate_PutDate_PutAccountID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_TradeDate_PutDate_PutAccountID on dbo.Trades
( TradeDate asc, PutDate asc, PutAccount_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
/****** Object:  Index [I_Trades_TradeInstrID]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index I_Trades_TradeInstrID on dbo.Trades
( TradeInstr_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on )
go
set ansi_padding on
go
/****** Object:  Index [IX_Trades_DMA_DMC]    Script Date: 20-Jan-20 13:38:27 ******/
create nonclustered index IX_Trades_DMA_DMC on dbo.Trades
( SubAcc_ID asc, TT_Const asc, IsRepo2 asc, PutPlannedDate asc, PayPlannedDate asc, PayAccount_ID asc, TSSection_ID asc, Security_ID asc, CpFirm_ID asc, id asc ) include( Accruedint, AgreeNum, BOTradeNum, BuySell, IsAccrued, OrderNum, Price, Qty, TradeDate, TradeNum, TradeTime, Volume1 ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, fillfactor = 80 ) on [PRIMARY]
go
alter table dbo.Trades
add constraint DEF_Trades_id default(-1) for id
go
alter table dbo.Trades
add constraint DEF_Trades_ArgueStatus default 'n' for ArgueStatus
go
alter table dbo.Trades
add constraint DEF_Trades_CancelArgueStatus default 'n' for CancelArgueStatus
go
alter table dbo.Trades
add constraint DEF_Trades_IsAccrued default 'n' for IsAccrued
go
alter table dbo.Trades
add constraint DEF_Trades_IsCoverage default 'n' for IsCoverage
go
alter table dbo.Trades
add constraint DEF_Trades_IsDiscount default 'n' for IsDiscount
go
alter table dbo.Trades
add constraint DEF_Trades_IsDraft default 'n' for IsDraft
go
alter table dbo.Trades
add constraint DEF_Trades_IsMargin default 'n' for IsMargin
go
alter table dbo.Trades
add constraint DEF_Trades_IsProcessed default 'n' for IsProcessed
go
alter table dbo.Trades
add constraint DEF_Trades_IsRepo2 default 'n' for IsRepo2
go
alter table dbo.Trades
add constraint DEF_Trades_IsSigned default 'n' for IsSigned
go
alter table dbo.Trades
add constraint DEF_Trades_IsUsed default 'n' for IsUsed
go
alter table dbo.Trades
add constraint DEF_Trades_NullStatus default 'n' for NullStatus
go
alter table dbo.Trades
add constraint DEF_Trades_PayStatus default 'n' for PayStatus
go
alter table dbo.Trades
add constraint DEF_Trades_PutStatus default 'n' for PutStatus
go
alter table dbo.Trades
with check
add constraint CK_Trades_ArgueStatus check(ArgueStatus = 'y'
                                           or ArgueStatus = 'n')
go
alter table dbo.Trades check constraint CK_Trades_ArgueStatus
go
alter table dbo.Trades
with check
add constraint CK_Trades_CancelArgueStatus check(CancelArgueStatus = 'y'
                                                 or CancelArgueStatus = 'n')
go
alter table dbo.Trades check constraint CK_Trades_CancelArgueStatus
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsAccrued check(IsAccrued = 'y'
                                         or IsAccrued = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsAccrued
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsCoverage check(IsCoverage = 'y'
                                          or IsCoverage = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsCoverage
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsDiscount check(IsDiscount = 'y'
                                          or IsDiscount = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsDiscount
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsDraft check(IsDraft = 'y'
                                       or IsDraft = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsDraft
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsMargin check(IsMargin = 'y'
                                        or IsMargin = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsMargin
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsProcessed check(IsProcessed = 'y'
                                           or IsProcessed = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsProcessed
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsRepo2 check(IsRepo2 = 'y'
                                       or IsRepo2 = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsRepo2
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsSigned check(IsSigned = 'y'
                                        or IsSigned = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsSigned
go
alter table dbo.Trades
with check
add constraint CK_Trades_IsUsed check(IsUsed = 'y'
                                      or IsUsed = 'n')
go
alter table dbo.Trades check constraint CK_Trades_IsUsed
go
alter table dbo.Trades
with check
add constraint CK_Trades_NullStatus check(NullStatus = 'y'
                                          or NullStatus = 'n')
go
alter table dbo.Trades check constraint CK_Trades_NullStatus
go
alter table dbo.Trades
with check
add constraint CK_Trades_PayStatus check(PayStatus = 'y'
                                         or PayStatus = 'n')
go
alter table dbo.Trades check constraint CK_Trades_PayStatus
go
alter table dbo.Trades
with check
add constraint CK_Trades_PutStatus check(PutStatus = 'y'
                                         or PutStatus = 'n')
go
alter table dbo.Trades check constraint CK_Trades_PutStatus
go
/****** Object:  Trigger [dbo].[T_ON_DISABLE_Trades]    Script Date: 20-Jan-20 13:38:27 ******/
set ansi_nulls on
go
set quoted_identifier off
go
create trigger dbo.T_ON_DISABLE_Trades on dbo.Trades
for update
as
     set nocount on
     declare @table_id int
     declare @id float
     declare @status float
     declare @row_count float
     declare @str_id varchar(64)
     declare @reftab varchar(128)
     declare @tab_name varchar(128)
     if @@LANGID = 0
         set @tab_name = 'Trades'
          else
         set @tab_name = 'Сделки'
     declare Trades_del_id_cursor cursor
     for select id
              , enabled
           from inserted
          where enabled > 0
     open Trades_del_id_cursor
     fetch next from Trades_del_id_cursor into @id
                                             , @status
     while @@FETCH_STATUS = 0
         begin
             if @status > 0
                 begin
                     if( select count(id)
                           from Trades
                          where isnull(ChildTradeNum, -1) > 0
                                and ChildTradeNum = @id
                                and enabled = 0 ) > 0
                         begin
                             rollback tran
                             if @@LANGID = 0
                                 set @reftab = 'Trades'
                                  else
                                 set @reftab = 'Сделки'
                             select @str_id = convert(varchar(64), convert(bigint, @id))
                             raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                     end
                          else
                         if( select count(id)
                               from Trades
                              where isnull(CpTrade_ID, -1) > 0
                                    and CpTrade_ID = @id
                                    and enabled = 0 ) > 0
                             begin
                                 rollback tran
                                 if @@LANGID = 0
                                     set @reftab = 'Trades'
                                      else
                                     set @reftab = 'Сделки'
                                 select @str_id = convert(varchar(64), convert(bigint, @id))
                                 raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                         end
                              else
                             if( select count(id)
                                   from Trades
                                  where isnull(OppositeTradeNum, -1) > 0
                                        and OppositeTradeNum = @id
                                        and enabled = 0 ) > 0
                                 begin
                                     rollback tran
                                     if @@LANGID = 0
                                         set @reftab = 'Trades'
                                          else
                                         set @reftab = 'Сделки'
                                     select @str_id = convert(varchar(64), convert(bigint, @id))
                                     raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                             end
                                  else
                                 if( select count(id)
                                       from Trades
                                      where isnull(RepoTrade_ID, -1) > 0
                                            and RepoTrade_ID = @id
                                            and enabled = 0 ) > 0
                                     begin
                                         rollback tran
                                         if @@LANGID = 0
                                             set @reftab = 'Trades'
                                              else
                                             set @reftab = 'Сделки'
                                         select @str_id = convert(varchar(64), convert(bigint, @id))
                                         raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                 end
                                      else
                                     if( select count(id)
                                           from Trades
                                          where isnull(ShareTrade_ID, -1) > 0
                                                and ShareTrade_ID = @id
                                                and enabled = 0 ) > 0
                                         begin
                                             rollback tran
                                             if @@LANGID = 0
                                                 set @reftab = 'Trades'
                                                  else
                                                 set @reftab = 'Сделки'
                                             select @str_id = convert(varchar(64), convert(bigint, @id))
                                             raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                     end
                                          else
                                         if( select count(id)
                                               from TradeLinkIDs
                                              where isnull(FatherTrade_ID, -1) > 0
                                                    and FatherTrade_ID = @id
                                                    and enabled = 0 ) > 0
                                             begin
                                                 rollback tran
                                                 if @@LANGID = 0
                                                     set @reftab = 'TradeLinkIDs'
                                                      else
                                                     set @reftab = 'Связи сделок по типу'
                                                 select @str_id = convert(varchar(64), convert(bigint, @id))
                                                 raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                         end
                                              else
                                             if( select count(id)
                                                   from TradeLinkIDs
                                                  where isnull(ChildTrade_ID, -1) > 0
                                                        and ChildTrade_ID = @id
                                                        and enabled = 0 ) > 0
                                                 begin
                                                     rollback tran
                                                     if @@LANGID = 0
                                                         set @reftab = 'TradeLinkIDs'
                                                          else
                                                         set @reftab = 'Связи сделок по типу'
                                                     select @str_id = convert(varchar(64), convert(bigint, @id))
                                                     raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                             end
                                                  else
                                                 if( select count(id)
                                                       from Reports
                                                      where isnull(Trade_ID, -1) > 0
                                                            and Trade_ID = @id
                                                            and enabled = 0 ) > 0
                                                     begin
                                                         rollback tran
                                                         if @@LANGID = 0
                                                             set @reftab = 'Reports'
                                                              else
                                                             set @reftab = 'Отчеты исполнения РЕПО, РПС'
                                                         select @str_id = convert(varchar(64), convert(bigint, @id))
                                                         raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                 end
                                                      else
                                                     if( select count(id)
                                                           from Reports
                                                          where isnull(CpTrade_ID, -1) > 0
                                                                and CpTrade_ID = @id
                                                                and enabled = 0 ) > 0
                                                         begin
                                                             rollback tran
                                                             if @@LANGID = 0
                                                                 set @reftab = 'Reports'
                                                                  else
                                                                 set @reftab = 'Отчеты исполнения РЕПО, РПС'
                                                             select @str_id = convert(varchar(64), convert(bigint, @id))
                                                             raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                     end
                                                          else
                                                         if( select count(id)
                                                               from Phases
                                                              where isnull(Trade_ID, -1) > 0
                                                                    and Trade_ID = @id
                                                                    and enabled = 0 ) > 0
                                                             begin
                                                                 rollback tran
                                                                 if @@LANGID = 0
                                                                     set @reftab = 'Phases'
                                                                      else
                                                                     set @reftab = 'Этапы исполнения сделок'
                                                                 select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                 raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                         end
                                                              else
                                                             if( select count(id)
                                                                   from Phases
                                                                  where isnull(ChildTrade_ID, -1) > 0
                                                                        and ChildTrade_ID = @id
                                                                        and enabled = 0 ) > 0
                                                                 begin
                                                                     rollback tran
                                                                     if @@LANGID = 0
                                                                         set @reftab = 'Phases'
                                                                          else
                                                                         set @reftab = 'Этапы исполнения сделок'
                                                                     select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                     raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                             end
                                                                  else
                                                                 if( select count(id)
                                                                       from AggregateTrades
                                                                      where isnull(Trade_ID, -1) > 0
                                                                            and Trade_ID = @id
                                                                            and enabled = 0 ) > 0
                                                                     begin
                                                                         rollback tran
                                                                         if @@LANGID = 0
                                                                             set @reftab = 'AggregateTrades'
                                                                              else
                                                                             set @reftab = 'Сделки в агрегате'
                                                                         select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                         raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                                 end
                                                                      else
                                                                     if( select count(id)
                                                                           from NDFLTradeParams
                                                                          where isnull(Trade_ID, -1) > 0
                                                                                and Trade_ID = @id
                                                                                and enabled = 0 ) > 0
                                                                         begin
                                                                             rollback tran
                                                                             if @@LANGID = 0
                                                                                 set @reftab = 'NDFLTradeParams'
                                                                                  else
                                                                                 set @reftab = 'Параметры мат. выгоды по сделке'
                                                                             select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                             raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                                     end
                                                                          else
                                                                         if( select count(id)
                                                                               from NSDBulkTrades
                                                                              where isnull(Trade_ID, -1) > 0
                                                                                    and Trade_ID = @id
                                                                                    and enabled = 0 ) > 0
                                                                             begin
                                                                                 rollback tran
                                                                                 if @@LANGID = 0
                                                                                     set @reftab = 'NSDBulkTrades'
                                                                                      else
                                                                                     set @reftab = 'Сделки в Bulk'
                                                                                 select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                                 raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                                         end
                                                                              else
                                                                             if( select count(id)
                                                                                   from BlockCommissionOnTrades
                                                                                  where isnull(Trade_ID, -1) > 0
                                                                                        and Trade_ID = @id ) > 0
                                                                                 begin
                                                                                     rollback tran
                                                                                     if @@LANGID = 0
                                                                                         set @reftab = 'BlockCommissionOnTrades'
                                                                                          else
                                                                                         set @reftab = 'Начисленная комиссия по сделкам'
                                                                                     select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                                     raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                                             end
                                                                                  else
                                                                                 if( select count(id)
                                                                                       from CommissionsReports
                                                                                      where isnull(Trade_ID, -1) > 0
                                                                                            and Trade_ID = @id ) > 0
                                                                                     begin
                                                                                         rollback tran
                                                                                         if @@LANGID = 0
                                                                                             set @reftab = 'CommissionsReports'
                                                                                              else
                                                                                             set @reftab = 'Отчет по расчету комиссий'
                                                                                         select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                                         raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                                                 end
                                                                                      else
                                                                                     if( select count(id)
                                                                                           from TradeInstrs
                                                                                          where isnull(ChangeTrade_ID, -1) > 0
                                                                                                and ChangeTrade_ID = @id
                                                                                                and enabled = 0 ) > 0
                                                                                         begin
                                                                                             rollback tran
                                                                                             if @@LANGID = 0
                                                                                                 set @reftab = 'TradeInstrs'
                                                                                                  else
                                                                                                 set @reftab = 'Торговые поручения'
                                                                                             select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                                             raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                                                     end
                                                                                          else
                                                                                         if( select count(id)
                                                                                               from TradeInstrLinks
                                                                                              where isnull(Trade_ID, -1) > 0
                                                                                                    and Trade_ID = @id ) > 0
                                                                                             begin
                                                                                                 rollback tran
                                                                                                 if @@LANGID = 0
                                                                                                     set @reftab = 'TradeInstrLinks'
                                                                                                      else
                                                                                                     set @reftab = 'Связки сделок и поручений на сделку'
                                                                                                 select @str_id = convert(varchar(64), convert(bigint, @id))
                                                                                                 raiserror(50013, 15, 1, @str_id, @tab_name, @reftab) with seterror
                                                                                         end
                                                                                              else
                                                                                             begin
                                                                                                 select @row_count = count(id)
                                                                                                   from Tickets
                                                                                                  where Trade_ID <> -1
                                                                                                        and Trade_ID = @id
                                                                                                 if @row_count > 0
                                                                                                     begin
                                                                                                         select @table_id = table_id
                                                                                                           from tablelist
                                                                                                          where table_name = 'Tickets'
                                                                                                         delete from Tickets
                                                                                                         output @table_id
                                                                                                              , deleted.id
                                                                                                              , 3
                                                                                                                into #deleted_tableid_rowid_action
                                                                                                          where Trade_ID = @id
                                                                                                 end
                                                                                                 select @row_count = count(id)
                                                                                                   from TradeWarnings
                                                                                                  where Trade_ID <> -1
                                                                                                        and Trade_ID = @id
                                                                                                 if @row_count > 0
                                                                                                     begin
                                                                                                         select @table_id = table_id
                                                                                                           from tablelist
                                                                                                          where table_name = 'TradeWarnings'
                                                                                                         delete from TradeWarnings
                                                                                                         output @table_id
                                                                                                              , deleted.id
                                                                                                              , 3
                                                                                                                into #deleted_tableid_rowid_action
                                                                                                          where Trade_ID = @id
                                                                                                 end
                                                                                                 select @row_count = count(id)
                                                                                                   from Shares
                                                                                                  where Trade_ID <> -1
                                                                                                        and Trade_ID = @id
                                                                                                        and enabled = 0
                                                                                                 if @row_count > 0
                                                                                                     begin
                                                                                                         select @table_id = table_id
                                                                                                           from tablelist
                                                                                                          where table_name = 'Shares'
                                                                                                         update Shares
                                                                                                            set Enabled = ID
                                                                                                         output @table_id
                                                                                                              , inserted.id
                                                                                                              , 3
                                                                                                                into #deleted_tableid_rowid_action
                                                                                                          where Trade_ID = @id
                                                                                                                and Enabled = 0
                                                                                                 end
                                                                                                 select @row_count = count(id)
                                                                                                   from TradeProperties
                                                                                                  where Trade_ID <> -1
                                                                                                        and Trade_ID = @id
                                                                                                 if @row_count > 0
                                                                                                     begin
                                                                                                         select @table_id = table_id
                                                                                                           from tablelist
                                                                                                          where table_name = 'TradeProperties'
                                                                                                         delete from TradeProperties
                                                                                                         output @table_id
                                                                                                              , deleted.id
                                                                                                              , 3
                                                                                                                into #deleted_tableid_rowid_action
                                                                                                          where Trade_ID = @id
                                                                                                 end
                                                                                                 select @row_count = count(id)
                                                                                                   from TradeMessageProperties
                                                                                                  where Trade_ID <> -1
                                                                                                        and Trade_ID = @id
                                                                                                 if @row_count > 0
                                                                                                     begin
                                                                                                         select @table_id = table_id
                                                                                                           from tablelist
                                                                                                          where table_name = 'TradeMessageProperties'
                                                                                                         delete from TradeMessageProperties
                                                                                                         output @table_id
                                                                                                              , deleted.id
                                                                                                              , 3
                                                                                                                into #deleted_tableid_rowid_action
                                                                                                          where Trade_ID = @id
                                                                                                 end
                                                                                                 select @row_count = count(id)
                                                                                                   from SuspectOperations
                                                                                                  where Trade_ID <> -1
                                                                                                        and Trade_ID = @id
                                                                                                 if @row_count > 0
                                                                                                     begin
                                                                                                         select @table_id = table_id
                                                                                                           from tablelist
                                                                                                          where table_name = 'SuspectOperations'
                                                                                                         delete from SuspectOperations
                                                                                                         output @table_id
                                                                                                              , deleted.id
                                                                                                              , 3
                                                                                                                into #deleted_tableid_rowid_action
                                                                                                          where Trade_ID = @id
                                                                                                 end
                                                                                         end
             end
             fetch next from Trades_del_id_cursor into @id
                                                     , @status
         end
     close Trades_del_id_cursor
     deallocate Trades_del_id_cursor
go
alter table dbo.Trades enable trigger T_ON_DISABLE_Trades
go
/****** Object:  Trigger [dbo].[T_Trades_Gen_Row_ID]    Script Date: 20-Jan-20 13:38:27 ******/
set ansi_nulls on
go
set quoted_identifier off
go
create trigger dbo.T_Trades_Gen_Row_ID on dbo.Trades
for insert
as
     declare @RowID row_id
     declare tmp_cur_Trades cursor
     for select ID
           from Trades
          where id = -1
                or id is null
     open tmp_cur_Trades
     fetch next from tmp_cur_Trades into @RowID
     while @@FETCH_STATUS = 0
         begin
             exec P_GenFloatValue @RowID output
                                , 'trades_table'
             if @@ERROR = 0
                 begin
                     update Trades
                        set ID = @RowID
                      where current of tmp_cur_Trades
             end
             fetch next from tmp_cur_Trades into @RowID
         end
     close tmp_cur_Trades
     deallocate tmp_cur_Trades
go
alter table dbo.Trades enable trigger T_Trades_Gen_Row_ID
go