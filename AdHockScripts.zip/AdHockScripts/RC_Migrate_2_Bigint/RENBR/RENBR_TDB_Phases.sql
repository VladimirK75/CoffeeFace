use QORT_TDB_PROD
go
alter table Phases nocheck constraint all;
alter table Phases alter column TradeNum bigint;
go
