use QORT_DB_PROD
go
exec sp_rename 'Orders'
             , 'Orders_old'
go
exec sp_rename 'Orders_old.PK_Orders'
             , 'PK_Orders_old'
go
drop trigger dbo.T_Orders_Gen_Row_ID
go
alter table dbo.Orders_old drop constraint DEF_Orders_id
alter table dbo.Orders_old drop constraint DEF_Orders_IsSigned
alter table dbo.Orders_old drop constraint DEF_Orders_IsExcludeComm
alter table dbo.Orders_old drop constraint DEF_Orders_IsClientSigned
alter table dbo.Orders_old drop constraint CK_Orders_IsSigned
alter table dbo.Orders_old drop constraint CK_Orders_IsExcludeComm
alter table dbo.Orders_old drop constraint CK_Orders_IsClientSigned
go
create table dbo.Orders
( id              dbo.ROW_ID not null
, OrderNum        bigint not null
, Qty             float null
, Subacc_ID       float null
, Security_ID     float null
, Account_ID      float null
, TraderUID       int null
, PayAsset_ID     float null
, LotQty          float null
, Price           float null
, BuySell         smallint null
, OrderDate       dbo.MDATE not null
, OrderTime       dbo.MTIME null
, QuikSecCode     varchar(12) collate Cyrillic_General_CI_AS null
, QuikClassCode   varchar(12) collate Cyrillic_General_CI_AS not null
, Comment         varchar(20) collate Cyrillic_General_CI_AS null
, FunctionType    smallint null
, CPFirmCode      varchar(12) collate Cyrillic_General_CI_AS null
, SettleCode      varchar(12) collate Cyrillic_General_CI_AS null
, RefundRate      float null
, RepoRate        float null
, RepoTerm        smallint null
, Volume          float null
, StartDiscount   float null
, LowerDiscount   float null
, UpperDiscount   float null
, MatchRef        varchar(10) collate Cyrillic_General_CI_AS null
, Price2          float null
, status          smallint null
, Balance         float null
, Enabled         float not null
, BOOrderNum      float null
, DealerFirm      varchar(12) collate Cyrillic_General_CI_AS null
, IsSigned        dbo.YN_FLAG not null
, BONum           varchar(40) collate Cyrillic_General_CI_AS null
, IsExcludeComm   dbo.YN_FLAG not null
, IsClientSigned  dbo.YN_FLAG not null
, QFlags          int null
, ExchangeCode    varchar(65) collate Cyrillic_General_CI_AS null
, ActivationTime  dbo.MTIME null
, WithdrawTime    dbo.MTIME null
, Trader          varchar(12) collate Cyrillic_General_CI_AS null
, InfoSource_ID   float null
, DM_Const        smallint null
, TYPE_Const      smallint null
, InstrSort_Const smallint null
, AuthorFIO       varchar(100) collate Cyrillic_General_CI_AS null
, AuthorPTS       dbo.STRING32 null
, InstrDate       dbo.MDATE null
, InstrTime       dbo.MTIME null
, created_date    dbo.MDATE null
, modified_date   dbo.MDATE null
, created_time    dbo.MTIME null
, modified_time   dbo.MTIME null
, user_created    dbo.USERID null
, user_modified   dbo.USERID null
, constraint PK_Orders primary key clustered(OrderDate asc, QuikClassCode asc, OrderNum asc, Enabled asc)
  with(pad_index = off, statistics_norecompute = off, ignore_dup_key = off, allow_row_locks = on, allow_page_locks = on, data_compression = page) on [OrderDateRangePS_Orders]([OrderDate]) )
on [OrderDateRangePS_Orders]([OrderDate])
go
create unique nonclustered index I_Orders_ID on dbo.Orders
( id asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, ignore_dup_key = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page ) on [PRIMARY]
go
create nonclustered index I_Orders_ModifiedDate_ModifiedTime on dbo.Orders
( modified_date asc, modified_time asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page ) on [OrderDateRangePS_Orders]( OrderDate )
go
create nonclustered index I_Orders_SubaccID on dbo.Orders
( Subacc_ID asc ) with( pad_index = off, statistics_norecompute = off, sort_in_tempdb = off, drop_existing = off, online = off, allow_row_locks = on, allow_page_locks = on, data_compression = page ) on [OrderDateRangePS_Orders]( OrderDate )
go
alter table dbo.Orders
add constraint DEF_Orders_id default(-1) for id
go
alter table dbo.Orders
add constraint DEF_Orders_IsSigned default 'n' for IsSigned
go
alter table dbo.Orders
add constraint DEF_Orders_IsExcludeComm default 'n' for IsExcludeComm
go
alter table dbo.Orders
add constraint DEF_Orders_IsClientSigned default 'n' for IsClientSigned
go
alter table dbo.Orders
with nocheck
add constraint CK_Orders_IsClientSigned check(IsClientSigned = 'y'
                                              or IsClientSigned = 'n')
go
alter table dbo.Orders nocheck constraint CK_Orders_IsClientSigned
go
alter table dbo.Orders
with nocheck
add constraint CK_Orders_IsExcludeComm check(IsExcludeComm = 'y'
                                             or IsExcludeComm = 'n')
go
alter table dbo.Orders nocheck constraint CK_Orders_IsExcludeComm
go
alter table dbo.Orders
with nocheck
add constraint CK_Orders_IsSigned check(IsSigned = 'y'
                                        or IsSigned = 'n')
go
alter table dbo.Orders nocheck constraint CK_Orders_IsSigned
go

EXEC P_AddFieldDesc -1, 'Orders', 'InstrDate', 5, 4, 'n', '0','','','','','','','','','','','','n' 
GO

EXEC P_AddFieldDesc -1, 'Orders', 'InstrTime', 6, 4, 'n', '0','','','','','','','','','','','','n' 
GO
