SET NOCOUNT ON;
DECLARE @DateFrom date= '2016-11-01'
      , @DateTo date  = '2010-01-01' --'2019-01-01'
      , @OrderDate int
	  , @TimeStamp varchar(1024)
	  , @Rowcount int
	  , @Limit int= 500000;
alter table Orders  nocheck constraint all;
WHILE @DateFrom >= @DateTo
begin
	SET ROWCOUNT 0;
	SET @TimeStamp = concat('RENBR: Order move OperDate=', format(@DateFrom, 'yyyy-MM-dd'), ' at ', format(GETDATE(), 'HH:mm:ss.fff'));
	RAISERROR(N'%s', 10, 1, @TimeStamp) WITH NOWAIT;
	SELECT @OrderDate = format(@DateFrom, 'yyyyMMdd'), @Rowcount = 1;
	drop table if exists #tmp_Orders
	SELECT oo.id, oo.OrderNum, oo.Qty, oo.Subacc_ID, oo.Security_ID, oo.Account_ID, oo.TraderUID, oo.PayAsset_ID, oo.LotQty, oo.Price, oo.BuySell, oo.OrderDate, oo.OrderTime, oo.QuikSecCode, oo.QuikClassCode, oo.Comment, oo.FunctionType, oo.CPFirmCode, oo.SettleCode, oo.RefundRate, oo.RepoRate, oo.RepoTerm, oo.Volume, oo.StartDiscount, oo.LowerDiscount, oo.UpperDiscount, oo.MatchRef, oo.Price2, oo.STATUS, oo.Balance, oo.Enabled, oo.BOOrderNum, oo.DealerFirm, oo.IsSigned, oo.BONum, oo.created_date, oo.modified_date, oo.created_time, oo.modified_time, oo.user_created, oo.user_modified, oo.IsExcludeComm, oo.IsClientSigned, oo.QFlags, oo.ExchangeCode, oo.ActivationTime, oo.WithdrawTime, oo.Trader, oo.DM_Const, oo.TYPE_Const, oo.InstrSort_Const, oo.AuthorFIO, oo.AuthorPTS, oo.InfoSource_ID
	INTO #tmp_Orders
	FROM QORT_DB_PROD..Orders_old oo with(nolock)
	WHERE oo.OrderDate = @OrderDate
	and not	EXISTS
			   (   SELECT 1
				   FROM dbo.Orders with(nolock, index=PK_Orders) 
				   WHERE Orders.OrderDate = oo.OrderDate AND 
						 Orders.QuikClassCode = oo.QuikClassCode AND 
						 Orders.OrderNum = cast(oo.OrderNum as bigint)
						 AND Orders.Enabled = oo.Enabled
			   )
	SET ROWCOUNT @Limit;
	WHILE @Rowcount > 0
	BEGIN
		SET @Rowcount = 0;
		SET @TimeStamp = concat('Moved Orders batch start OperDate=', format(@DateFrom, 'yyyy-MM-dd'), ' at ', format(GETDATE(), 'HH:mm:ss.fff'));
		RAISERROR(N'%s', 10, 1, @TimeStamp) WITH NOWAIT;
		INSERT INTO dbo.Orders( id, OrderNum, Qty, Subacc_ID, Security_ID, Account_ID, TraderUID, PayAsset_ID, LotQty, Price, BuySell, OrderDate, OrderTime, QuikSecCode, QuikClassCode, Comment, FunctionType, CPFirmCode, SettleCode, RefundRate, RepoRate, RepoTerm, Volume, StartDiscount, LowerDiscount, UpperDiscount, MatchRef, Price2, STATUS, Balance, Enabled, BOOrderNum, DealerFirm, IsSigned, BONum, created_date, modified_date, created_time, modified_time, user_created, user_modified, IsExcludeComm, IsClientSigned, QFlags, ExchangeCode, ActivationTime, WithdrawTime, Trader, DM_Const, TYPE_Const, InstrSort_Const, AuthorFIO, AuthorPTS, InfoSource_ID )
		SELECT oo.id, oo.OrderNum, oo.Qty, oo.Subacc_ID, oo.Security_ID, oo.Account_ID, oo.TraderUID, oo.PayAsset_ID, oo.LotQty, oo.Price, oo.BuySell, oo.OrderDate, oo.OrderTime, oo.QuikSecCode, oo.QuikClassCode, oo.Comment, oo.FunctionType, oo.CPFirmCode, oo.SettleCode, oo.RefundRate, oo.RepoRate, oo.RepoTerm, oo.Volume, oo.StartDiscount, oo.LowerDiscount, oo.UpperDiscount, oo.MatchRef, oo.Price2, oo.STATUS, oo.Balance, oo.Enabled, oo.BOOrderNum, oo.DealerFirm, oo.IsSigned, oo.BONum, oo.created_date, oo.modified_date, oo.created_time, oo.modified_time, oo.user_created, oo.user_modified, oo.IsExcludeComm, oo.IsClientSigned, oo.QFlags, oo.ExchangeCode, oo.ActivationTime, oo.WithdrawTime, oo.Trader, oo.DM_Const, oo.TYPE_Const, oo.InstrSort_Const, oo.AuthorFIO, oo.AuthorPTS, oo.InfoSource_ID
		FROM #tmp_Orders oo -- with(nolock, index =IX_Orders) 

		delete FROM #tmp_Orders 
		SET @Rowcount = @@ROWCOUNT;
		SET @TimeStamp = concat('Moved Orders OperDate=', format(@DateFrom, 'yyyy-MM-dd'), ' Total=', @Rowcount, ' at ', format(GETDATE(), 'HH:mm:ss.fff'));
		RAISERROR(N'%s', 10, 1, @TimeStamp) WITH NOWAIT;
		--if @Rowcount > 0
		--waitfor delay '00:01'
	END;
	SELECT @DateFrom = DATEADD(dd, -1, @DateFrom);
END;
alter table Orders with check check constraint all;
SET ROWCOUNT 0;