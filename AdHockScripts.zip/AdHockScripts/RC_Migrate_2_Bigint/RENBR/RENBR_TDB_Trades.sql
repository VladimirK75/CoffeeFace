use QORT_TDB_PROD
go
alter table Trades nocheck constraint all;
alter table Trades alter column OrderNum bigint;
drop index I_Trades_TradeNum_TS_NullStatus on dbo.Trades
go
alter table Trades alter column TradeNum bigint;
create nonclustered index I_Trades_TradeNum_TS_NullStatus on dbo.Trades( TradeNum asc, TSSection_Name asc, NullStatus asc ) with( data_compression = page );
alter table Trades
with check check constraint all;