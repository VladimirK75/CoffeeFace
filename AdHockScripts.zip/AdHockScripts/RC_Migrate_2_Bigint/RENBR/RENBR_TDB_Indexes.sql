create nonclustered index I_ImportOrders_OrderDate_QuikClassCode_OrderNum on dbo.ImportOrders
( OrderDate asc, QuikClassCode asc, OrderNum asc ) 
go

create nonclustered index I_ImportTrades_TradeNum_BuySell_TradeDate_TSSectionName_AgreeNum on dbo.ImportTrades
( TradeNum asc, BuySell asc, TradeDate asc, TSSection_Name asc, AgreeNum asc ) 
go

create nonclustered index I_ExportBlockCommissionOnTrades_AccrualDate_TradeNum_CommissionName on dbo.ExportBlockCommissionOnTrades
( AccrualDate asc, TradeNum asc, CommissionName asc ) 
go
