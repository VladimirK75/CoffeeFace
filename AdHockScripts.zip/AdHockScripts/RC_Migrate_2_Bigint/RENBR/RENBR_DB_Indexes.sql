alter table dbo.OriginLinkOrders
add constraint PK_OriginLinkOrders primary key clustered(OrderDate asc, QuikClassCode asc, OrderNum asc)
go
