select distinct 
       Table_Name = o.name
     , Column_Name = s.name
     , rowcnt=(select sum(s2.rowcnt) from sys.sysindexes s2 with(nolock) where o.object_id = s2.id)
     , ind = (select count(distinct ic.index_id)
                from sys.index_columns ic with(nolock)
               where ic.object_id = s.id
                     and ic.column_id = s.colid)
     , Ind_Object_id = s.id
     , Ind_colid = s.colid
  from sys.syscolumns s with(nolock)
  inner join sys.objects o with(nolock) on o.object_id = s.id and right(o.name,3) not in ('old','bak','log')
 where(s.name like '%TradeNum%'
       or s.name like '%OrderNum%')
      and s.xtype = 62
order by 1,2