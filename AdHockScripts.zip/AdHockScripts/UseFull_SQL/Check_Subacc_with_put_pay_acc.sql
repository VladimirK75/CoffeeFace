declare @CurrentDate int = format(getdate(), 'yyyyMMdd');
with tmp_subacc
     as (select s.id
              , s.SubAccCode
           from QORT_DB_PROD..Subaccs s with(nolock)
           inner join QORT_DB_PROD..ClientAgrees ca with(nolock) on ca.SubAcc_ID = s.id
                                                                    and ca.ClientAgreeType_ID = 1
                                                                    and @CurrentDate between ca.DateSign and isnull(nullif(ca.dateEnd, 0), @CurrentDate)
          where s.Enabled = 0
                and ACSTAT_Const != 7
                and IsQUIK = 'y'
                and s.SubAccCode = s.TradeCode
                and s.IsAnalytic = 'n')
     select distinct 
            ts.SubAccCode
          , PayAcc.AccountCode
          , PutAcc.AccountCode
       from tmp_subacc ts
       left join QORT_DB_PROD..PayAccs pa with(nolock) on pa.SubAcc_ID = ts.id
       left join QORT_DB_PROD..Accounts PayAcc with(nolock) on payacc.id = pa.PayAccount_ID
                                                               and PayAcc.Enabled = 0
       left join QORT_DB_PROD..Accounts PutAcc with(nolock) on PutAcc.id = pa.PutAccount_ID
                                                               and PutAcc.Enabled = 0
      where PayAcc.AccountCode is null
            or PutAcc.AccountCode is null
     order by ts.SubAccCode
