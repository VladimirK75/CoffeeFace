declare @DateFrom int = 20200101
      , @DateTo   int = 20200331
drop table if exists #tmp_Report
drop table if exists #tmp_Subacc
create table #tmp_Subacc
( RowID      int identity(1, 1)
, SubAccCode varchar(32) collate Cyrillic_General_CS_AS )
insert into #tmp_Subacc( SubAccCode )
select s2.SubAccCode
  from QORT_DB_PROD.dbo.SubaccStructure ss with(nolock)
  inner join QORT_DB_PROD.dbo.Subaccs s with(nolock) on s.id = ss.Father_ID
                                                     and s.SubAccCode = 'UMG873 A'
  inner join QORT_DB_PROD.dbo.Subaccs s2 with(nolock) on s2.id = ss.Child_ID
insert into #tmp_Subacc( SubAccCode )
values( 'UMG873' ), ( 'UMG953' ), ( 'RB0331' ), ( 'RBF331' ), ( 'RB0441' ), ( 'RB0447' )
delete #tmp_Subacc
 where exists( select 1
                 from #tmp_Subacc ts
                where #tmp_Subacc.SubAccCode = ts.SubAccCode
                      and ts.RowID > #tmp_Subacc.RowID )
select Loro = t.SubAcc_Code
     , t.TradeDate
     , TT_Const = tc.Description
     , t.TSSection_Name
     , t.SystemID
     , t.TradeNum
     , ISIN = t.Asset_ISIN
     , Asset = t.AssetShortName
     , t.isRepo2
     , BuySell = iif(t.BuySell = 1, 'Buy', 'Sell')
     , t.Qty
     , VolPrice = t.Volume1Nom
     , CurrPrice = t.CurrPriceAsset_ShortName
     , VolPay = iif(t.IsAccrued = 'y', t.Volume1, t.Volume1 + t.AccruedInt)
     , CurrPay = CurrPayAsset_ShortName
     , t.NullStatus
  from QORT_TDB_PROD.dbo.Trades t with(nolock)
  inner join QORT_DB_PROD.dbo.TT_Const tc with(nolock) on tc.[Value] = t.TT_Const
  inner join #tmp_Subacc ts on ts.SubAccCode = t.SubAcc_Code
  inner join QORT_DDM.dbo.DDM_fn_DateRange( @DateFrom, @DateTo, 0 ) dt on dt.OperDate = t.TradeDate
 where t.NullStatus = 'n'
