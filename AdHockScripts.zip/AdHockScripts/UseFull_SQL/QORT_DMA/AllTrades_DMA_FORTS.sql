select f.BOCode
     , s.SubAccCode
     , count(t.id)
  from QORT_DB_PROD..Trades T with(nolock)
  inner join QORT_DDM.dbo.DDM_fn_DateRange( 20190101, 20191231, 0 ) dt on dt.OperDate = T.TradeDate
  inner join QORT_DB_PROD..Subaccs s with(nolock) on s.id = t.SubAcc_ID
                                                     and left(s.SubAccCode, 3) = 'DCF'
  inner join QORT_DB_PROD..Firms f with(nolock) on f.id = s.OwnerFirm_ID
                                                   and f.BOCode in('ITALG', 'CRADL', 'RITMI', 'SAMOH', 'ROKIA', 'INSTM', 'ARGOG')
 where 1 = 1
       and t.TT_Const = 4 /* FORTS ONLY */
 group by f.BOCode
        , s.SubAccCode
order by 1, 2, 3