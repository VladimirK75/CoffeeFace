with tmp_Trades
     as (select SectionName = TS.Name
              , AssetClass = acc.[Description(eng.)]
              , AssetType = act.[Description(eng.)]
              , S.SecCode
              , A.ISIN
              , T.Qty
              , T.Volume1
              , A2.ShortName
                                                  , T.ID
                                                  , T.OrderNum
           from QORT_DB_PROD..Trades T with (nolock, index = PK_Trades)
           inner join QORT_DDM.dbo.DDM_fn_DateRange( 20190101, 20191231, 0 ) dt on dt.OperDate = T.TradeDate
           inner join QORT_DB_PROD..Securities S with(nolock) on S.id = T.Security_ID
           inner join QORT_DB_PROD..Assets A with(nolock) on A.id = S.Asset_ID
           inner join QORT_DB_PROD..AssetClass_Const acc with(nolock) on acc.[Value] = A.AssetClass_Const
           inner join QORT_DB_PROD..AssetSort_Const act with(nolock) on act.[Value] = a.AssetSort_Const
           inner join QORT_DB_PROD..TSSections TS with(nolock) on TS.id = T.TSSection_ID
                                                                  and TS.Name not like '%_CL'
                                                                  and TS.Name not like '%OTC%'
           inner join QORT_DB_PROD..Assets A2 with(nolock) on A2.id = T.CurrPayAsset_ID
          where 1 = 1
                and T.SubAcc_ID != 2808)
     select t.SectionName
          , t.AssetClass
          , t.AssetType
          , t.SecCode
          , t.ISIN
          , Qty = sum(t.Qty)
          , Total = sum(t.Volume1)
          , t.ShortName
                                  , CountTrades=Count(distinct t.id)
                                  , CountOrders=count(distinct t.OrderNum)
from tmp_Trades t
      group by t.SectionName
             , t.AssetClass
             , t.AssetType
             , t.SecCode
             , t.ISIN
             , t.ShortName
