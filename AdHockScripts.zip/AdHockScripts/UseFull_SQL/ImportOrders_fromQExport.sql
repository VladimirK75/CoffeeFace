
--INSERT INTO qort_tdb_prod.dbo.ImportOrders( id, OrderNum, Qty, Subacc_Code, Security_Code, Account_ExportCode, TraderUID, PayAsset_ShortName, LotQTY, Price, BuySell, OrderDate, OrderTime, QuikClassCode, Comment, FunctionType, STATUS, Balance, DealerFirm, Isprocessed, ET_Const, TSSectionName, DM_Const, TYPE_Const, InstrSort_Const, AuthorFIO, AuthorPTS )
select-1
    , OrderNum=iif(OrderNum > 100000000000, cast(Ordernum/10 as bigint), OrderNum )
    , Qty
    , Subacc_Code = 'UMG873'
    , Security_Code = SecCode
    , Account_ExportCode = 'ALORB_DEP_RENBR_08N.01'
    , TraderUID = 3081
    , PayAsset_ShortName = SecTradeCurrency
    , LotQTY = Qty
    , Price
    , BuySell = iif(Operation = 'Купля', 1, 2)
    , OrderDate = format(tradedate, 'yyyyMMdd')
    , OrderTime = format(OrderTime, 'HHmmssfff')
    , QuikClassCode = classcode
    , Comment = BrokerRef
    , FunctionType = 0
    , status = iif(State = 'Исполнена', 2, 3)
    , Balance
    , DealerFirm = FirmName
    , Isprocessed = 1
    , ET_Const = 2
    , TSSectionName = 'СПБ: Т+2'
    , DM_Const = 2
    , TYPE_Const = 2
    , InstrSort_Const = 2
    , AuthorFIO = 'QUIK FIX'
    , AuthorPTS = 'QUIK'
  from QUIK_73.QExport.dbo.Orders_History
 where tradedate = '2020-03-12'
       and classcode = 'SPBXM'
	   			 and not exists (select 1 
								   from QORT_DB_PROD.dbo.Orders o with(nolock, index=PK_Orders) 
								  where o.OrderDate=20200312  
								        and o.QuikClassCode='SPBXM' 
										and o.OrderNum=cast(Orders_History.OrderNum/10 as bigint))

