declare @DateFrom  date
      , @DateTo    date
	  , @UID_Count bigint
      , @TimeStamp varchar(1024)
      , @Msg       varchar(4000)
select @DateFrom = '2020-09-14' /*dateadd(month, -1, getdate())*/
     , @DateTo = getdate()
while @DateFrom < @DateTo
    begin
		select @UID_Count = 0
        set @TimeStamp = concat('RENBR-1: Очистка UID за ', format(@DateFrom, 'yyyy-MM-dd'), ' at ', format(getdate(), 'HH:mm:ss.fff'))
        select @Msg = concat(@Msg, @TimeStamp, char(10), char(13))
        raiserror(N'%s', 10, 1, @TimeStamp) with nowait
        drop table if exists #tmp_Orders
        create table #tmp_Orders
        ( OrderNum  bigint
        , OrderDate int
        , TraderUID int
        , id        float
        , status    bit )
        insert into #tmp_Orders
        ( OrderNum
        , OrderDate
        , TraderUID
        , id
        , status
        )
        select o.OrderNum
             , o.OrderDate
             , o.TraderUID
             , o.id
             , status = 0
          from QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders)
         where 1 = 1
               and o.orderdate = format(@DateFrom, 'yyyyMMdd')
			   and o.QuikClassCode='SPBFUT'
        set @TimeStamp = concat('RENBR-2: Очистка UID за ', format(@DateFrom, 'yyyy-MM-dd'), ' at ', format(getdate(), 'HH:mm:ss.fff'))
        select @Msg = concat(@Msg, @TimeStamp, char(10), char(13))
        raiserror(N'%s', 10, 1, @TimeStamp) with nowait
        update tmp_o
           set tmp_o.TraderUID = t.uid
             , tmp_o.status = 1
          from #tmp_Orders tmp_o
          inner join QUIK_73.QExport.dbo.Orders_History t with(nolock) on t.OrderNum = tmp_o.OrderNum
                                                                          and convert(date, t.Tradedate, 120) = @DateFrom
                                                                          and t.uid != tmp_o.TraderUID
        set @TimeStamp = concat('RENBR-3: Очистка UID за ', format(@DateFrom, 'yyyy-MM-dd'), ' at ', format(getdate(), 'HH:mm:ss.fff'))
        select @Msg = concat(@Msg, @TimeStamp, char(10), char(13))
        raiserror(N'%s', 10, 1, @TimeStamp) with nowait
        delete tmp_o
          from #tmp_Orders tmp_o
         where tmp_o.status = 0
		select @UID_Count = count(1) from #tmp_Orders
        set @TimeStamp = concat('RENBR-4: Очистка ', @UID_Count,' UID за ', format(@DateFrom, 'yyyy-MM-dd'), ' at ', format(getdate(), 'HH:mm:ss.fff'))
        select @Msg = concat(@Msg, @TimeStamp, char(10), char(13))
        raiserror(N'%s', 10, 1, @TimeStamp) with nowait
        update o
           set o.TraderUID = t.TraderUID
          from QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders)
          inner join #tmp_Orders t on o.id = t.id
                                      and o.orderdate = t.orderdate
         where 1 = 1
        set @TimeStamp = concat('RENBR-5: Очистка ', @UID_Count,' UID за ', format(@DateFrom, 'yyyy-MM-dd'), ' at ', format(getdate(), 'HH:mm:ss.fff'))
        select @Msg = concat(@Msg, @TimeStamp, char(10), char(13))
        raiserror(N'%s', 10, 1, @TimeStamp) with nowait
        alter table QORT_DB_PROD.dbo.Trades disable trigger T_ON_DISABLE_Trades
        update trd
           set trd.TraderUID = o.TraderUID
          from QORT_DB_PROD.dbo.Trades trd with (nolock, index = PK_Trades)
          inner join QORT_DB_PROD.dbo.orders o with (nolock, index = PK_Orders) on o.OrderNum = trd.OrderNum
                                                                                   and o.orderdate = trd.TradeDate
                                                                                   and o.TraderUID != trd.TraderUID
         where 1 = 1
               and trd.TradeDate = format(@DateFrom, 'yyyyMMdd')
        alter table QORT_DB_PROD.dbo.Trades enable trigger T_ON_DISABLE_Trades
        drop table if exists #tmp_Orders
        drop table if exists ##Mail_Orders
        select @DateFrom = dateadd(dd, 1, @DateFrom)
    end