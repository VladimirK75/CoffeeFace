with tmp_trades
     as (select t.id
              , tc.Description
              , t.IsRepo2
              , t.CrossRate
              , t.IsAccrued
              , t.Volume1
              , t.Volume1Nom
              , t.Volume2
              , t.Volume2Nom
              , t.Accruedint
              , t.AccruedintPart
              , t.AccruedintPrice
              , t.AccruedintPartPrice
              , t.Accruedint2
              , t.Accruedint2Part
              , t.Accruedint2Price
              , t.Accruedint2PartPrice
           from qort_ddm.dbo.DDM_fn_DateRange( 20171001, 20200401, 0 ) dt
           inner join qort_db_prod.dbo.Trades t with(nolock) on t.TradeDate = dt.OperDate
                                                                and CRT_Const = 1
                                                                and CurrPayAsset_ID = 71273
                                                                and CurrPriceAsset_ID = 71273
                                                                and PayStatus = 'y'
                                                                and CrossRate <> 1
           inner join qort_db_prod.dbo.TT_Const tc with(nolock) on tc.[Value] = t.TT_Const)
 /*    update t
        set t.CrossRate = 1
          , t.Volume1Nom = t.volume1
          , t.Volume2Nom = t.Volume2
          , t.AccruedintPrice = t.Accruedint
          , t.Accruedint2Price = t.Accruedint2
       from QORT_TDB_PROD..Trades t with(nolock)
       inner join tmp_trades tt on tt.id = t.SystemID
*/
     update t
        set t.CrossRate = 1
          , t.Volume1Nom = t.volume1
          , t.Volume2Nom = t.Volume2
		  , t.AccruedintPrice=t.Accruedint
          , t.AccruedintPart = cast((t.Accruedint/t.Qty) as numeric(19,2))
		  , t.AccruedintPartPrice = cast((t.Accruedint/t.Qty) as numeric(19,2))
		  , Accruedint2Price=t.Accruedint2
          , t.Accruedint2Part = cast((t.Accruedint2/t.Qty) as numeric(19,2))
		  , t.Accruedint2PartPrice = cast((t.Accruedint2/t.Qty) as numeric(19,2))
       from QORT_DB_PROD..Trades t with(nolock)
       inner join tmp_trades tt on tt.id = t.ID
