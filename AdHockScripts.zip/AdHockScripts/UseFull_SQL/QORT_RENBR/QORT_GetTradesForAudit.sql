drop table if exists #tmp_MarketTrades
create table #tmp_MarketTrades
( id        bigint
, TradeDate int
, ExoClient varchar(28)
, OrderNum  bigint )
declare @ISIN      varchar(48) = 'RU000A0JSQ90'
      , @StartDate datetime    = '2020-01-01'
      , @EndDate   datetime    = '2021-02-08'
while @StartDate <= @EndDate
    begin
        insert into #tmp_MarketTrades
        ( id
        , TradeDate
        , ExoClient
        , OrderNum
        )
        select *
          from( select t.id
                     , t.TradeDate
                     , ExoClient = QORT_DDM.dbo.QORT_GetListNumber( t.Comment, '/', 2 )
                     , t.OrderNum
                  from QORT_DB_PROD.dbo.Trades t with (nolock, index = PK_Trades)
                  inner join QORT_DB_PROD..Securities sec with(nolock) on t.Security_ID = sec.id
                                                                          and sec.Enabled = 0
                  inner join QORT_DB_PROD..Assets a with(nolock) on a.id = sec.Asset_ID
                                                                    and a.Enabled = 0
                                                                    and a.ISIN = @ISIN
                  inner join QORT_DB_PROD..Subaccs s with(nolock) on s.id = t.SubAcc_ID
                                                                     and s.SubAccCode = 'RB0331'
                  inner join QORT_DB_PROD..TSSections tsec with(nolock) on tsec.id = t.TSSection_ID
                  inner join QORT_DB_PROD..TSs ts with(nolock) on ts.id = tsec.TS_ID
                                                                  and ts.IsMarket = 'y'
                 where t.Enabled = 0
                       and t.Tradedate = format(@StartDate, 'yyyyMMdd')
                       and t.NullStatus = 'n' ) as t
         where t.ExoClient in ( 'EXN003', 'FID003' )
        select @StartDate = dateadd(dd, 1, @StartDate)
    end
select top 10 QORT_ID = t.id
     , [1] = t.BONum
     , [2] = format(QORT_DDM.dbo.DDM_GetDateTimeFromInt( t.TradeDate, t.TradeTime ), 'dd.MM.yyyy/HH:mm:ss')
     , [3] = tspl.Name
     , [4] = t2.SubAccOwner_ShortName
     , [5] = left(replace(t.Comment, 'RB331/', ''), 6) /*t2.SubAcc_Code*/
     , [6] = case
                 when tspl.IsMarket = 'y' then concat('Отчет ', tspl.Name, ' от ', format(QORT_DDM.dbo.DDM_GetDateTimeFromInt( t.TradeDate, 0 ), 'dd.MM.yyyy'))
                  else 'OTC Trade'
             end
     , [7] = 'БРОК'
     , [8] = 'Комиссии'
     , [9] = o.BONum
     , [10] = iif(t.BuySell = 1, 'Покупка', 'Продажа')
     , [11] = iif(t.BuySell = 1, t2.BrokerFirm_ShortName, t2.CpFirm_ShortName) 
     , [12] = iif(t.BuySell = 1, t2.CpFirm_ShortName, t2.BrokerFirm_ShortName) 
     , [13] = t2.Asset_Name
     , [14] = as0.Description
     , [15] = as1.Description
     , [16] = a.RegistrationCode
     , [17] = t2.Accruedint
     , [18] = cast(t2.Price as numeric(19, 6))
     , [19] = t2.CurrPriceAsset_ShortName
     , [20] = t2.Qty
     , [21] = cast(t2.Volume1Nom as numeric(19, 2))
     , [22] = t2.CurrPayAsset_ShortName
     , [23] = cast(t2.Volume1 as numeric(19, 2))
     , [24] = case
                  when t2.CurrPriceAsset_ShortName = 'RUR' then cast(t2.Volume1Nom as numeric(19, 2))
                  when t2.CurrPayAsset_ShortName = 'RUR' then cast(t2.Volume1 as numeric(19, 2))
                   else 0
              end
     , [25] = format(QORT_DDM.dbo.DDM_GetDateTimeFromInt( nullif(t.PutPlannedDate, 0), 0 ), 'dd.MM.yyyy')
     , [26] = format(QORT_DDM.dbo.DDM_GetDateTimeFromInt( nullif(t.PutDate, 0), 0 ), 'dd.MM.yyyy')
     , [27] = format(QORT_DDM.dbo.DDM_GetDateTimeFromInt( nullif(t.PayPlannedDate, 0), 0 ), 'dd.MM.yyyy')
     , [28] = format(QORT_DDM.dbo.DDM_GetDateTimeFromInt( nullif(t.PayDate, 0), 0 ), 'dd.MM.yyyy')
     , [29] = choose(t.SETTYPE_Const, 'None', 'OTC - Внеклиринговый расчет', 'CCP-Расчет по результатам клиринга с участием центрального контрагента', 'CS - Расчет по результатам клиринга без участия центрального контрагента')
     , [30] = iif(t.RepoTrade_ID < 0, '-', 'Репо')
     , [31] = iif(t.RepoTrade_ID < 0, '-', iif(t.IsRepo2 = 'y', '2-я часть', '1-я часть'))
     , [32] = '-'
     , [33] = '-'
     , [34] = ''
     , [35] = concat(cast(t.OrderNum as bigint), '')
     , [36] = t2.TSSection_Name
     , [37] = concat(cast(t.TradeNum as bigint), '')
     , [38] = '-'
     , [39] = 'Нет'
     , [40] = 'Нет'
  from QORT_DB_PROD..Trades t with(nolock)
  inner join #tmp_MarketTrades tmt on tmt.id = t.id
  left join QORT_DB_PROD..Orders o with(nolock) on o.OrderDate = t.TradeDate
                                                   and o.QuikClassCode = t.QUIKClassCode
                                                   and t.OrderNum = o.OrderNum
                                                   and o.Enabled = 0
  inner join QORT_DB_PROD..TSSections tsec with(nolock) on t.TSSection_ID = tsec.id
                                                           and tsec.Enabled = 0
  inner join QORT_DB_PROD..TSs tspl with(nolock) on tspl.id = tsec.TS_ID
  inner join QORT_DB_PROD..Securities sec with(nolock) on t.Security_ID = sec.id
                                                          and sec.Enabled = 0
  inner join QORT_DB_PROD..Assets a with(nolock) on a.id = sec.Asset_ID
                                                    and a.Enabled = 0
  inner join QORT_DB_PROD..AssetClass_Const as0 with(nolock) on a.AssetClass_Const = as0.[Value]
  inner join QORT_DB_PROD..AssetSort_Const as1 with(nolock) on a.AssetSort_Const = as1.[Value]
  inner join QORT_TDB_PROD..Trades t2 with(nolock) on t2.SystemID = t.id
 where 1 = 1
/*  ПЕРЕДВИНУТЬ ВРЕМЯ для регистра сделок, чтоб не было минусов внутри дня. Все зачисления на секунду раньше всех списаний */
 select top 10 * 
 --update p set p.PhaseTime = 165959000
 from QORT_DB_PROD..Phases p with(nolock) 
 inner join  #tmp_MarketTrades tmt on tmt.id = p.Trade_ID
 where p.PC_Const = 4
 and p.QtyAfter >0