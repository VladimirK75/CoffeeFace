Declare @CurrentDate date = getdate()
drop table if exists #SeccCodeReport
drop table if exists #QUIK_Seccode
create table #QUIK_Seccode
( Seccode varchar(32)
, ISIN    varchar(32) )
insert into #QUIK_Seccode
select distinct 
       s.seccode
     , isincode = isnull(s.isincode, '')
  from QUIK_73.QExport.dbo.Securities s with(nolock)
  inner join QUIK_73.QExport.dbo.Trades t with(nolock) on t.SecCode = s.SecCode
 where s.TradeDate = @CurrentDate
delete from #QUIK_Seccode
 where nullif(ISIN, '') is null
       and exists( select 1
                     from #QUIK_Seccode qs
                    where #QUIK_Seccode.Seccode = qs.Seccode
                          and nullif(qs.ISIN, '') is not null );
with tmp_QORT_Seccode
     as (select distinct 
                s.SecCode
              , a.ISIN
              , a.ShortName
              , s.IsPriority/*, s.id*/
           from QORT_DB_PROD.dbo.Position p with(nolock)
           inner join QORT_DB_PROD.dbo.Subaccs sub with(nolock) on sub.id = p.Subacc_ID
                                                                   and sub.OwnerFirm_ID != 70736
           inner join QORT_DB_PROD.dbo.Assets a with(nolock) on a.id = p.Asset_ID
           inner join QORT_DB_PROD.dbo.Securities s with(nolock) on s.Asset_ID = p.Asset_ID
                                                                    and s.Enabled = 0
                                                                    and not exists( select 1
                                                                                      from QORT_DB_PROD..Securities s2 with(nolock)
                                                                                     where s2.Asset_ID = s.Asset_ID
                                                                                           and s2.SecCode = s.SecCode
                                                                                           and s2.IsPriority = 'y'
                                                                                           and s.IsPriority = 'n' )
           inner join QORT_DB_PROD.dbo.TSSections t with(nolock) on t.id = s.TSSection_ID
          where 1 = 1
                and p.created_date > 20180101
                and abs(p.VolFree) + abs(p.VolForward) + abs(p.VolBlocked) > 0 /* order by 1*/
         )
     select RowID = row_number() over(
            order by isnull(tqs.SecCode, qqs.Seccode)
                   , isnull(tqs.ISIN, qqs.ISIN)
                   , tqs.IsPriority)
          , tqs.SecCode
          , tqs.ISIN
          , tqs.ShortName
          , tqs.IsPriority
            /*, rNum = row_number() over(partition by tqs.ShortName order by tqs.IsPriority desc/*, tqs.id*/            )*/
          , QUIK_SecCode = qqs.Seccode
          , QUIK_ISIN = qqs.ISIN
          , NewPriority = cast('' as varchar(1))
          , TypeError = cast(0 as smallint)
     into #SeccCodeReport
       from tmp_QORT_Seccode tqs
       full outer join #QUIK_Seccode qqs on tqs.SecCode = qqs.Seccode
                                            or nullif(tqs.ISIN, '') = nullif(qqs.ISIN, '')
update scr
   set scr.NewPriority = 'y'
     , scr.TypeError = 1
  from #SeccCodeReport scr
 where scr.SecCode = scr.QUIK_SecCode
       and scr.ISIN = scr.QUIK_ISIN
update scr
   set scr.NewPriority = 'n'
     , scr.TypeError = 1
  from #SeccCodeReport scr
 where scr.SecCode != scr.QUIK_SecCode
       and scr.ISIN = scr.QUIK_ISIN
       and exists( select 1
                     from #SeccCodeReport scr0
                    where scr0.QUIK_SecCode = scr.QUIK_SecCode
                          and scr0.QUIK_ISIN in ( scr.ISIN, scr.QUIK_ISIN )
                   and scr0.TypeError = 1 )
update scr
   set scr.NewPriority = '?'
     , scr.TypeError = 2
  from #SeccCodeReport scr
 where 1 = 1
       and scr.QUIK_ISIN != ''
       and isnull(scr.ISIN, '') != ''
       and exists( select 1
                     from #SeccCodeReport scr0
                    where scr0.QUIK_ISIN = scr.QUIK_ISIN
                          and scr0.TypeError in ( 0, 2 )
                   and scr0.RowID != scr.RowID )
update scr
   set scr.NewPriority = '?'
     , scr.TypeError = 3
  from #SeccCodeReport scr
 where 1 = 1
       and scr.SecCode = scr.QUIK_SecCode
       and scr.TypeError = 0
update scr
   set scr.NewPriority = '?'
     , scr.TypeError = 3
  from #SeccCodeReport scr
 where 1 = 1
       and scr.ISIN = scr.QUIK_ISIN
       and scr.TypeError = 0
select *
  from #SeccCodeReport scr
 where 1 = 1
       and scr.TypeError not in ( 0 )
and isnull(nullif(scr.ISIN, ''), nullif(scr.QUIK_ISIN, '')) is not null
and scr.IsPriority <> scr.NewPriority
and TypeError=1
order by isnull(scr.ISIN, scr.QUIK_ISIN)
       , isnull(scr.SecCode, scr.QUIK_SecCode)
       , 1
