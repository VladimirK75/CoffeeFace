set nocount on;
declare @TimeStamp varchar(1024)
      , @Rowcount  int
      , @DateStart date          = '2020-02-04'
      , @DateEnd   date          = '2020-03-31'
set rowcount 0;
set @TimeStamp = concat('RENBR: Orders update. START at ', format(getdate(), 'HH:mm:ss.fff'));
raiserror(N'%s', 10, 1, @TimeStamp) with nowait;
select @Rowcount = 1;
while @DateStart <= @DateEnd
    begin
        set @TimeStamp = concat('Updated Orders for OrderDate=', format(@DateStart, 'yyyy-MM-dd'), ' at ', format(getdate(), 'HH:mm:ss.fff'));
        raiserror(N'%s', 10, 1, @TimeStamp) with nowait;
        drop table if exists #tmp_Orders
        select o.id
        into #tmp_Orders
          from QORT_DB_PROD..Orders o with (nolock, index = PK_Orders)
          inner join QORT_DB_PROD..Subaccs s with(nolock) on s.id = o.Subacc_ID
          inner join QORT_DB_PROD..Securities sec with(nolock) on sec.id = o.Security_ID
                                                                  and sec.TSSection_ID = 79 /* СПБ: Т+2*/
         where 1 = 1
               and o.OrderDate = format(@DateStart, 'yyyyMMdd')
        update o
           set o.DM_Const = 2 /* Способ подачи поручения - Электронное */
             , o.TYPE_Const = 2 /* Тип поручения (торговое/неторговое) - Торговое */
             , o.InstrSort_Const = 2 /* Категория поручения - обычное */
             , o.AuthorFIO = 'QUIK FIX' /* Автор - QUIK FIX */
             , o.AuthorPTS = 'QUIK' /* Тех. система – QUIK */
             , o.TraderUID = isnull(nullif(o.TraderUID, 0), 3081)
          from QORT_DB_PROD..Orders o with(nolock)
          inner join #tmp_Orders oo on oo.id = o.id
        delete from #tmp_Orders
        set @Rowcount = @@ROWCOUNT;
        set @TimeStamp = concat('Updated Orders. Total=', @Rowcount, ' at ', format(getdate(), 'HH:mm:ss.fff'));
        raiserror(N'%s', 10, 1, @TimeStamp) with nowait;
        set @DateStart = dateadd(dd, 1, @DateStart)
    end
set @TimeStamp = concat('RENBR: Orders update. FINISH at ', format(getdate(), 'HH:mm:ss.fff'));
raiserror(N'%s', 10, 1, @TimeStamp) with nowait;
set rowcount 0