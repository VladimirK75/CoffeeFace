declare @subject    varchar(256) = 'QORT RENBR -- All cancelled phases need to doublecheck'
      , @body       nvarchar(max)
      , @body_table nvarchar(max)
      , @body_sign  nvarchar(max)
      , @recipients varchar(256)  = 'ITSupportBackQORT@rencap.com'
      , @Recipcopy  varchar(256)  = 'vkruglov@rencap.com;'
drop table if exists #tmp_Report
create table #tmp_Report
( id       bigint
, PC_Const smallint
, BackID   varchar(128)
, Trade_ID bigint
, AgreeNum varchar(128)
, TradeNum bigint )
insert into #tmp_Report
select p.id
     , p.PC_Const
     , p.BackID
     , p.Trade_ID
     , t.AgreeNum
     , t.TradeNum
  from QORT_DB_PROD..Phases p with (nolock, index = I_Phases_ModifiedDate)
  inner join QORT_DB_PROD..Trades t with(nolock) on t.id = p.Trade_ID
                                                    and t.Nullstatus = 'n'
  inner join QORT_DDM.dbo.DDM_fn_DateRange( format(dateadd(dd, -7, getdate()), 'yyyyMMdd'), format(getdate(), 'yyyyMMdd'), 0 ) dt on dt.OperDate = p.modified_date
 where p.IsCanceled = 'y'
       and not exists( select 1
                         from QORT_DB_PROD..Phases p2 with(nolock)
                        where p2.Trade_ID = p.Trade_ID
                              and p2.PC_Const = p.PC_Const
                              and p2.BackID = p.BackID
                              and p2.id > p.id )
       and not exists( select 1
                         from QORT_DB_PROD..Phases p2 with(nolock)
                        where p2.Trade_ID = p.Trade_ID
                              and p2.PC_Const = p.PC_Const
                              and p2.IsCanceled = 'n' )
       and not exists( select 1
                         from QORT_DB_PROD..Phases p3 with(nolock)
                        where p3.Trade_ID = p.Trade_ID
                              and p3.PC_Const = 18
                              and p3.IsCanceled = 'n' )
select @body = '<html><body><head>
<style type="text/css">
.myTable {border-collapse:collapse;}
.myTable td, .myTable th {padding: 3px; border: 1px solid #000}
.myTable th {background-color: #C0C0C0; text-align: center; font-family: "Arial", Sans-serif; font-size: 13px}
.myTable td {font-family: "Arial", Sans-serif; font-size: 12px; text-align: center}
p {margin: 4px 0px 4px; font-family: "Arial", Sans-serif; font-size: 14px; color: #006600}
</style>
</head>
'
select @body_table = replace(replace(cast(( select td = concat(id, '</td>
			<td style="text-align: right ', iif(PC_Const in(26, 27), '', ';background-color:#F08080'), ' ">', PC_Const, '</td>
			<td>', BackID, '</td>
			<td style="text-align: right">', Trade_ID, '</td>
			<td style="text-align: right">', AgreeNum, '</td>
			<td style="text-align: right">', TradeNum)
                                              from( select *
                                                      from #tmp_Report ) tt
                                            order by TradeNum
                                                   , PC_Const for xml path('tr'), type ) as varchar(max)), '&lt;', '<'), '&gt;', '>')
if isnull(@body_table, '') <> ''
    begin
        set @body_table = concat('<table class="myTable" width=450px>', '<tr><th>Phase ID</th>
		     <th>PC_Const</th>
		     <th>BackID</th>
		     <th>Trade_ID</th>
		     <th>AgreeNum</th>
		     <th>TradeNum</th>
	    </tr>', replace(replace(@body_table, '&lt;', '<'), '&gt;', '>'), '</table>')
        select @body_sign = '<hr />
<p style="font-size: 9px">
Server:&nbsp; S-MSK01-SQL08\QORT_RENBR<br /> 
Maintenance Plan:&nbsp;QORT_DailyRoutineTask<br />
SubPlan:&nbsp;DailyCheck<br />
Step:&nbsp;CheckBrokenPhases<br />
Author: vkruglov@rencap.com
</p> '
        select @body = concat(@body, @body_table, @body_sign, '</body></html>')
        exec msdb.dbo.sp_send_dbmail @profile_name = 'QORTMonitoring'
                                   , @recipients = @recipients
                                   , @copy_recipients = @Recipcopy
                                   , @subject = @subject
                                   , @body = @body
                                   , @body_format = 'HTML'
                           /*, @query = 'select * from ##Mail_Orders'
                           , @attach_query_result_as_file = 1
                           , @query_result_separator =','
                           , @query_result_no_padding = 1*/
end
drop table if exists #tmp_Orders
drop table if exists ##Mail_Orders