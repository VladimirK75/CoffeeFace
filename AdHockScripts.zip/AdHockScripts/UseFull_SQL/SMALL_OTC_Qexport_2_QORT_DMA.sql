/*
����������� ��������� �������� ����

*/
/*
INSERT INTO [QORT_DMA].QORT_TDB_PROD.dbo.ImportTrades
   (TradeNum, 
	IsSigned,
	OrderNum, 
	TradeDate,
	TradeTime,
	TT_Const, 
	TimeSpread, 
	TSSection_Name,
	BUYSELL,
	security_code,
	qty,
	lotqty,
	price,
	pt_const,
	CurrPriceAsset_ShortName,
	CurrPayAsset_ShortName,
	CrossRate,
	CRT_Const,
    CrossRateDate,
    CrossRateShift,
    Accruedint,
    IsAccrued,
	volume1,
	PutPeriod,
    PayPeriod,
    PutPlannedDate,
	PayPlannedDate,
	BackDate,
	FeePay,
	FeePut,
	BackPrice,
	RepoRate,
	RepoTerm,
	Volume2,
	RepoDate2,
	InfoSource,
	PutAccount_ExportCode,
	PayAccount_ExportCode,
	SubAcc_Code,
	FutGO,
	SideBenefactor,
	SidePay,
	SideDepoPay,
	ChildTradeNum,
	OppositeTradeNum,
	TraderUser_ID,
	BrokerFirm_ShortName,
	comment,
	CpFirm_ShortName,
	SettleCode,
	DealerFirm,
	IsRepo2,
	IsProcessed,
	AgreeNum,
	IsSynchronize,
	IsDraft,
	Trader,
	QuikClassCode,
	SS_Const)
*/
select TradeNum
     , 'y' as                                                                      IsSigned
     , OrderNum
     , TradeDate = format(TradeDate, 'yyyyMMdd')
     , TradeTime = format(TradeTime, 'HHmmssfff')
     , TT_Const = 7 --- ���������
     , TimeSpread = 0 --- ���������
     , TSSection_Name = ts.name
     , BUYSELL = case tr.Operation when '�����' collate DATABASE_DEFAULT
            then 1 when '�������' collate DATABASE_DEFAULT
            then 2
       end
     , security_code = seccode
     , qty = qty
     , lotqty = qty
     , price
     , pt_const = 2 --- ���������
     , CurrPriceAsset_ShortName = replace(TradeCurrency,'SUR', 'RUR')
     , CurrPayAsset_ShortName = replace(TradeCurrency,'SUR', 'RUR')
     , CrossRate = 1
     , CRT_Const = 1
     , CrossRateDate = 0
     , CrossRateShift = 0
     , Accruedint = 0
     , IsAccrued = 'n'
     , value as                                                                    volume1
     , 2 as                                                                        PutPeriod
     , 2 as                                                                        PayPeriod
     , PutPlannedDate = null --- ���������� ���� ������ ���������
     , PayPlannedDate = null --- ���������� ���� ������ ���������
     , 0 as                                                                        BackDate
     , 0 as                                                                        FeePay
     , 0 as                                                                        FeePut
     , 0 as                                                                        BackPrice
     , 0 as                                                                        RepoRate
     , 0 as                                                                        RepoTerm
     , 0 as                                                                        Volume2
     , 0 as                                                                        RepoDate2
     , 'QUIK' as                                                                   InfoSource
     , account as                                                                  PutAccount_ExportCode
     , PayAccount_ExportCode = 'RENBR_BRO_RESEC_19B.02' --- ���������
     , right(clientcode, 6) as                                                     SubAcc_Code
     , 0 as                                                                        FutGO
     , '' as                                                                       SideBenefactor
     , '' as                                                                       SidePay
     , '' as                                                                       SideDepoPay
     , -1 as                                                                       ChildTradeNum
     , -1 as                                                                       OppositeTradeNum
     , -1 as                                                                       TraderUser_ID
     , 'Renaissance Securities (Cyprus) Limited' as                                BrokerFirm_ShortName
     , brokerref as                                                                comment
     , 'Credit Suisse Securities, Sociedad de Valores S.A.' as                     CpFirm_ShortName
     , SettleCode as                                                               SettleCode
     , firmid as                                                                   DealerFirm
     , 'n' as                                                                      IsRepo2
     , 1 as                                                                        IsProcessed
     , AgreeNum = isnull(exchangecode, concat('',tradenum))
     , 'n' as                                                                      IsSynchronize
     , 'n' as                                                                      IsDraft
     , userid as                                                                   Trader
     , classcode as                                                                QuikClassCode
     , 2 as                                                                        SS_Const
  from QUIK.QExport.dbo.Trades_history tr with(nolock)
  inner join QORT_DMA.QORT_DB_PROD.dbo.TSSections ts with(nolock) on ts.ClassList like '%' + tr.ClassCode + '%'
 where tradedate in ('2020-02-03','2020-02-04')
 and ClientCode is not NULL
 and TradeNum in (7348,7349,10327,10329,10344,10289,7450)